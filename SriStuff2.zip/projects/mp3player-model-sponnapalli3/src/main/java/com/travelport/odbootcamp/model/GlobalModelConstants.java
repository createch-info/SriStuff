package com.travelport.odbootcamp.model;

public class GlobalModelConstants {

  public static final String SYSTEM_ID = "OD_BOOTCAMP";
  public static final String NAMESPACE =
      "http://training.travelport.com/od_bootcamp/tp/mp3/sponnapalli3";
  public static final String NAMESPACE_VERSION = NAMESPACE + "/v0";
}
