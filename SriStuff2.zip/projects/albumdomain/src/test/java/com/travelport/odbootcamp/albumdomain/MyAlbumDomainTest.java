package com.travelport.odbootcamp.albumdomain;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import com.travelport.odt.restfw.plugin.common.exceptions.ServiceException;

/**
 * TODO when tests are written, remember to uncomment the stage 'Reports' in the Jenkinsfile so that
 * the Java Code Coverage and JUnit test reports are published for the Jenkins build job.
 */
public class MyAlbumDomainTest {

  private MyAlbumResource resource;

  @Before
  public void setup() {
    resource = new MyAlbumResource();
  }

  @After
  public void teardown() {
    resource = null;
  }

  @Ignore
  @Test
  public void doDelete_v0Test() throws ServiceException {
    // Test doDelete_v0
    resource.doDelete_v0("123");
  }

  @Ignore
  @Test
  public void doCreate_v0Test() throws ServiceException {
    // Test doDelete_v0
    AlbumID albumId = new AlbumID();

    Identifier id = new Identifier();
    id.setValue("123");
    albumId.setIdentifier(id);

    resource.doCreate_v0(albumId, "v0");
  }

  @Ignore
  @Test
  public void doQuery_v0Test() throws ServiceException {

    AlbumIdentifier albumId = resource.doQuery_Mp3_v0("Test song-1", "Test Artist-1");
    assertNotNull(albumId);
  }

  @Ignore
  @Test
  public void doGet_v0Test() throws ServiceException {

    String id = "123";

    AlbumIdentifier albumId = resource.doGet_v0(id);
    assertNotNull(id);
    assertNotNull(albumId.getIdentifier());
    assertNotNull(albumId.getIdentifier().getValue());
    assertEquals(albumId.getIdentifier().getValue(), id);
  }
}
