package com.travelport.odbootcamp.scenariotest;

import javax.xml.namespace.QName;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import com.travelport.odbootcamp.model.GlobalModelConstants;
import com.travelport.odt.restfw.audit.report.gen.AbstractScenarioTest;
import com.travelport.odt.restfw.audit.report.gen.TestType;
import com.travelport.odt.restfw.audit.report.gen.TestingTypes;
import com.travelport.odt.restfw.common.FrameworkConstants;
import com.travelport.odt.restfw.common.FrameworkContext;
import com.travelport.odt.restfw.consumer.ActionParam;
import com.travelport.odt.restfw.consumer.InvocationManager;
import com.travelport.odt.restfw.consumer.InvocationManagerFactory;
import com.travelport.odt.restfw.mock.MockResponseWriter;
import com.travelport.training.od_bootcamp.tp.mp3.sponnapalli3.ArtistIdentifier;

public class ArtistAtomicTest extends AbstractScenarioTest {

  private static InvocationManager invocationManager;
  private QName resource = new QName(GlobalModelConstants.NAMESPACE, "ArtistResource");

  // TODO for mocking
  @Rule
  public TestName testMethodName = new TestName();

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    System.setProperty(FrameworkConstants.SECURE_CONFIGURATION, "false");
    System.setProperty(FrameworkConstants.CONFIG_LOCATION,
        "config/com.travelport.odt.restfw.properties");
    System.setProperty(FrameworkConstants.CONTEXT_LOCATION,
        "config/com.travelport.odt.restfw.context.xml");
    FrameworkContext.newContext();
    invocationManager = InvocationManagerFactory.getManager();

  }

  // TODO for mocking
  @Before
  public void setup() {
    MockResponseWriter.setTestName(ArtistAtomicTest.class, testMethodName);
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
    FrameworkContext.close();
  }

  @TestType(type = TestingTypes.ALL)
  @Test
  public void testArtistAtomicGet() throws Exception {
    System.out.println("\nTesting GET...\n");

    ArtistIdentifier artistIdentifier = invocationManager.invocationBuilder().resource(resource)
        .action("Get").param(ActionParam.newParam("Identifier", "N1234"))
        .systemID(GlobalModelConstants.SYSTEM_ID)
        // framework defaults to MediaType.APPLICATION_JSON if not provided
        // .header(FrameworkConstants.ACCEPT_HEADER, MediaType.APPLICATION_XML)
        .header(FrameworkConstants.ACCEPT_VERSION_HEADER, 0).build().invoke(ArtistIdentifier.class);

    // AbstractScenarioTest provides the basic assertions, to provide a description of the test that
    // is being done
    // The test description is documented in the Test Automation Framework report
    assertNotNull("albumIdentifier not null", artistIdentifier);
  }
}
