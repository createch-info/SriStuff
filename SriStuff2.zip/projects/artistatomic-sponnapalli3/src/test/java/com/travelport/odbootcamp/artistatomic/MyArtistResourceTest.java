package com.travelport.odbootcamp.artistatomic;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import org.junit.Before;
import org.junit.Test;
import com.travelport.schema.common.Identifier;
import com.travelport.training.od_bootcamp.tp.mp3.sponnapalli3.ArtistID;
import com.travelport.training.od_bootcamp.tp.mp3.sponnapalli3.ArtistIdentifier;

public class MyArtistResourceTest {

  private MyArtistResource resource;

  @Before
  public void setup() {
    resource = new MyArtistResource();
  }

  @Test
  public void doCreate_v0Test() throws Exception {
    ArtistID artistID = new ArtistID();
    artistID.setId("albumID");

    Identifier identifier = new Identifier();
    identifier.setValue("123");

    artistID.setIdentifier(identifier);

    resource.doCreate_v0(artistID, "v0");
  }

  @Test
  public void doGet_v0Test() throws Exception {
    final String ID = "1234";

    ArtistIdentifier artistId = resource.doGet_v0(ID);

    assertNotNull(artistId);
    assertNotNull(artistId.getIdentifier());
    assertNotNull(artistId.getIdentifier().getValue());
    assertEquals(ID, artistId.getIdentifier().getValue());
  }

  @Test
  public void doDelete_v0Test() throws Exception {
    resource.doDelete_v0("123");
  }

}
