package com.travelport.odbootcamp.artistatomic;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import com.travelport.odbootcamp.model.GlobalModelConstants;
import com.travelport.odt.restfw.plugin.common.annotations.OTMAction;
import com.travelport.odt.restfw.plugin.common.annotations.OTMResource;
import com.travelport.odt.restfw.plugin.common.exceptions.ServiceException;
import com.travelport.odt.restfw.plugin.common.sync.ProcessingJob;
import com.travelport.schema.common.Identifier;
import com.travelport.training.od_bootcamp.tp.mp3.sponnapalli3.AbstractArtistResource;
import com.travelport.training.od_bootcamp.tp.mp3.sponnapalli3.ArtistID;
import com.travelport.training.od_bootcamp.tp.mp3.sponnapalli3.ArtistIdentifier;

@Path("OD_BOOTCAMP/Artists")
@OTMResource(systemId = "OD_BOOTCAMP", namespace = GlobalModelConstants.NAMESPACE_VERSION,
    localName = "ArtistResource")
@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
public class MyArtistResource extends AbstractArtistResource {

  @Override
  protected void doDelete_v0(String Identifier) throws ServiceException {
    // TODO Auto-generated method stub
    System.out.println("In MyArtistResource.doDelete_v0 method");

  }

  @Override
  protected void doCreate_v0(ArtistID artistID, String version) throws ServiceException {
    // TODO Auto-generated method stub
    System.out.println("In MyArtistResource.doCreate_v0 method");

  }

  @Override
  protected ArtistIdentifier doGet_v0(String Identifier) throws ServiceException {
    System.out.println("In MyArtistResource.doGet_v0 method");
    ArtistIdentifier artistId = null;
    artistId = new ArtistIdentifier();
    Identifier id = new Identifier();
    id.setValue(Identifier);
    artistId.setIdentifier(id);

    return artistId;
  }

  /**
   * This method is overridden to provide a work around for an OD REST Framework bug which will be
   * fixed in an upcoming release. This override allows the LocalResourceManager call for the Get
   * action to use the path parameter name of "Identifier" rather than the framework generated name
   * of "param1". This workaround will not be needed in future releases of the framework.
   */
  @Override
  @GET
  @OTMAction("Get")
  @Path("/{Identifier}")
  public Response get(@javax.ws.rs.PathParam("Identifier") final String identifier) {
    try {
      ProcessingJob job = new ProcessingJob() {
        public Object processRequest() throws ServiceException {
          return doGet_v0(identifier);
        }
      };

      return buildResponse(job.processRequest());

    } catch (Throwable t) {
      return buildResponse(t);
    }
  }
}
