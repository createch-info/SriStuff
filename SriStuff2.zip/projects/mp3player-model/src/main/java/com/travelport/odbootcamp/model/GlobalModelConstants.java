package com.travelport.odbootcamp.model;

public class GlobalModelConstants {
	
}