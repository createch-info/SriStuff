package com.travelport.odbootcamp.albumdomain;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;
import javax.xml.namespace.QName;
import com.travelport.odbootcamp.model.GlobalModelConstants;
import com.travelport.odt.restfw.common.FrameworkConstants;
import com.travelport.odt.restfw.consumer.ActionParam;
import com.travelport.odt.restfw.consumer.InvocationManager;
import com.travelport.odt.restfw.consumer.InvocationManagerFactory;
import com.travelport.odt.restfw.plugin.common.annotations.OTMAction;
import com.travelport.odt.restfw.plugin.common.annotations.OTMResource;
import com.travelport.odt.restfw.plugin.common.exceptions.ServiceException;
import com.travelport.odt.restfw.plugin.common.sync.ProcessingJob;
import com.travelport.training.od_bootcamp.tp.mp3.sponnapalli3.AbstractAlbumResource;
import com.travelport.training.od_bootcamp.tp.mp3.sponnapalli3.Album;
import com.travelport.training.od_bootcamp.tp.mp3.sponnapalli3.AlbumID;
import com.travelport.training.od_bootcamp.tp.mp3.sponnapalli3.AlbumIdentifier;
import com.travelport.training.od_bootcamp.tp.mp3.sponnapalli3.ArtistIdentifier;

@Path("OD_BOOTCAMP/Albums")
@OTMResource(systemId = GlobalModelConstants.SYSTEM_ID,
    namespace = GlobalModelConstants.NAMESPACE_VERSION, localName = "AlbumResource")
public class MyAlbumResource extends AbstractAlbumResource {

  private static InvocationManager invocationManager = InvocationManagerFactory.getManager();
  private final String systemID = GlobalModelConstants.SYSTEM_ID;
  private QName artistResource = new QName(GlobalModelConstants.NAMESPACE, "ArtistResource");
  private QName songResource = new QName(GlobalModelConstants.NAMESPACE, "SongResource");

  /**
   * This method is oveterridden to provide a work around for an OD REST Framework bug which will be
   * fixed in an upcoming release. This override allows the LocalResourceManager call for the Get
   * action to use the path parameter name of "Identifier" rather than the framework generated name
   * of "param1". This workaround will not be needed in future releases of the framework.
   */
  @Override
  @GET
  @OTMAction("Get")
  @Path("/{Identifier}")
  public Response get(@javax.ws.rs.PathParam("Identifier") final String identifier) {
    try {
      ProcessingJob job = new ProcessingJob() {
        public Object processRequest() throws ServiceException {
          return doGet_v0(identifier);
        }
      };

      return buildResponse(job.processRequest());

    } catch (Throwable t) {
      return buildResponse(t);
    }
  }

  @Override
  protected void doDelete_v0(String Identifier) throws ServiceException {
    System.out.println("MyAlbumResource.doDelete_v0");

  }

  @Override
  protected AlbumIdentifier doGet_v0(String Identifier) throws ServiceException {
    System.out.println("MyAlbumResource.doGet_v0");

    try {
      System.out.println("Calling Artist Atomic...");
      ArtistIdentifier artistIdentifier =
          invocationManager.invocationBuilder().resource(artistResource).action("Get")
              .param(ActionParam.newParam("Identifier", "N1234")).systemID(systemID)
              // framework defaults to MediaType.APPLICATION_JSON if not provided
              // .header(FrameworkConstants.ACCEPT_HEADER, MediaType.APPLICATION_XML)
              .header(FrameworkConstants.ACCEPT_VERSION_HEADER, 0).build()
              .invoke(ArtistIdentifier.class);
      System.out.println("Artist Atomic call successful.");
    } catch (Exception e) {
      e.printStackTrace();
    }

    AlbumIdentifier albumIdentifier = new AlbumIdentifier();
    albumIdentifier.setId("123");

    return albumIdentifier;
  }

  @Override
  protected AlbumIdentifier doQuery_Mp3_v0(String SongName, String ArtistName)
      throws ServiceException {
    System.out.println("MyAlbumResource.doQuery_Mp3_v0");
    AlbumIdentifier albumIdentifier = new AlbumIdentifier();
    albumIdentifier.setId("123");
    return albumIdentifier;
  }

  @Override
  protected void doCreate_v0(AlbumID albumID, String version) throws ServiceException {
    System.out.println("MyAlbumResource.doCreate_v0");

    if (albumID instanceof Album) {
      Album album = (Album) albumID;

      System.out.println("Title: " + album.getTitle());
    }
  }
}
