package com.travelport.odbootcamp.albumdomain;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import com.travelport.schema.common.Identifier;
import com.travelport.training.od_bootcamp.tp.mp3.sponnapalli3.Album;
import com.travelport.training.od_bootcamp.tp.mp3.sponnapalli3.AlbumID;
import com.travelport.training.od_bootcamp.tp.mp3.sponnapalli3.AlbumIdentifier;
import com.travelport.training.od_bootcamp.tp.mp3.sponnapalli3.ArtistID;
import com.travelport.training.od_bootcamp.tp.mp3.sponnapalli3.Song;
import com.travelport.training.od_bootcamp.tp.mp3.sponnapalli3.SongID;

public class MyAlbumResourceTest {

  private MyAlbumResource resource;

  @Before
  public void setUp() {
    this.resource = new MyAlbumResource();
  }

  @Test
  public void doCreate_v0AlbumIDTest() throws Exception {
    AlbumID albumID = new AlbumID();
    albumID.setId("albumID");

    Identifier identifier = new Identifier();
    identifier.setValue("123");

    albumID.setIdentifier(identifier);

    resource.doCreate_v0(albumID, "v0");
  }

  @Test
  public void doCreate_v0AlbumSummaryTest() throws Exception {
    Album albumSummary = new Album();
    albumSummary.setId("albumID");

    Identifier identifier = new Identifier();
    identifier.setValue("123");

    albumSummary.setIdentifier(identifier);
    albumSummary.setTitle("Love Me");

    ArtistID artistID = new ArtistID();
    Identifier artistIdentifer = new Identifier();
    artistIdentifer.setValue("234");
    artistID.setIdentifier(artistIdentifer);

    albumSummary.setArtist(artistID);

    List<SongID> songs = albumSummary.getSong();
    Song song = new Song();
    songs.add(song);

    albumSummary.setSong(songs);

    resource.doCreate_v0(albumSummary, "v0");
  }

  @Test
  public void doGet_v0Test() throws Exception {
    System.out.println("\nTesting GET...\n");

    AlbumIdentifier response = resource.doGet_v0("123");

    assertNotNull(response);
    assertEquals("123", response.getId());
  }

  @Test
  public void doDelete_v0Test() throws Exception {
    resource.doDelete_v0("123");
  }

  @Test
  public void doQuery_Mp3_v0Test() throws Exception {
    AlbumID albumId = resource.doQuery_Mp3_v0("song", "artist");
  }

}
