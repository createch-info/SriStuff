package com.travelport.odbootcamp.scenariotest;

import static org.junit.Assert.assertNotNull;

import javax.ws.rs.core.MediaType;
import javax.xml.namespace.QName;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;

import com.travelport.odt.restfw.audit.report.gen.AbstractScenarioTest;
import com.travelport.odt.restfw.common.FrameworkConstants;
import com.travelport.odt.restfw.common.FrameworkContext;
import com.travelport.odt.restfw.consumer.ActionParam;
import com.travelport.odt.restfw.consumer.InvocationManager;
import com.travelport.odt.restfw.consumer.InvocationManagerFactory;
import com.travelport.schema.common.Identifier;

import com.travelport.odt.restfw.audit.report.gen.TestType;
import com.travelport.odt.restfw.audit.report.gen.TestingTypes;

import sandbox.demonstration.mp3.AlbumID;
import sandbox.demonstration.mp3.AlbumIdentifier;

public class AlbumDomainTest extends AbstractScenarioTest {

	private static InvocationManager invocationManager;
	private final String systemID = "OD_BOOTCAMP";
	private QName resource = new QName(
			"http://sandbox/Demonstration/MP3", "AlbumResource");

// TODO for mocking			
//	@Rule
//	public TestName testMethodName = new TestName();
 
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {	
		System.setProperty(FrameworkConstants.SECURE_CONFIGURATION, "false");
		System.setProperty(FrameworkConstants.CONFIG_LOCATION,
				"config/com.travelport.odt.restfw.properties");
		System.setProperty(FrameworkConstants.CONTEXT_LOCATION,
				"config/com.travelport.odt.restfw.context.xml");
		FrameworkContext.newContext();
		invocationManager = InvocationManagerFactory.getManager();
		
	}
	
// TODO for mocking			
//	@Before
//	public void setup() {
//		MockResponseWriter.setTestName(AlbumDomainTest.class, testMethodName);
//	}
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		FrameworkContext.close();
	}
	
    @TestType(type = TestingTypes.ALL)
	@Test
	public void testAlbumDomainGet() throws Exception {
		System.out.println("\nTesting GET...\n");
		 
		AlbumIdentifier albumIdentifier = invocationManager.invocationBuilder().resource(resource)
				.action("Get")
				.param(ActionParam.newParam("Identifier", "N1234"))
				.systemID(systemID)
				// framework defaults to MediaType.APPLICATION_JSON if not provided
//				.header(FrameworkConstants.ACCEPT_HEADER, MediaType.APPLICATION_XML)
				.header(FrameworkConstants.ACCEPT_VERSION_HEADER, 0).build()
				.invoke(AlbumIdentifier.class);

		// AbstractScenarioTest provides the basic assertions, to provide a description of the test that is being done
		// The test description is documented in the Test Automation Framework report
		assertNotNull("albumIdentifier not null", albumIdentifier);
	}
	
    @TestType(type = TestingTypes.ALL)
	@Test
	public void testAlbumDomainDelete() throws Exception {
		System.out.println("\nTesting DELETE...\n");
		 
		invocationManager.invocationBuilder().resource(resource)
				.action("Delete")
				.param(ActionParam.newParam("param1", "N1234"))
				.systemID(systemID)
				.header(FrameworkConstants.ACCEPT_VERSION_HEADER, 0)
				.build()
				.invoke();
	}
	
    @TestType(type = TestingTypes.ALL)
	@Test
	public void testAlbumDomainCreate() throws Exception {
		System.out.println("\nTesting CREATE...\n");

		final String ALBUM_NAME = "Ten Summoners Tales";
		final String SONG_NAME = "Fields of Gold";
		
		AlbumID albumId = new AlbumID();
		albumId.setId("ID");
		
		Identifier identifier = new Identifier();
		identifier.setValue("N1234");
		albumId.setIdentifier(identifier);

		invocationManager.invocationBuilder().resource(resource)
				.action("Create")
				.param(ActionParam.newParam("Song", SONG_NAME))
				.param(ActionParam.newParam("Name", ALBUM_NAME))
				.systemID(systemID)
				.header(FrameworkConstants.CONTENT_TYPE_HEADER, MediaType.APPLICATION_XML)
				.header(FrameworkConstants.CONTENT_VERSION_HEADER, 0)
				.payload(albumId)
				.build()
				.invoke();
	}
	
    @TestType(type = TestingTypes.ALL)
	@Test
	public void testAlbumDomainQuery() throws Exception {
		System.out.println("\nTesting QUERY...\n");

		final String ALBUM_NAME = "Ten Summoners Tales";
		final String SONG_NAME = "Fields of Gold";
		
		AlbumIdentifier albumIdentifier = invocationManager.invocationBuilder().resource(resource)
				.action("Query_mp3")
				.param(ActionParam.newParam("Song", SONG_NAME))
				.param(ActionParam.newParam("Name", ALBUM_NAME))
				.systemID(systemID)
				.header(FrameworkConstants.CONTENT_TYPE_HEADER, MediaType.APPLICATION_XML)
				.header(FrameworkConstants.CONTENT_VERSION_HEADER, 0)
				.build()
				.invoke(AlbumIdentifier.class);
		
		// AbstractScenarioTest provides the basic assertions, to provide a description of the test that is being done
		// The test description is documented in the Test Automation Framework report
		assertNotNull("albumIdentifier not null", albumIdentifier);
	}
	
}
