USE [odauditsdb]
GO
/****** Object:  Table [odaudits].[gb_group]    Script Date: 1/10/2018 3:32:21 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [odaudits].[gb_group](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[project_team_id] [bigint] NOT NULL,
	[group_name] [varchar](100) NOT NULL,
 CONSTRAINT [PK_gb_group] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [odaudits].[git_repository]    Script Date: 1/10/2018 3:32:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [odaudits].[git_repository](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[project_team_id] [bigint] NOT NULL,
	[project_key] [varchar](100) NOT NULL,
	[project_name] [varchar](100) NOT NULL,
	[branch] [varchar](100) NULL,
	[repository_url] [varchar](500) NOT NULL,
	[repository_name] [varchar](200) NOT NULL,
	[repository_type] [varchar](50) NOT NULL,
	[is_deleted] [int] NULL,
 CONSTRAINT [PK_git_repository] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [odaudits].[od_program_report]    Script Date: 1/10/2018 3:32:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [odaudits].[od_program_report](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[sonar_scan_info_id] [bigint] NOT NULL,
	[od_report_date] [timestamp] NOT NULL,
 CONSTRAINT [PK_od_program_report] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [odaudits].[od_scan]    Script Date: 1/10/2018 3:32:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [odaudits].[od_scan](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[git_repository_id] [bigint] NOT NULL,
	[scan_date] [timestamp] NOT NULL,
	[scan_type] [varchar](50) NOT NULL,
 CONSTRAINT [PK_od_scan] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [odaudits].[organization]    Script Date: 1/10/2018 3:32:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [odaudits].[organization](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[name] [varchar](200) NOT NULL,
	[is_deleted] [int] NULL,
 CONSTRAINT [PK_organization] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [odaudits].[organization_report]    Script Date: 1/10/2018 3:32:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [odaudits].[organization_report](
	[id] [bigint] NOT NULL,
	[organization_id] [bigint] NOT NULL,
	[sonar_scan_info_id] [bigint] NOT NULL,
	[od_program_report_id] [bigint] NOT NULL,
	[org_report_date] [timestamp] NOT NULL,
 CONSTRAINT [PK_organization_report] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [odaudits].[project_team]    Script Date: 1/10/2018 3:32:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [odaudits].[project_team](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[organization_id] [bigint] NOT NULL,
	[name] [varchar](200) NOT NULL,
	[is_deleted] [int] NULL,
 CONSTRAINT [PK_project_team] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [odaudits].[project_team_report]    Script Date: 1/10/2018 3:32:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [odaudits].[project_team_report](
	[id] [bigint] NOT NULL,
	[project_team_id] [bigint] NOT NULL,
	[sonar_scan_info_id] [bigint] NOT NULL,
	[od_program_report_id] [bigint] NOT NULL,
	[pt_report_date] [timestamp] NOT NULL,
 CONSTRAINT [PK_project_team_report] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [odaudits].[repository_report]    Script Date: 1/10/2018 3:32:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [odaudits].[repository_report](
	[id] [bigint] NOT NULL,
	[od_scan_id] [bigint] NOT NULL,
	[sonar_scan_info_id] [bigint] NOT NULL,
	[od_program_report_id] [bigint] NOT NULL,
	[sonar_qube_url] [varchar](500) NOT NULL,
	[report_date] [timestamp] NOT NULL,
 CONSTRAINT [PK_repository_report] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [odaudits].[sonar_scan_info]    Script Date: 1/10/2018 3:32:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [odaudits].[sonar_scan_info](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[bugs] [float] NOT NULL,
	[vulnerabilities] [float] NOT NULL,
	[tech_debt] [float] NOT NULL,
	[code_smells] [float] NOT NULL,
	[code_coverage] [float] NOT NULL,
	[complexity] [float] NOT NULL,
	[lines_of_code] [int] NOT NULL,
 CONSTRAINT [PK_sonar_scan_info] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [odaudits].[sonar_thresholds]    Script Date: 1/10/2018 3:32:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [odaudits].[sonar_thresholds](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[is_active] [int] NOT NULL,
	[bugs_low] [float] NOT NULL,
	[bugs_high] [float] NOT NULL,
	[vulnerabilities_low] [float] NOT NULL,
	[vulnerabilities_high] [float] NOT NULL,
	[tech_debt_low] [float] NOT NULL,
	[tech_debt_high] [float] NOT NULL,
	[complexity_low] [float] NOT NULL,
	[complexity_high] [float] NOT NULL,
	[code_coverage_low] [float] NOT NULL,
	[code_coverage_high] [float] NOT NULL,
	[effective_date] [date] NOT NULL,
 CONSTRAINT [PK_sonar_thresholds] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [odaudits].[gb_group]  WITH CHECK ADD  CONSTRAINT [FK_gb_group_project_team] FOREIGN KEY([project_team_id])
REFERENCES [odaudits].[project_team] ([id])
GO
ALTER TABLE [odaudits].[gb_group] CHECK CONSTRAINT [FK_gb_group_project_team]
GO
ALTER TABLE [odaudits].[git_repository]  WITH CHECK ADD  CONSTRAINT [FK_git_repository_project_team] FOREIGN KEY([project_team_id])
REFERENCES [odaudits].[project_team] ([id])
GO
ALTER TABLE [odaudits].[git_repository] CHECK CONSTRAINT [FK_git_repository_project_team]
GO
ALTER TABLE [odaudits].[od_program_report]  WITH CHECK ADD  CONSTRAINT [FK_od_program_report_sonar_scan_info] FOREIGN KEY([sonar_scan_info_id])
REFERENCES [odaudits].[sonar_scan_info] ([id])
GO
ALTER TABLE [odaudits].[od_program_report] CHECK CONSTRAINT [FK_od_program_report_sonar_scan_info]
GO
ALTER TABLE [odaudits].[od_scan]  WITH CHECK ADD  CONSTRAINT [FK_od_scan_git_repository] FOREIGN KEY([git_repository_id])
REFERENCES [odaudits].[git_repository] ([id])
GO
ALTER TABLE [odaudits].[od_scan] CHECK CONSTRAINT [FK_od_scan_git_repository]
GO
ALTER TABLE [odaudits].[organization_report]  WITH CHECK ADD  CONSTRAINT [FK_organization_report_od_program_report] FOREIGN KEY([od_program_report_id])
REFERENCES [odaudits].[od_program_report] ([id])
GO
ALTER TABLE [odaudits].[organization_report] CHECK CONSTRAINT [FK_organization_report_od_program_report]
GO
ALTER TABLE [odaudits].[organization_report]  WITH CHECK ADD  CONSTRAINT [FK_organization_report_organization] FOREIGN KEY([organization_id])
REFERENCES [odaudits].[organization] ([id])
GO
ALTER TABLE [odaudits].[organization_report] CHECK CONSTRAINT [FK_organization_report_organization]
GO
ALTER TABLE [odaudits].[organization_report]  WITH CHECK ADD  CONSTRAINT [FK_organization_report_sonar_scan_info] FOREIGN KEY([sonar_scan_info_id])
REFERENCES [odaudits].[sonar_scan_info] ([id])
GO
ALTER TABLE [odaudits].[organization_report] CHECK CONSTRAINT [FK_organization_report_sonar_scan_info]
GO
ALTER TABLE [odaudits].[project_team]  WITH CHECK ADD  CONSTRAINT [FK_project_team_organization] FOREIGN KEY([organization_id])
REFERENCES [odaudits].[organization] ([id])
GO
ALTER TABLE [odaudits].[project_team] CHECK CONSTRAINT [FK_project_team_organization]
GO
ALTER TABLE [odaudits].[project_team_report]  WITH CHECK ADD  CONSTRAINT [FK_project_team_report_od_program_report] FOREIGN KEY([od_program_report_id])
REFERENCES [odaudits].[od_program_report] ([id])
GO
ALTER TABLE [odaudits].[project_team_report] CHECK CONSTRAINT [FK_project_team_report_od_program_report]
GO
ALTER TABLE [odaudits].[project_team_report]  WITH CHECK ADD  CONSTRAINT [FK_project_team_report_project_team] FOREIGN KEY([project_team_id])
REFERENCES [odaudits].[project_team] ([id])
GO
ALTER TABLE [odaudits].[project_team_report] CHECK CONSTRAINT [FK_project_team_report_project_team]
GO
ALTER TABLE [odaudits].[project_team_report]  WITH CHECK ADD  CONSTRAINT [FK_project_team_report_sonar_scan_info] FOREIGN KEY([sonar_scan_info_id])
REFERENCES [odaudits].[sonar_scan_info] ([id])
GO
ALTER TABLE [odaudits].[project_team_report] CHECK CONSTRAINT [FK_project_team_report_sonar_scan_info]
GO
ALTER TABLE [odaudits].[repository_report]  WITH CHECK ADD  CONSTRAINT [FK_repository_report_od_program_report] FOREIGN KEY([od_program_report_id])
REFERENCES [odaudits].[od_program_report] ([id])
GO
ALTER TABLE [odaudits].[repository_report] CHECK CONSTRAINT [FK_repository_report_od_program_report]
GO
ALTER TABLE [odaudits].[repository_report]  WITH CHECK ADD  CONSTRAINT [FK_repository_report_od_scan] FOREIGN KEY([od_scan_id])
REFERENCES [odaudits].[od_scan] ([id])
GO
ALTER TABLE [odaudits].[repository_report] CHECK CONSTRAINT [FK_repository_report_od_scan]
GO
ALTER TABLE [odaudits].[repository_report]  WITH CHECK ADD  CONSTRAINT [FK_repository_report_sonar_scan_info] FOREIGN KEY([sonar_scan_info_id])
REFERENCES [odaudits].[sonar_scan_info] ([id])
GO
ALTER TABLE [odaudits].[repository_report] CHECK CONSTRAINT [FK_repository_report_sonar_scan_info]
GO
