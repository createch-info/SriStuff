package com.travelport.otm.compiler.test;

import com.travelport.otm.test.v0.TestCoreObject2;
import org.databene.contiperf.PerfTest;
import org.databene.contiperf.junit.ContiPerfRule;
import org.databene.contiperf.report.CSVLatencyReportModule;
import org.databene.contiperf.report.CSVSummaryReportModule;
import org.databene.contiperf.report.HtmlReportModule;
import org.eclipse.persistence.jaxb.JAXBContextFactory;
import org.eclipse.persistence.jaxb.MarshallerProperties;
import org.junit.*;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * @author joseph.savariraj
 */
public class PerformanceTestMoxyXML {

    private static JAXBContext ctx;
    private static Marshaller m;
    private static Unmarshaller unm;
    @Rule
    public ContiPerfRule rule = new ContiPerfRule(new HtmlReportModule(),
            new CSVSummaryReportModule(), new CSVLatencyReportModule());
    private ByteArrayInputStream in;
    private ByteArrayOutputStream out;

    @BeforeClass
    public static void setup() throws Exception {
        ctx = JAXBContextFactory.createContext("com.travelport.otm.test.v0:"
                + "com.travelport.otm.test.v0_1:"
                + "com.travelport.otm.test._2.v0:"
                + "com.travelport.otm.test._2.v1:"
                + "org.opentravel.common.message.v02:"
                + "org.opentravel.common.v02:"
                + "org.opentravel.ns.ota2.appinfo_v01_00:"
                + "org.opentravel.otm.common.v0", null);

        m = ctx.createMarshaller();
        m.setProperty(MarshallerProperties.MEDIA_TYPE, "application/xml");
        unm = ctx.createUnmarshaller();
        unm.setProperty(MarshallerProperties.MEDIA_TYPE, "application/xml");

    }

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
        File file = new File(
                "target/resources/schemas/examples/TestLibrary_0_0_0/TestCoreObject2.xml");
        Path path = Paths.get(file.toURI());
        byte[] bytes = Files.readAllBytes(path);
        in = new ByteArrayInputStream(bytes);
        out = new ByteArrayOutputStream(bytes.length);
        System.out.println("XML Size :: " + bytes.length);

    }

    @SuppressWarnings("rawtypes")
    @Test
    @PerfTest(duration = 11000, threads = 1, warmUp = 1000)
    public void testTestCoreObject2Xml() throws Exception {
        TestCoreObject2 core2 = (TestCoreObject2) ((javax.xml.bind.JAXBElement) unm
                .unmarshal(in)).getValue();
        m.marshal(core2, out);
        out.reset();
        in.reset();
    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception {
        if (in != null) {
            in.close();
        }
        if (out != null) {
            out.close();
        }
    }
}
