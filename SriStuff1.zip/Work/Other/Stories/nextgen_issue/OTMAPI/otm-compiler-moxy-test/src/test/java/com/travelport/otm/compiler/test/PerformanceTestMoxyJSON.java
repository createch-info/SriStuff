/**
 *
 */
package com.travelport.otm.compiler.test;

import com.travelport.otm.test.v0.TestCoreObject2;
import org.databene.contiperf.PerfTest;
import org.databene.contiperf.junit.ContiPerfRule;
import org.databene.contiperf.report.CSVLatencyReportModule;
import org.databene.contiperf.report.CSVSummaryReportModule;
import org.databene.contiperf.report.HtmlReportModule;
import org.eclipse.persistence.jaxb.JAXBContextFactory;
import org.eclipse.persistence.jaxb.MarshallerProperties;
import org.junit.*;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.junit.Assert.*;

/**
 * @author joseph.savariraj
 */
public class PerformanceTestMoxyJSON {

    private static JAXBContext ctx;
    private static Marshaller m1;
    private static Unmarshaller unm1;
    @Rule
    public ContiPerfRule rule = new ContiPerfRule(new HtmlReportModule(),
            new CSVSummaryReportModule(), new CSVLatencyReportModule());
    private ByteArrayInputStream in2;
    private ByteArrayOutputStream out2;

    /**
     * @throws java.lang.Exception
     */
    @BeforeClass
    public static void setup() throws Exception {

        ctx = JAXBContextFactory.createContext("com.travelport.otm.test.v0:"
                + "com.travelport.otm.test.v0_1:"
                + "com.travelport.otm.test._2.v0:"
                + "com.travelport.otm.test._2.v1:"
                + "org.opentravel.common.message.v02:"
                + "org.opentravel.common.v02:"
                + "org.opentravel.ns.ota2.appinfo_v01_00:"
                + "org.opentravel.otm.common.v0", null);

        m1 = ctx.createMarshaller();
        m1.setProperty(MarshallerProperties.MEDIA_TYPE, "application/json");
        unm1 = ctx.createUnmarshaller();
        unm1.setProperty(MarshallerProperties.MEDIA_TYPE, "application/json");
    }

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
        File file1 = new File(
                "target/resources/schemas/examples/TestLibrary_0_0_0/TestCoreObject2.json");
        Path path1 = Paths.get(file1.toURI());
        byte[] bytes1 = Files.readAllBytes(path1);
        in2 = new ByteArrayInputStream(bytes1);
        out2 = new ByteArrayOutputStream(bytes1.length);
        System.out.println("JSON Size :: " + bytes1.length);
    }

    @SuppressWarnings("rawtypes")
    @Test
    @PerfTest(duration = 11000, threads = 1, warmUp = 1000)
    public void testTestCoreObject2JSON() throws Exception {

        TestCoreObject2 core2 = (TestCoreObject2) ((javax.xml.bind.JAXBElement) unm1
                .unmarshal(in2)).getValue();
        m1.marshal(core2, out2);
        out2.reset();
        in2.reset();
    }

    @After
    public void tearDown() throws Exception {
        if (in2 != null) {
            in2.close();
        }
        if (out2 != null) {
            out2.close();
        }
    }

}
