package com.travelport.otm.test;

import com.travelport.otm.test.v0.TestBusinessObject2Detail;
import com.travelport.otm.test.v0.TestCoreObject2;
import com.travelport.otm.test.v0.TestCoreObject3;
import org.apache.commons.io.IOUtils;
import org.eclipse.persistence.jaxb.JAXBContextFactory;
import org.eclipse.persistence.jaxb.MarshallerProperties;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class UnmarshalMarshalThread implements Runnable {

    private static JAXBContext ctx;

    static {
        try {
            ctx = JAXBContextFactory.createContext("com.travelport.otm.test.v0:"
                    + "com.travelport.otm.test.v0_1:"
                    + "com.travelport.otm.test._2.v0:"
                    + "com.travelport.otm.test._2.v1:"
                    + "org.opentravel.common.message.v02:"
                    + "org.opentravel.common.v02:"
                    + "org.opentravel.ns.ota2.appinfo_v01_00:"
                    + "org.opentravel.otm.common.v0", null);
        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }

    private long timeToQuit;
    private ByteArrayInputStream in;
    private ByteArrayOutputStream out;
    private String type;
    private char size;

    public UnmarshalMarshalThread(char size, String type, long duration)
            throws IOException, JAXBException {
        this.type = type.toLowerCase();
        this.size = String.valueOf(size).toUpperCase().charAt(0);
        timeToQuit = System.currentTimeMillis() + duration;
        this.getFile();
    }

    /**
     *
     */
    @Override
    public void run() {
        long start = System.nanoTime();
        int count = 0;

        try {
            Marshaller m = ctx.createMarshaller();
            m.setProperty(MarshallerProperties.MEDIA_TYPE,
                    "application/" + type);
            Unmarshaller unm = ctx.createUnmarshaller();
            unm.setProperty(MarshallerProperties.MEDIA_TYPE,
                    "application/" + type);

            switch (size) {
                case 'L':
                    while (System.currentTimeMillis() < timeToQuit) {
//						try {
                        TestCoreObject2 testObj = (TestCoreObject2)
                                ((javax.xml.bind.JAXBElement)
                                        unm.unmarshal(in)).getValue();

                        m.marshal(testObj, out);
                        count++;

//						} catch (JAXBException e) {
//							e.printStackTrace();
//						}
                        out.reset();
                        in.reset();
                    }
                    break;

                case 'M':
                    while (System.currentTimeMillis() < timeToQuit) {
//						try {
                        TestBusinessObject2Detail testObj = (TestBusinessObject2Detail)
                                ((javax.xml.bind.JAXBElement)
                                        unm.unmarshal(in)).getValue();

                        m.marshal(testObj, out);
                        count++;

//						} catch (JAXBException e) {
//							e.printStackTrace();
//						}
                        out.reset();
                        in.reset();
                    }
                    break;
                case 'S':

                    while (System.currentTimeMillis() < timeToQuit) {
//						try {
                        TestCoreObject3 testObj = (TestCoreObject3)
                                ((javax.xml.bind.JAXBElement)
                                        unm.unmarshal(in)).getValue();

                        m.marshal(testObj, out);
                        count++;

//						} catch (JAXBException e) {
//							e.printStackTrace();
//						}
                        out.reset();
                        in.reset();
                    }
                    break;

                default:
                    //-TODO: What?
            }

            long time = System.nanoTime() - start;
            System.out.println(String.format(
                    "Time taken by %s to complete %.3f ms & processed %d",
                    Thread.currentThread().getName(), time / 1e6, count));

        } catch (JAXBException e1) {
            e1.printStackTrace();
            throw new RuntimeException("JAXBException from thread: ", e1);
        } finally {
            try {
                in.close();
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * @throws IOException
     */
    private void getFile() throws IOException {
        InputStream is = null;
        byte[] bytes;
        try {
            switch (size) {
                case 'L':
                    is = this.getClass().getResourceAsStream(
                            "/examples/TestLibrary_0_0_0/TestCoreObject2."
                                    + this.type);
                    break;

                case 'M':
                    is = this.getClass().getResourceAsStream(
                            "/examples/TestLibrary_0_0_0/TestBusinessObject2."
                                    + this.type);
                    break;

                case 'S':
                    is = this.getClass().getResourceAsStream(
                            "/examples/TestLibrary_0_0_0/TestCoreObject3."
                                    + this.type);
                    break;

                default:
                    //-TODO: What?
            }

            bytes = IOUtils.toByteArray(is);
            in = new ByteArrayInputStream(bytes);
            out = new ByteArrayOutputStream(bytes.length);
        } catch (IOException e) {
            throw new IOException(e);
        } finally {
            if (is != null)
                is.close();
        }

        System.out.println("JSON/XML file size= " + bytes.length);
    }

}
