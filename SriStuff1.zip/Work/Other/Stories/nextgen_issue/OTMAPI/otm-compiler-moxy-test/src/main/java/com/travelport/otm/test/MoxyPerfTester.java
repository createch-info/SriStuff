/**
 *
 */
package com.travelport.otm.test;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

//import javax.xml.bind.JAXBContext;


/**
 * @author jason.kramer
 */
public class MoxyPerfTester {

//	private static JAXBContext context;

    public MoxyPerfTester() {
        // TODO Auto-generated constructor stub
    }

    /**
     * @param args Argument usage:
     *             1) Number of threads
     *             2) Duration - in milliseconds
     *             3) XML / JSON or both
     *             4) Sample to use - small, medium, large
     */
    public static void main(String[] args) throws Exception {
        if (args == null || args.length != 4) {
            System.out.println("Invalid number of paramaters!");
            System.out.println("Paramater usage example: 2 30000 JSON s");
            System.out.println(" Where 2=Number of Threads, 30000=duration in milliseconds, JSON=type of object, small=size of object");
            System.exit(1);
        }

        int numberOfThreads = Integer.parseInt(args[0]);
        final long duration = Long.parseLong(args[1]);
        final String type = args[2].toLowerCase();
        final char size = args[3].toLowerCase().charAt(0);
        int trueNumberOfThreads = numberOfThreads;
        if ("both".equalsIgnoreCase(type)) {
            trueNumberOfThreads *= 2;
        }

        System.out.println("Parameters: " + numberOfThreads + " " + duration + " " + type + " " + size);

//		try {

        ExecutorService es = Executors.newFixedThreadPool(trueNumberOfThreads);
//			long timeToQuit = System.currentTimeMillis() + duration;

        if ("both".equalsIgnoreCase(type)) {
            for (int i = 0; i < trueNumberOfThreads; i++) {
                String xmlJsonType = "xml";
                if (i % 2 == 0) {
                    xmlJsonType = "json";
                }

                UnmarshalMarshalThread testThread = new UnmarshalMarshalThread(size,
                        xmlJsonType, duration);
                es.execute(testThread);

            }
        } else {
            for (int i = 0; i < trueNumberOfThreads; i++) {
                UnmarshalMarshalThread testThread = new UnmarshalMarshalThread(size,
                        type, duration);
                es.execute(testThread);
            }
        }

        es.shutdown(); // Disable new tasks from being submitted

        while (!es.isTerminated()) {
            // Just waiting...
        }

        System.out.println("All threads are done!");

//		} catch (JAXBException je) {
//			System.out.println("JAXBException occured!");
//		} catch (Exception e) {
//			System.out.println(e.getMessage());
//			System.out.println(e.getStackTrace());
//		}

    }

}
