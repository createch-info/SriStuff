/**
 *
 */
package com.travelport.otm.compiler.task;

import org.opentravel.schemacompiler.task.CompileAllTaskOptions;

/**
 * @author eric.bronson
 */
public interface OTMCompileAllTaskOptions extends CompileAllTaskOptions, JavaCompileTaskOptions {

    /**
     * Returns the option flag indicating that JAXB Java source files should be generated for all
     * libraries.
     *
     * @return boolean
     */
    public boolean isGenerateJavaClasses();


}
