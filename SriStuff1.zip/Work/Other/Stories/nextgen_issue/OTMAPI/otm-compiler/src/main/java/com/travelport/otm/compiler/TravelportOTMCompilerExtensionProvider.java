/**
 *
 */
package com.travelport.otm.compiler;

import org.opentravel.schemacompiler.extension.CompilerExtension;
import org.opentravel.schemacompiler.extension.CompilerExtensionProvider;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.core.io.InputStreamResource;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.Collections;


/**
 * @author eric.bronson
 */
public class TravelportOTMCompilerExtensionProvider implements
        CompilerExtensionProvider {

    /**
     * Classpath location of the OTM-API compiler extensions.
     */
    public static final String OTM_COMPILER_EXTENSION_PATH = "/otm-context/travelportOTMCompilerExtensions.xml";

    /**
     * Classpath location of the OTM-API compiler extensions.
     */
    public static final String OTM_COMPILER_EXTENSION_ID = "OTM";

    /**
     * @see org.opentravel.schemacompiler.extension.CompilerExtensionProvider#getCompilerExtensions()
     */
    @Override
    public Collection<CompilerExtension> getCompilerExtensions() {
        return Collections.emptySet();
    }

    /**
     * @see org.opentravel.schemacompiler.extension.CompilerExtensionProvider#isSupportedExtension(java.lang.String)
     */
    @Override
    public boolean isSupportedExtension(String extensionId) {
        return OTM_COMPILER_EXTENSION_ID.equals(extensionId);
    }

    /**
     * @see org.opentravel.schemacompiler.extension.CompilerExtensionProvider#loadGeneralCompilerExtensions(org.springframework.context.support.GenericApplicationContext)
     */
    @Override
    public void loadGeneralCompilerExtensions(GenericApplicationContext context)
            throws BeansException {
        XmlBeanDefinitionReader beanReader = new XmlBeanDefinitionReader(context);
        try (InputStream configStream = getClass().getResourceAsStream(OTM_COMPILER_EXTENSION_PATH)) {

            beanReader.setBeanClassLoader(getClass().getClassLoader());
            beanReader.setValidating(false);
            beanReader.loadBeanDefinitions(new InputStreamResource(configStream));
        } catch (IOException ioe) {
            //-TODO: what to do for close IOExceptions
        }
    }

    /**
     * @see org.opentravel.schemacompiler.extension.CompilerExtensionProvider#loadCompilerExtension(org.springframework.context.support.GenericApplicationContext,
     * java.lang.String)
     */
    @Override
    public void loadCompilerExtension(GenericApplicationContext context, String extensionId)
            throws BeansException {
        // No extensions that are specific to a particular binding style
    }

    /**
     * @see org.opentravel.schemacompiler.extension.CompilerExtensionProvider#getExtensionResource(java.lang.String)
     */
    @Override
    public InputStream getExtensionResource(String resourcePath) {
        return getClass().getResourceAsStream(resourcePath);
    }


}
