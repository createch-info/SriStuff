package com.travelport.otm.compiler.task;

import org.opentravel.schemacompiler.loader.LibraryInputSource;
import org.opentravel.schemacompiler.loader.LibraryModelLoader;
import org.opentravel.schemacompiler.loader.impl.CatalogLibraryNamespaceResolver;
import org.opentravel.schemacompiler.loader.impl.LibraryStreamInputSource;
import org.opentravel.schemacompiler.model.TLLibrary;
import org.opentravel.schemacompiler.model.TLModel;
import org.opentravel.schemacompiler.model.XSDLibrary;
import org.opentravel.schemacompiler.repository.Project;
import org.opentravel.schemacompiler.repository.ProjectManager;
import org.opentravel.schemacompiler.task.CommonCompilerTaskOptions;
import org.opentravel.schemacompiler.task.CompileAllCompilerTask;
import org.opentravel.schemacompiler.task.TaskUtils;
import org.opentravel.schemacompiler.util.SchemaCompilerException;
import org.opentravel.schemacompiler.util.URLUtils;
import org.opentravel.schemacompiler.validate.FindingType;
import org.opentravel.schemacompiler.validate.ValidationFindings;

import java.io.InputStream;
import java.net.URL;
import java.util.List;

/**
 * Task used to orchestrate the execution of separate compilation tasks: full
 * library schemas, service (WSDL) documents, resource action service (WSDL)
 * documents, Java classes, and versionMapping files.
 *
 * @author eric.bronson
 */
public class OTMCompileAllCompilerTask extends CompileAllCompilerTask implements
        OTMCompileAllTaskOptions {

    /**
     * The type of webservice classes to be generated.
     */
    protected String wsdlBindingStyle;
    /**
     * The schema folder location.
     */
    protected String schemaFolderLocation;
    /**
     * The version binding file.
     */
    protected String versionBindingFile;
    /**
     * The output folder location for generated java files (default location is
     * &lt;project&gt;/target/generated-sources/otm).
     */
    private String javaOutputFolder;
    /**
     * Should java classes be generated.
     */
    private boolean generateJavaClasses = true;
    /**
     * Should builder classes be generated.
     */
    private boolean generateBuilders = false;
    /**
     * Should ModelDoc files be generated.
     */
    private boolean generateModelDoc = false;

    /**
     * Validates an existing <code>TLModel</code> instance and compiles the
     * output using the options assigned for this task.
     *
     * @param model the model that contains all of the libraries for which to
     *              compile output
     * @return ValidationFindings
     * @throws SchemaCompilerException thrown if an unexpected error occurs during the compilation
     *                                 process
     */
    public ValidationFindings compileOutput(TLModel model)
            throws SchemaCompilerException {
        List<TLLibrary> userDefinedLibraries = model.getUserDefinedLibraries();
        List<XSDLibrary> xsdLibraries = model.getLegacySchemaLibraries();

        ValidationFindings findings = compileOutput(userDefinedLibraries,
                xsdLibraries);

        if (!findings.hasFinding(FindingType.ERROR)) {
            generateJavaClasses(findings, model);
            if (generateModelDoc) {
                DocumentationCompileTask docTask = new DocumentationCompileTask();
                docTask.setOutputFolder(getOutputFolder() + "/documentation");
                docTask.compileOutput(model);
                addGeneratedFiles(docTask.getGeneratedFiles());
            }

        }
        return findings;
    }

    /**
     * Generate the necessary Java classes.
     *
     * @param findings the current set of validation findings
     * @param model    the OTM model
     * @throws SchemaCompilerException if there is a generation issue
     */
    protected void generateJavaClasses(ValidationFindings findings, TLModel model) throws SchemaCompilerException {
        if (generateJavaClasses) {
            JavaCompilerTask javaTask = getJavaCompilerTask();
            javaTask.applyTaskOptions(this);
            findings.addAll(javaTask.compileOutput(model));
            addGeneratedFiles(javaTask.getGeneratedFiles());
        }
    }

    protected JavaCompilerTask getJavaCompilerTask() {
        return new JavaCompilerTask();
    }

    /**
     * @see org.opentravel.schemacompiler.task.CommonCompilerTaskOptions#applyTaskOptions(org.opentravel.schemacompiler.task.CommonCompilerTaskOptions)
     */
    @Override
    public void applyTaskOptions(CommonCompilerTaskOptions taskOptions) {
        if (taskOptions instanceof OTMCompileAllTaskOptions) {
            OTMCompileAllTaskOptions compileAllOptions = (OTMCompileAllTaskOptions) taskOptions;
            generateJavaClasses = compileAllOptions.isGenerateJavaClasses();
            javaOutputFolder = compileAllOptions.getJavaOutputFolder();
            generateBuilders = compileAllOptions.isGenerateBuilders();
            generateModelDoc = compileAllOptions.isGenerateModelDoc();
            schemaFolderLocation = compileAllOptions.getSchemaClasspathLocation();
            versionBindingFile = compileAllOptions.getConverterBindingFile();
        }
        super.applyTaskOptions(taskOptions);
    }

    /**
     * Loads a model using the content of the specified library (or project)
     * file and compiles the output using the options assigned for this task.
     *
     * @param libraryOrProjectUrl the URL location of the library/project file
     * @return ValidationFindings
     * @throws SchemaCompilerException thrown if an unexpected error occurs during the compilation
     *                                 process
     */
    public ValidationFindings compileOutput(URL libraryOrProjectUrl)
            throws SchemaCompilerException {
        ValidationFindings findings;
        TLModel model;
        if (isProjectFile(libraryOrProjectUrl)) {
            findings = new ValidationFindings();
            ProjectManager projectManager = new ProjectManager(false);
            Project project = projectManager.loadProject(
                    URLUtils.toFile(libraryOrProjectUrl), findings);
            projectFilename = project.getProjectFile().getName();
//			for (ProjectItem item : project.getProjectItems()) {
//	            AbstractLibrary itemContent = item.getContent();
//			}
            model = project.getModel();
        } else {
            LibraryInputSource<InputStream> libraryInput = new LibraryStreamInputSource(
                    libraryOrProjectUrl);
            LibraryModelLoader<InputStream> modelLoader = new LibraryModelLoader<>();
            String catalogLocation = getCatalogLocation();

            if (catalogLocation != null) {
                modelLoader
                        .setNamespaceResolver(new CatalogLibraryNamespaceResolver(
                                TaskUtils
                                        .getPathFromOptionValue(catalogLocation)));
            }
            findings = modelLoader.loadLibraryModel(libraryInput);
            model = modelLoader.getLibraryModel();
        }

        // Proceed with compilation if no errors were detected during the load
        if (!findings.hasFinding(FindingType.ERROR)) {
            findings.addAll(compileOutput(model));
        }
        return findings;
    }

    @Override
    public boolean isGenerateJavaClasses() {
        return generateJavaClasses;
    }

    @Override
    public String getJavaOutputFolder() {
        return javaOutputFolder;
    }

    @Override
    public boolean isGenerateBuilders() {
        return generateBuilders;
    }

    @Override
    public boolean isGenerateModelDoc() {
        return generateModelDoc;
    }

    @Override
    public String getSchemaClasspathLocation() {
        return schemaFolderLocation;
    }

    @Override
    public String getConverterBindingFile() {
        return versionBindingFile;
    }
}
