package com.travelport.otm.compiler.task;

import com.travelport.otm.jaxb.OTMContextFactory;
import com.travelport.otm.sourcegen.java.JavaCodeGenerationException;
import com.travelport.otm.sourcegen.java.JavaCodeGenerationFilter;
import com.travelport.otm.sourcegen.java.JavaCodeGenerator;
import com.travelport.otm.sourcegen.java.JavaCodegenUtils;
import com.travelport.otm.sourcegen.java.model.JavaModel;
import com.travelport.otm.sourcegen.java.model.JavaPackageInfo;
import com.travelport.otm.sourcegen.versioning.VersionMappingGenerator;
import com.travelport.otm.sourcegen.versioning.VersionMappingManager;
import org.opentravel.schemacompiler.codegen.CodeGenerationContext;
import org.opentravel.schemacompiler.codegen.CodeGenerationFilter;
import org.opentravel.schemacompiler.model.TLLibrary;
import org.opentravel.schemacompiler.model.TLModel;
import org.opentravel.schemacompiler.model.XSDLibrary;
import org.opentravel.schemacompiler.task.AbstractCompilerTask;
import org.opentravel.schemacompiler.task.CommonCompilerTaskOptions;
import org.opentravel.schemacompiler.util.SchemaCompilerException;
import org.opentravel.schemacompiler.validate.ValidationFindings;

import javax.xml.XMLConstants;
import java.io.*;
import java.util.*;
import java.util.Map.Entry;

/**
 * Task used to orchestrate the execution of creating Java class files from user
 * libraries.
 *
 * @author eric.bronson
 */
public class JavaCompilerTask extends AbstractCompilerTask {

    /**
     * Generator mapping key used by the generator factory.
     */
    public static final String JAVA_FORMAT = "JAVA";
    /**
     * Name of the context properties file.
     */
    public static final String CONTEXT_PROPERTIES_FILENAME = "com.travelport.otm.context.properties";
    /**
     * Name of the context properties file.
     */
    public static final String DEFAULT_SCHEMA_FOLDER = "schemas";
    /**
     * The jaxb properties file name.
     */
    private static final String JAXB_PROPERTIES_FILE_NAME = "jaxb.properties";
    /**
     * The property used by the JAXB API to select the context factory
     * implementation.
     */
    private static final String JAXB_CONTEXT_FACTORY_PROPERTY = "javax.xml.bind.context.factory=com.travelport.otm.jaxb.OTMContextFactory";
    /**
     * String builder used for creating file names.
     */
    private StringBuilder fileNameBuilder = new StringBuilder();

    /**
     * The location of the schema folder.
     */
    private String schemaOutputFolder;

    /**
     * Should builders be generated.
     */
    private boolean generateBuilders;

    /**
     * Schema classpath Location
     */
    private String schemaClasspathLocation;

    /**
     * The version binding file.
     */
    private String converterBindingFile;

    /**
     * @see org.opentravel.schemacompiler.task.AbstractCompilerTask#generateOutput(java.util.Collection,
     * java.util.Collection)
     */
    @Override
    public ValidationFindings compileOutput(TLModel model)
            throws SchemaCompilerException {
        CodeGenerationContext context = createContext();
        JavaCodeGenerator codeGenerator = getJavaCodeGenerator();
        codeGenerator.setGenerateBuilders(generateBuilders);
        if (converterBindingFile != null) {
            codeGenerator.loadBindings(converterBindingFile);
        }
        CodeGenerationFilter filter = new JavaCodeGenerationFilter(
                model.getUserDefinedLibraries());
        codeGenerator.setFilter(filter);
        // Just in case the libraries are not listed in the otp file in order
        List<TLLibrary> libs = JavaCodegenUtils.sortLibraries(model.getUserDefinedLibraries(), true);
        Map<String, String> uriPrefixMap = new HashMap<>();
        for (TLLibrary lib : libs) {
            codeGenerator.doGenerateOutput(lib, context);
            uriPrefixMap.put(lib.getNamespace(), lib.getPrefix());
        }
        VersionMappingManager.getInstance().cleanVersionBindings();

        addGeneratedFiles(codeGenerator.generateClassFiles(context));
        String javaOutputFolder = getOutputFolder();
        generatePropertyFiles(codeGenerator,
                javaOutputFolder, uriPrefixMap);

        VersionMappingGenerator versionMapGenerator = new VersionMappingGenerator();
        addGeneratedFiles(versionMapGenerator.generateOutput(model, context));
        return codeGenerator.getValidationFindings();
    }

    protected JavaCodeGenerator getJavaCodeGenerator() {
        return new JavaCodeGenerator();
    }


    /**
     * Creates the necessary properties file for use during runtime.
     *
     * @param uriPrefixMap
     * @param javaModel
     * @throws JavaCodeGenerationException
     */
    protected Properties generatePropertyFiles(JavaCodeGenerator generator,
                                               String javaOutputFolder, Map<String, String> uriPrefixMap) throws JavaCodeGenerationException {
        JavaModel javaModel = generator.getModel();
        Properties contextProperties = new Properties();

        if (javaModel != null) {
            // Create the list of packages referenced by the java model
            Collection<String> namespaces = generator.getClassTable()
                    .getNamespaces();
            Set<String> packages = new HashSet<>();
            for (String namespace : namespaces) {
                if (namespace.equals(XMLConstants.W3C_XML_SCHEMA_NS_URI)) {
                    continue;
                }
                packages.add(JavaCodegenUtils.getPackageName(namespace));
            }
            try {
                for (JavaPackageInfo info : javaModel.getPackages()) {
                    String pkg = info.getPackage();
                    if (!pkg.endsWith(".builders") && !javaModel.getClasses(info).isEmpty()) {
                        addJaxbProperties(pkg, javaOutputFolder);
                        // because we could have a user library that doesn't
                        // reference any of its own types and therefor won't
                        // show up in the symbolTable.
                        packages.add(pkg);
                    }
                }

                // build the context path
                String contextPath = createContextPath(packages);
                String schemas = getSchemas(schemaOutputFolder);
                String prefixes = getPrefixes(uriPrefixMap);
                contextProperties.setProperty(OTMContextFactory.SCHEMA_FOLDER,
                        schemas);
                contextProperties.setProperty(OTMContextFactory.CONTEXT_PATH,
                        contextPath);

                contextProperties.setProperty(OTMContextFactory.PREFIX_MAP,
                        prefixes);

                fileNameBuilder.setLength(0);
                fileNameBuilder.append(javaOutputFolder);
                fileNameBuilder.append("/"
                        + JavaCodeGenerator.CONTEXT_PROPERTIES_DIRECTORY);
                File metaInf = new File(fileNameBuilder.toString());
                if (!metaInf.exists()) {
                    metaInf.mkdirs();
                }
                fileNameBuilder.append("/" + CONTEXT_PROPERTIES_FILENAME);
                File contextPropertiesFile = new File(
                        fileNameBuilder.toString());
                try (FileOutputStream contextPropertiesFileStream = new FileOutputStream(
                        contextPropertiesFile)) {
                    contextProperties.store(contextPropertiesFileStream,
                            "OTMContext Properties File");
                    addGeneratedFile(contextPropertiesFile);
                }
            } catch (IOException e) {
                throw new JavaCodeGenerationException(e);
            }
        }
        return contextProperties;
    }

    private String getPrefixes(Map<String, String> uriPrefixMap) {
        StringBuilder sb = new StringBuilder();
        Iterator<Entry<String, String>> entryIt = uriPrefixMap.entrySet().iterator();
        while (entryIt.hasNext()) {
            sb.append(entryIt.next().toString());
            if (entryIt.hasNext()) {
                sb.append(OTMContextFactory.PROPERTY_SEPERATOR);
            }
        }
        return sb.toString();
    }

    private String getSchemas(String schemaOutputFolder2) {
        StringBuilder schemaListBuilder = new StringBuilder();
        File schemaFolder = new File(schemaOutputFolder + "/schemas");
        if (schemaFolder != null) {
            File[] files = schemaFolder.listFiles(new FilenameFilter() {

                @Override
                public boolean accept(File dir, String name) {
                    return name.endsWith(".xsd");
                }
            });
            boolean isFirst = true;
            for (File file : files) {
                if (isFirst) {
                    isFirst = false;
                } else {
                    schemaListBuilder.append(";");
                }
                schemaListBuilder.append("schemas/" + file.getName());

            }
        }
        return schemaListBuilder.toString();
    }

    private String createContextPath(Set<String> packages) {
        StringBuilder contextPathBuilder = new StringBuilder();
        Iterator<String> iter = packages.iterator();
        while (iter.hasNext()) {
            contextPathBuilder.append(iter.next());
            if (iter.hasNext()) {
                contextPathBuilder.append(":");
            }
        }
        return contextPathBuilder.toString();
    }

    private void addJaxbProperties(String pkg, String outputFolderPath)
            throws IOException {
        fileNameBuilder.setLength(0);
        fileNameBuilder.append(outputFolderPath);
        fileNameBuilder.append(File.separator);
        fileNameBuilder.append(pkg.replace(".", File.separator));
        fileNameBuilder.append(File.separator);
        fileNameBuilder.append(JAXB_PROPERTIES_FILE_NAME);
        File jaxbPropertiesFile = new File(fileNameBuilder.toString());
        try (FileWriter writer = new FileWriter(jaxbPropertiesFile);) {
            writer.write(JAXB_CONTEXT_FACTORY_PROPERTY);
            writer.flush();
            addGeneratedFile(jaxbPropertiesFile);
        }
    }

    /**
     * Returns a code generation context to be used for the generation of Java
     * source code.
     *
     * @return CodeGenerationContext
     */
    @Override
    protected CodeGenerationContext createContext() {
        CodeGenerationContext context = new CodeGenerationContext();
        context.setValue(CodeGenerationContext.CK_OUTPUT_FOLDER,
                getOutputFolder());
        return context;
    }

    /**
     * @see org.opentravel.schemacompiler.task.CommonCompilerTaskOptions#applyTaskOptions(org.opentravel.schemacompiler.task.CommonCompilerTaskOptions)
     */
    @Override
    public void applyTaskOptions(CommonCompilerTaskOptions taskOptions) {
        if (taskOptions instanceof JavaCompileTaskOptions) {
            JavaCompileTaskOptions compileOptions = (JavaCompileTaskOptions) taskOptions;
            setOutputFolder(compileOptions.getJavaOutputFolder());
            generateBuilders = compileOptions.isGenerateBuilders();
            schemaClasspathLocation = compileOptions
                    .getSchemaClasspathLocation();
            if (null == schemaClasspathLocation) {
                schemaClasspathLocation = DEFAULT_SCHEMA_FOLDER;
            }
            converterBindingFile = compileOptions.getConverterBindingFile();
        }

        schemaOutputFolder = taskOptions.getOutputFolder();

    }

    /*
     * (non-Javadoc)
     *
     * @see
     * org.opentravel.schemacompiler.task.AbstractCompilerTask#generateOutput
     * (java.util.Collection, java.util.Collection)
     */
    @Override
    protected void generateOutput(Collection<TLLibrary> userDefinedLibraries,
                                  Collection<XSDLibrary> legacySchemas)
            throws SchemaCompilerException {
    }

}
