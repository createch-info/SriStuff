/**
 *
 */
package com.travelport.otm.compiler.task;

import org.opentravel.schemacompiler.codegen.CodeGenerator;
import org.opentravel.schemacompiler.codegen.CodeGeneratorFactory;
import org.opentravel.schemacompiler.model.TLLibrary;
import org.opentravel.schemacompiler.model.TLModel;
import org.opentravel.schemacompiler.model.XSDLibrary;
import org.opentravel.schemacompiler.task.AbstractCompilerTask;
import org.opentravel.schemacompiler.util.SchemaCompilerException;
import org.opentravel.schemacompiler.validate.ValidationFindings;

import java.util.Collection;

/**
 * @author Eric.Bronson
 */
public class DocumentationCompileTask extends AbstractCompilerTask {

    public static final String CODE_GENERATOR_FACTORY = "javaCodeGeneratorFactory";
    private static final String HTML = "HTML";

    /**
     * Default Constructor
     */
    public DocumentationCompileTask() {
    }

    /**
     * Validates an existing <code>TLModel</code> instance and compiles the output using the options
     * assigned for this task.
     *
     * @param model the model that contains all of the libraries for which to compile output
     * @return ValidationFindings
     * @throws SchemaCompilerException thrown if an unexpected error occurs during the compilation process
     */
    public ValidationFindings compileOutput(TLModel model) throws SchemaCompilerException {
        CodeGenerator<TLModel> docGenerator = CodeGeneratorFactory.getInstance(CODE_GENERATOR_FACTORY).newCodeGenerator(
                HTML, TLModel.class);
        docGenerator.generateOutput(model, createContext());
        return null;
    }

    /* (non-Javadoc)
     * @see org.opentravel.schemacompiler.task.AbstractCompilerTask#generateOutput(java.util.Collection, java.util.Collection)
     */
    @Override
    protected void generateOutput(Collection<TLLibrary> userDefinedLibraries,
                                  Collection<XSDLibrary> legacySchemas)
            throws SchemaCompilerException {

    }

}
