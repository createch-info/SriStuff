package com.travelport.otm.compiler.task;

public interface JavaCompileTaskOptions {

    /**
     * Returns the generated java output folder location as either an absolute or relative URL string.
     *
     * @return String
     */
    public String getJavaOutputFolder();

    /**
     * Should web service classes be generated.
     *
     * @return String
     */
    public boolean isCompileServices();

    /**
     * Should builder classes be generated.
     *
     * @return String
     */
    public boolean isGenerateBuilders();

    /**
     * Returns the option flag indicating that ModelDoc files should be generated.
     *
     * @return boolean
     */
    public boolean isGenerateModelDoc();

    /**
     * Schema Classpath Location.
     *
     * @return String
     */
    public String getSchemaClasspathLocation();

    /**
     * The version binding file.
     *
     * @return String
     */
    public String getConverterBindingFile();


}
