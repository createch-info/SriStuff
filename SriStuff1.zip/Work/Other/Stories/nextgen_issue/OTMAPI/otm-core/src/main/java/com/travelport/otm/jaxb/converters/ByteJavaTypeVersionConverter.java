package com.travelport.otm.jaxb.converters;

public class ByteJavaTypeVersionConverter extends
        OTMJavaTypeConverter<Byte, String> {

    /*
     * (non-Javadoc)
     *
     * @see
     * com.travelport.otm.jaxb.OTMVersionConverter#marshall(java.lang.Object,
     * java.lang.String)
     */
    @Override
    public String marshall(Byte field, String version, Object parent) {
        return String.valueOf(field);
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * com.travelport.otm.jaxb.OTMVersionConverter#unmarshall(java.lang.Object,
     * java.lang.String)
     */
    @Override
    public Byte unmarshall(String value, String version, Object parent) {
        Byte returnValue;
        try {
            returnValue = Byte.parseByte(value);
        } catch (Exception e) {
            returnValue = Byte.parseByte(this.defaultValue.toString());
        }
        return returnValue;
    }

    /**
     * @param defaultValue the defaultValue to set
     */
    public void setDefaultValue(Byte defaultValue) {
        this.defaultValue = defaultValue;
    }

    @Override
    public boolean isConvertible(Class<?> actual, Class<?> temp) {
        return actual.equals(Byte.class) && temp.equals(String.class);
    }

}
