/**
 *
 */
package com.travelport.otm.jaxb.converters;

/**
 * @author Eric.Bronson
 */
public class DoubleJavaTypeVersionConverter extends
        OTMJavaTypeConverter<Double, String> {

    /*
     * (non-Javadoc)
     *
     * @see
     * com.travelport.otm.jaxb.OTMVersionConverter#marshall(java.lang.Object,
     * java.lang.String)
     */
    @Override
    public String marshall(Double field, String version, Object parent) {
        return String.valueOf(field);
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * com.travelport.otm.jaxb.OTMVersionConverter#unmarshall(java.lang.Object,
     * java.lang.String)
     */
    @Override
    public Double unmarshall(String value, String version, Object parent) {
        Double returnValue;
        try {
            returnValue = Double.parseDouble(value);
        } catch (Exception e) {
            returnValue = Double.parseDouble(this.defaultValue.toString());
        }
        return returnValue;
    }

    /**
     * @param defaultValue the defaultValue to set
     */
    public void setDefaultValue(Double defaultValue) {
        this.defaultValue = defaultValue;
    }

    @Override
    public boolean isConvertible(Class<?> actual, Class<?> other) {
        return actual.equals(Double.class) && other.equals(String.class);
    }
}
