package com.travelport.otm.jaxb.converters;

public class IntegerJavaTypeVersionConverter extends
        OTMJavaTypeConverter<Integer, String> {

    /* (non-Javadoc)
     * @see com.travelport.otm.jaxb.OTMVersionConverter#marshall(java.lang.Object, java.lang.String)
     */
    @Override
    public String marshall(Integer field, String version, Object parent) {
        return String.valueOf(field);
    }

    /* (non-Javadoc)
     * @see com.travelport.otm.jaxb.OTMVersionConverter#unmarshall(java.lang.Object, java.lang.String)
     */
    @Override
    public Integer unmarshall(String value, String version, Object parent) {
        Integer returnValue;
        try {
            returnValue = Integer.parseInt(value);
        } catch (Exception e) {
            returnValue = Integer.parseInt(this.defaultValue.toString());
        }
        return returnValue;
    }

    /**
     * @param defaultValue the defaultValue to set
     */
    public void setDefaultValue(Integer defaultValue) {
        this.defaultValue = defaultValue;
    }

    @Override
    public boolean isConvertible(Class<?> actual, Class<?> other) {
        return actual.equals(Integer.class) && other.equals(String.class);
    }
}
