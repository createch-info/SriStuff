/**
 *
 */
package com.travelport.otm.jaxb.converters;

import com.sun.xml.bind.v2.runtime.IllegalAnnotationsException;
import com.travelport.otm.core.VersionMappingsLoader;
import com.travelport.otm.core.exception.CoreRuntimeException;
import com.travelport.otm.jaxb.model.runtime.RuntimeEnumLeafInfo;
import com.travelport.otm.jaxb.runtime.OTMJAXBContext;
import com.travelport.otm.jaxb.runtime.Transducer;
import com.travelport.otm.sourcegen.versioning.model.EnumGraph;
import com.travelport.otm.sourcegen.versioning.model.JavaType;
import com.travelport.otm.sourcegen.versioning.model.VersionGraph;

import java.util.ArrayList;
import java.util.List;

/**
 * @param <E>
 * @author Eric.Bronson
 */
public class DefaultClosedEnumConverter<E extends Enum<E>> extends
        ClosedEnumConverter<E> {

    private List<Enum> values = new ArrayList<>();

    private Transducer transducer = null;

    private Class closedEnum;

    public DefaultClosedEnumConverter(Class<E> closedEnum,
                                      VersionMappingsLoader mappingsLoader, String version,
                                      String defaultValue, OTMJAXBContext context) {
        this.closedEnum = closedEnum;
        setDefaultValue(Enum.valueOf(closedEnum, defaultValue));
        JavaType jt = mappingsLoader.getJavaTypeForClass(closedEnum);

        for (VersionGraph vog : jt.getVersionGraphs()) {
            if (vog instanceof EnumGraph) {
                String v = vog.getName();
                generateEnums(version, v, vog);
            }
        }
        try {
            for (RuntimeEnumLeafInfo e : context.getTypeInfoSet().enums()
                    .values()) {
                if (e.getClazz().equals(closedEnum)) {
                    transducer = (Transducer) e;
                    break;
                }
            }
        } catch (IllegalAnnotationsException e1) {
            throw new CoreRuntimeException(e1.getMessage(), e1);
        }
        if (null == transducer) {
            throw new IllegalArgumentException(String.format(
                    "Enum %s is not known to this context.",
                    closedEnum.getName()));
        }
    }

    private void generateEnums(String version, String v, VersionGraph vog) {
        if (v.equals(version)) {
            List<Enum> enumValues = new ArrayList<>();
            for (String node : ((EnumGraph) vog).getValues()) {
                enumValues.add(Enum.valueOf(closedEnum, node));
            }
            this.values = enumValues;
        }
    }

    @Override
    public E marshall(E field, String version, Object parent) {
        E value = field;
        if (value != null && !values.contains(value)) {
            //TODO why are we doing the conversion again here?
            value = (E) Enum.valueOf(closedEnum, (String) defaultValue);
        }
        return value;
    }

    @Override
    public E unmarshall(E value, String version, Object parent) {
        return value;
    }

}