/**
 *
 */
package com.travelport.otm.jaxb.converters;

import org.springframework.beans.BeanUtils;

import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.List;

/**
 * DefaultFacetTypeConverter used in major versioning when
 * a new facet added in higher version
 *
 * @param <X>
 * @param <Y>
 * @author Eric.Bronson
 */
public class DefaultFacetTypeConverter extends
        OTMVersionConverter<Object, Object> {

    private final List<Class<?>> allowedClasses;

    private final Class<?> defaultClass;

    /**
     * @param defaultClass   runtime class
     * @param allowedClasses the class and the its subclass
     */
    public DefaultFacetTypeConverter(Class<?> defaultClass,
                                     List<Class<?>> allowedClasses) {
        this.defaultClass = defaultClass;
        this.allowedClasses = Collections.unmodifiableList(allowedClasses);
    }

    @Override
    public Object marshall(Object field, String version, Object parent) {
        Object obj = field; // field is the required object to be processed
        if (!allowedClasses.contains(obj.getClass())) {
            try {
                obj = morph(field, defaultClass.newInstance());
            } catch (InstantiationException | IllegalAccessException | InvocationTargetException e) {
                obj = null;
            }
        }
        return obj;
    }

    @Override
    public Object unmarshall(Object value, String version, Object parent) {
        return value;
    }

    /**
     * Copies the properties from destination to source
     *
     * @param source
     * @param destination
     * @return
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */
    protected Object morph(Object source, Object destination) throws IllegalAccessException, InvocationTargetException {
        BeanUtils.copyProperties(source, destination);
        return destination;
    }

}
