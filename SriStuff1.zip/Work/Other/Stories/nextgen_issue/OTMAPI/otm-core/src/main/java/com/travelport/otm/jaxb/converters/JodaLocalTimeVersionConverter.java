package com.travelport.otm.jaxb.converters;

import org.joda.time.LocalTime;

/**
 * @author jason.kramer
 */
public class JodaLocalTimeVersionConverter extends
        OTMJavaTypeConverter<LocalTime, String> {

    /* (non-Javadoc)
    * @see com.travelport.otm.jaxb.OTMVersionConverter#marshall(java.lang.Object, java.lang.String)
    */
    @Override
    public String marshall(LocalTime field, String version, Object parent) {
        return String.valueOf(field);
    }

    /* (non-Javadoc)
    * @see com.travelport.otm.jaxb.OTMVersionConverter#unmarshall(java.lang.Object, java.lang.String)
    */
    @Override
    public LocalTime unmarshall(String value, String version, Object parent) {
        LocalTime returnValue;

        try {
            returnValue = new LocalTime(value);
        } catch (Exception e) {
            returnValue = LocalTime.parse(this.defaultValue.toString());
        }
        return returnValue;
    }

    /**
     * @param defaultValue the defaultValue to set
     */
    public void setDefaultValue(LocalTime defaultValue) {
        this.defaultValue = defaultValue;
    }

    @Override
    public boolean isConvertible(Class<?> actual, Class<?> other) {
        return actual.equals(LocalTime.class) && other.equals(String.class);
    }
}
