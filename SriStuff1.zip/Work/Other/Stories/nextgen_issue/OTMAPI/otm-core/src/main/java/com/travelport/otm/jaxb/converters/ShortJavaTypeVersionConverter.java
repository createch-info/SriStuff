package com.travelport.otm.jaxb.converters;

public class ShortJavaTypeVersionConverter extends
        OTMJavaTypeConverter<Short, String> {

    /* (non-Javadoc)
    * @see com.travelport.otm.jaxb.OTMVersionConverter#marshall(java.lang.Object, java.lang.String)
    */
    @Override
    public String marshall(Short field, String version, Object parent) {
        return String.valueOf(field);
    }

    /* (non-Javadoc)
    * @see com.travelport.otm.jaxb.OTMVersionConverter#unmarshall(java.lang.Object, java.lang.String)
    */
    @Override
    public Short unmarshall(String value, String version, Object parent) {
        Short returnValue;
        try {
            returnValue = Short.parseShort(value);
        } catch (Exception e) {
            returnValue = Short.parseShort(this.defaultValue.toString());
        }
        return returnValue;
    }

    /**
     * @param defaultValue the defaultValue to set
     */
    public void setDefaultValue(Short defaultValue) {
        this.defaultValue = defaultValue;
    }

    @Override
    public boolean isConvertible(Class<?> actual, Class<?> other) {
        return actual.equals(Short.class) && other.equals(String.class);
    }

}
