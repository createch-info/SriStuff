package com.travelport.otm.jaxb.converters;

public class BooleanJavaTypeVersionConverter extends
        OTMJavaTypeConverter<Boolean, String> {

    /*
     * (non-Javadoc)
     *
     * @see
     * com.travelport.otm.jaxb.OTMVersionConverter#marshall(java.lang.Object,
     * java.lang.String)
     */
    @Override
    public String marshall(Boolean field, String version, Object parent) {
        return String.valueOf(field);
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * com.travelport.otm.jaxb.OTMVersionConverter#unmarshall(java.lang.Object,
     * java.lang.String)
     */
    @Override
    public Boolean unmarshall(String value, String version, Object parent) {
        Boolean returnValue = true;
        try {
            returnValue = Boolean.parseBoolean(value);
        } catch (Exception e) {
            returnValue = (Boolean) this.defaultValue;
        }
        return returnValue;
    }

    /**
     * @param defaultValue the defaultValue to set
     */
    public void setDefaultValue(Boolean defaultValue) {
        this.defaultValue = defaultValue;
    }

    @Override
    public boolean isConvertible(Class<?> actual, Class<?> other) {
        return actual.equals(Boolean.class) && other.equals(String.class);
    }

}
