/**
 *
 */
package com.travelport.otm.jaxb.converters;

/**
 * RequiredValueConverter provides default value for mandatory property
 * in the case of major version change
 *
 * @author Eric.Bronson
 */
public class RequiredValueConverter extends
        OTMVersionConverter<Object, Object> {

    /**
     * Uses the default value to set in the mandatory field
     */
    @Override
    public Object marshall(Object field, String version, Object parent) {
        Object value = field;
        if (null == value) {
            value = getDefaultValue();
        }
        return value;
    }

    /**
     *
     */
    @Override
    public Object unmarshall(Object value, String version, Object parent) {
        // do we need this ?
        return value;
    }
}
