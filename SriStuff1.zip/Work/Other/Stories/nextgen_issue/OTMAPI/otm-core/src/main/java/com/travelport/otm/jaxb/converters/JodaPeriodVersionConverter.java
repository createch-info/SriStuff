package com.travelport.otm.jaxb.converters;

import org.joda.time.Period;

/**
 * @author jason.kramer
 */
public class JodaPeriodVersionConverter extends
        OTMJavaTypeConverter<Period, String> {

    /* (non-Javadoc)
    * @see com.travelport.otm.jaxb.OTMVersionConverter#marshall(java.lang.Object, java.lang.String)
    */
    @Override
    public String marshall(Period field, String version, Object parent) {
        return String.valueOf(field);
    }

    /* (non-Javadoc)
    * @see com.travelport.otm.jaxb.OTMVersionConverter#unmarshall(java.lang.Object, java.lang.String)
    */
    @Override
    public Period unmarshall(String value, String version, Object parent) {
        Period returnValue;

        try {
            returnValue = new Period(value);
        } catch (Exception e) {
            returnValue = Period.parse(this.defaultValue.toString());
        }
        return returnValue;
    }

    /**
     * @param defaultValue the defaultValue to set
     */
    public void setDefaultValue(Period defaultValue) {
        this.defaultValue = defaultValue;
    }

    @Override
    public boolean isConvertible(Class<?> actual, Class<?> other) {
        return actual.equals(Period.class) && other.equals(String.class);
    }
}
