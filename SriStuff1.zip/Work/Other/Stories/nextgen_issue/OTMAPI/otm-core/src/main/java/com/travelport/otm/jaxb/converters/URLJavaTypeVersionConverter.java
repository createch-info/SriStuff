package com.travelport.otm.jaxb.converters;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * @author jason.kramer
 */
public class URLJavaTypeVersionConverter extends
        OTMJavaTypeConverter<URL, String> {

    /* (non-Javadoc)
    * @see com.travelport.otm.jaxb.OTMVersionConverter#marshall(java.lang.Object, java.lang.String)
    */
    @Override
    public String marshall(URL field, String version, Object parent) {
        return String.valueOf(field);
    }

    /* (non-Javadoc)
    * @see com.travelport.otm.jaxb.OTMVersionConverter#unmarshall(java.lang.Object, java.lang.String)
    */
    @Override
    public URL unmarshall(String value, String version, Object parent) {
        URL returnValue;

        try {
            returnValue = new URL(value);
        } catch (Exception e) {
            try {
                returnValue = new URL(this.defaultValue.toString());
            } catch (MalformedURLException e1) {
                returnValue = null;
            }
        }
        return returnValue;
    }

    /**
     * @param defaultValue the defaultValue to set
     */
    public void setDefaultValue(URL defaultValue) {
        this.defaultValue = defaultValue;
    }

    @Override
    public boolean isConvertible(Class<?> actual, Class<?> other) {
        return actual.equals(URL.class) && other.equals(String.class);
    }
}
