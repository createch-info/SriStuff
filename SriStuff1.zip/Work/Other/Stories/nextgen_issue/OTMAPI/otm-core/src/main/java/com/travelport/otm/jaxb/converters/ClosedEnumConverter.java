/**
 *
 */
package com.travelport.otm.jaxb.converters;

/**
 * @param <E>
 * @author Eric.Bronson
 */
public abstract class ClosedEnumConverter<E extends Enum<?>> extends OTMVersionConverter<E, E> {

}
