/**
 *
 */
package com.travelport.otm.jaxb.converters;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;


/**
 * @author Eric.Bronson
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({FIELD, METHOD, TYPE})
public @interface OTMConverter {

    OTMConverterType type();

    Class<?> clazz() default DEFAULT.class;

    String toVersion() default "";

    String fromVersion() default "";

    String defaultValue() default "";

    public static final class DEFAULT {
    }
}
