/**
 *
 */
package com.travelport.otm.jaxb.converters;

import com.travelport.otm.core.exception.CoreRuntimeException;
import org.springframework.beans.BeanUtils;

/**
 * @author Eric.Bronson
 */
public class OpenToClosedEnumBaseConverter extends OpenEnumConverter {

    @SuppressWarnings("rawtypes")
    protected OpenToClosedEnumConverter<Enum> converter;
    protected boolean currentOpen = false;

    /**
     * To XML
     */
    @Override
    public Object marshall(Object field, String parentVersion, Object parent) {
        Object obj = parent;
        Enum<?> value;
        try {
            value = (Enum<?>) enumField.get(parent);
            if (value != null && !allowedValues.contains(value)) {
                BeanUtils.copyProperties(parent, obj);
                String extObj = (String) extensionField.get(parent);
                value = converter.marshall(value, parentVersion, extObj);
                enumField.set(obj, value);
                extensionField.set(obj, null);
            } else if (allowedValues.contains(value) && !isCurrentOpen()) {
                BeanUtils.copyProperties(parent, obj);
                enumField.set(obj, value);
                extensionField.set(obj, null);
            }
        } catch (Exception e1) {
            // -TODO: Do we want to handle this differently in the future?
            throw new CoreRuntimeException(e1.getMessage(), e1);
        }

        return obj;
    }


    /**
     * To Java object
     */
    @Override
    public Object unmarshall(Object field, String parentVersion, Object parent) {

        Enum<?> value;
        String ext;

        try {
            value = (Enum<?>) enumField.get(parent);
            if (value != null && !highestVersionValues.contains(value)) {
                ext = (String) extensionField.get(parent);
                if (ext != null) {
                    Enum<?> extValue = (Enum<?>) transducer.parse(ext);
                    setFields(extValue, parent);
                }
            }
        } catch (Exception e) {
            // -TODO: Do we want to handle this differently in the future?
            throw new CoreRuntimeException(e.getMessage(), e);
        }

        return parent;
    }

    private void setFields(Enum<?> extValue, Object parent) throws IllegalArgumentException, IllegalAccessException {
        if (extValue != null && highestVersionValues.contains(extValue)) {
            extensionField.set(parent, null);
            enumField.set(parent, extValue);
        }
    }

    @SuppressWarnings("rawtypes")
    public OpenToClosedEnumConverter<Enum> getConverter() {
        return converter;
    }

    @SuppressWarnings("rawtypes")
    public void setConverter(OpenToClosedEnumConverter<Enum> converter) {
        this.converter = converter;
    }

    public boolean isCurrentOpen() {
        return currentOpen;
    }

    public void setCurrentOpen(boolean currentOpen) {
        this.currentOpen = currentOpen;
    }

}