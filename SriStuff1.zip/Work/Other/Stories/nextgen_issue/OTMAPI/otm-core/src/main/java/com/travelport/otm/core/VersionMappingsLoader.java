/**
 *
 */
package com.travelport.otm.core;

import com.sun.xml.bind.v2.ContextFactory;
import com.travelport.otm.core.exception.VersionMappingException;
import com.travelport.otm.sourcegen.versioning.model.JavaType;
import com.travelport.otm.sourcegen.versioning.model.VersionBinding;
import com.travelport.otm.sourcegen.versioning.model.VersionBindings;
import com.travelport.otm.sourcegen.versioning.model.VersionGraph;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;
import java.io.IOException;
import java.net.URL;
import java.util.*;

// SonarQube should really only penalize usage of sun.* package or whatever is internally used
//by an arbitrary JRE/JDK implementation. The com.sun.* package is not JRE/JDK API/impl related at all.

/**
 * The VersionMappingsLoader provides the details of the version mappings which
 * has all the details about the properties of each class. Property node and
 * enum graph details from the version mappings is used to construct the
 * respective classes for processing the properties.
 *
 * @author Eric.Bronson
 */
public class VersionMappingsLoader {

    private static VersionMappingsLoader instance;
    private static VersionBindings bindings;
    // TODO dereference these after build phase?
    private Map<Class<?>, JavaType> versionTypeMap = new HashMap<>();

    private VersionMappingsLoader() {
        loadBindings();
    }

    public static synchronized VersionMappingsLoader getInstance() {
        if (null == instance) {
            instance = new VersionMappingsLoader();
        }
        return instance;
    }

    private static void loadBindings() {
        Enumeration<URL> systemResources;
        try {
            systemResources = Thread.currentThread().getContextClassLoader()
                    .getResources("META-INF/com.travelport.otm.versionMappings.xml");

            JAXBContext context = ContextFactory.createContext("com.travelport.otm.sourcegen.versioning.model",
                    Thread.currentThread().getContextClassLoader(), null);
            Unmarshaller unm = context.createUnmarshaller();
            while (systemResources.hasMoreElements()) {
                StreamSource source = new StreamSource(systemResources.nextElement().openStream());
                VersionBindings vbs = (VersionBindings) unm.unmarshal(source);
                if (null == bindings) {
                    bindings = vbs;
                } else {
                    bindings.getBindings().addAll(vbs.getBindings());
                }

            }
        } catch (IOException | JAXBException e) {
            throw new VersionMappingException(e);
        }
    }

    /**
     * Returns the JavaType for given class which contains details about the
     * property nodes of each version of the class
     *
     * @param c - class to get the java type
     * @return
     */
    public JavaType getJavaTypeForClass(Class<?> c) {
        if (bindings == null || c == null) {
            return null;
        }
        JavaType jt = null;
        if (!c.isPrimitive()) {
            jt = versionTypeMap.get(c);
            if (null == jt) {
                for (VersionBinding vb : bindings.getBindings()) {
                    jt = matchJavaType(vb, c, jt);
                }
            }
            versionTypeMap.put(c, jt);
        }

        return jt;
    }

    private JavaType matchJavaType(VersionBinding vb, Class<?> c, JavaType jt) {
        if (vb.getPackageName().equals(c.getPackage().getName())) {
            for (JavaType javaType : vb.getJavaTypes()) {
                if (javaType.getName().equals(c.getSimpleName())) {
                    jt = javaType;
                    break;
                }
            }
        }
        return jt;
    }

    /**
     * Gets the set of version/s for the supplied class
     *
     * @param c - class to fetch the version
     * @return
     */
    public Set<String> getVersionsForClass(Class<?> c) {
        Set<String> versions = new HashSet<>();
        JavaType jt = getJavaType(c);
        if (jt != null) {
            for (VersionGraph graph : jt.getVersionGraphs()) {
                versions.add(graph.getName());
            }
        }
        return versions;
    }

    private JavaType getJavaType(Class<?> c) {
        JavaType jt = versionTypeMap.get(c);
        if (null == jt) {
            jt = getJavaTypeForClass(c);
        }
        return jt;
    }

    public boolean isVersioned(Class<?> c) {
        JavaType jt = getJavaType(c);
        return jt != null;
    }

    public VersionGraph getVersionGraph(String name, Class<?> c) {
        VersionGraph vg = null;
        JavaType jt = getJavaType(c);
        if (jt != null) {
            for (VersionGraph graph : jt.getVersionGraphs()) {
                if (graph.getName().equals(name)) {
                    vg = graph;
                    break;
                }
            }
        }
        return vg;
    }

    public VersionGraph getHighestVersion(Class<?> c) {
        VersionGraph vg = null;
        String highestVersion = null;
        JavaType jt = getJavaType(c);
        if (jt != null) {
            for (VersionGraph graph : jt.getVersionGraphs()) {
                String v = graph.getName();
                if (VersionUtils.isHigherVersion(v, highestVersion)) {
                    highestVersion = v;
                    vg = graph;
                }
            }
        }
        return vg;
    }

}
