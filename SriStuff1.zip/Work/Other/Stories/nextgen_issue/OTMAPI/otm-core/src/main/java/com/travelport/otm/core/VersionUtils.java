/*
 * Copyright (c) 2016, Travelport.  All Rights Reserved.
 * Use is subject to license agreement.
 * 
 * CHANGELOG:
 *
 * DATE				NAME				STORY			DESCRIPTION
 *
 * Oct 04, 2016		joseph.savariraj	ODT-229			ExtensionPoint Unmarshalling JSON
 */
package com.travelport.otm.core;

import com.sun.xml.bind.v2.model.annotation.AnnotationSource;
import com.travelport.otm.core.exception.OTMException;
import com.travelport.otm.jaxb.converters.*;
import com.travelport.otm.jaxb.runtime.OTMVersionListener;
import com.travelport.otm.jaxb.runtime.reflect.VersionListener;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// SonarQube should really only penalize usage of sun.* package or whatever is internally used
//by an arbitrary JRE/JDK implementation. The com.sun.* package is not JRE/JDK API/impl related at all.


/**
 * VersionUtils provide methods to find the highest version, getting the version
 * from namespace, getting the listener, JavaType converter and list of version
 * converters
 *
 * @author Eric.Bronson
 */
public abstract class VersionUtils {
    private static final Pattern versionPattern = Pattern
            .compile("(\\d+)(?:\\_(\\d+))?(?:\\_(\\d+))?");
    private static final Pattern nsVersionPattern = Pattern.compile("/v"
            + versionPattern.pattern());

    // Adding a private constructor to hide the implicit public one
    private VersionUtils() {
    }

    /**
     * Determine if version1 is a higher version than version2.
     *
     * @param version1
     * @param version2
     * @return
     */
    public static boolean isHigherVersion(String version1, String version2) {
        int ver1 = -1;
        int ver2 = -1;
        if (version1 != null) {
            int[] ver1Parts = splitVersionIdentifier(version1);
            StringBuilder strNum1 = new StringBuilder();
            for (int num : ver1Parts) {
                strNum1.append(num);
            }
            ver1 = Integer.parseInt(strNum1.toString());
        }
        if (version2 != null) {
            int[] ver2Parts = splitVersionIdentifier(version2);
            StringBuilder strNum2 = new StringBuilder();
            for (int num : ver2Parts) {
                strNum2.append(num);
            }
            ver2 = Integer.parseInt(strNum2.toString());
        }
        return ver1 > ver2;
    }

    /**
     * Fetches the version (major, minor and patch) into parts.
     *
     * @param versionIdentifier Ex: 1.1.2, 3.2.1
     * @return Each index has the version part.
     */
    public static int[] splitVersionIdentifier(String versionIdentifier) {
        Matcher m = versionPattern.matcher(versionIdentifier);
        int[] versionParts = null;
        try {
            if (m.matches()) {
                versionParts = new int[3];

                for (int i = 0; i < 3; i++) {
                    String versionPart = m.group(i + 1);
                    versionParts[i] = Integer.parseInt((versionPart == null) ? "0"
                            : versionPart);
                }
            } else {
                versionParts = new int[]{0, 0, 0};
            }
        } catch (StackOverflowError e) {
            System.out.println("OVERFLOW! " + e);
            System.out.println("VersionID " + versionIdentifier);
        }
        return versionParts;
    }

    public static String getVersionFromNamespace(String namespace) {
        String version = null;
        Matcher matcher = nsVersionPattern.matcher(namespace);
        if (matcher.find()) {
            version = namespace.substring(matcher.start(0) + 2, matcher.end(0));
        }
        return version;
    }

    /**
     * Gets the list of OTMVersion converter from the annotation OTMConverter/s
     * for the given property
     *
     * @param prop
     * @return
     */
    @SuppressWarnings({"rawtypes"})
    public static List<OTMVersionConverter> getConverterList(
            AnnotationSource prop) throws OTMException {
        List<OTMVersionConverter> otmVersionConverterList = new ArrayList<>();

        OTMConverters otmConverters = prop.readAnnotation(OTMConverters.class);
        if (otmConverters != null) {
            for (OTMConverter verConverter : otmConverters.value()) {
                otmVersionConverterList
                        .add(getOTMVersionConverter(verConverter));
            }
        }
        OTMConverter otmConverter = prop.readAnnotation(OTMConverter.class);
        if (otmConverter != null) {
            otmVersionConverterList.add(getOTMVersionConverter(otmConverter));
        }

        return otmVersionConverterList;
    }

    /**
     * Instantiates an OTMVersionConverter
     *
     * @param verConverter
     * @return
     */
    @SuppressWarnings({"rawtypes"})
    public static OTMVersionConverter getOTMVersionConverter(
            OTMConverter verConverter) throws OTMException {
        OTMVersionConverter otmVerConverter = null;
        try {
            otmVerConverter = (OTMVersionConverter) verConverter.clazz()
                    .newInstance();
            if (verConverter.type() != null) {
                otmVerConverter.setType(verConverter.type());
            }

            if (verConverter.defaultValue() != null) {
                otmVerConverter.setDefaultValue(verConverter.defaultValue());
            }

        } catch (InstantiationException | IllegalAccessException e) {
            throw new OTMException(e.getMessage(), e);
        }
        return otmVerConverter;
    }

    /**
     * Instantiates a JavaType Converter
     *
     * @param otmVersionConverterList
     * @param myType                  the node type
     * @param iType
     * @return
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public static OTMJavaTypeConverter getJavaTypeConverter(
            List<OTMVersionConverter> otmVersionConverterList, Type myType,
            Type iType) {

        OTMJavaTypeConverter otmJavaTypeConverter = null;

        for (OTMVersionConverter otmVersionConverter : otmVersionConverterList) {
            if (otmVersionConverter instanceof OTMJavaTypeConverter
                    && ((OTMJavaTypeConverter) otmVersionConverter)
                    .isConvertible(myType.getClass(), iType.getClass())) {
                otmJavaTypeConverter = (OTMJavaTypeConverter) otmVersionConverter;
            }
        }

        return otmJavaTypeConverter;
    }

    /**
     * @param clazz
     * @return
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    public static OTMVersionListener<?> getVersionListener(Class<?> clazz)
            throws InstantiationException, IllegalAccessException {
        VersionListener versionListener = clazz
                .getAnnotation(VersionListener.class);
        OTMVersionListener<?> listener = null;
        Class<?> vl = null;
        if (versionListener != null) {
            vl = versionListener.value();
            listener = (OTMVersionListener<?>) vl.newInstance();
            if (listener == null) {
                clazz = clazz.getSuperclass();
                versionListener = clazz.getAnnotation(VersionListener.class);
                vl = versionListener.value();
                listener = (OTMVersionListener<?>) vl.newInstance();
            }
        } else {
            clazz = clazz.getSuperclass();
            if (clazz != null) {
                versionListener = clazz.getAnnotation(VersionListener.class);
                if (versionListener != null) {
                    vl = versionListener.value();
                    listener = (OTMVersionListener<?>) vl.newInstance();
                }
            }
        }

        return listener;
    }

    /**
     * @param className
     * @return
     * @throws ClassNotFoundException
     */
    public static Class<?> getClass(String className)
            throws ClassNotFoundException {
        Class<?> clazz = null;
        if ("boolean".equals(className)) {
            clazz = boolean.class;
        } else {
            clazz = Class.forName(className);
        }
        return clazz;
    }


    /**
     * @param enumType
     * @param isOpen
     * @return
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public static OpenEnumConverter getOpenEnumConverter(
            Class<? extends Enum> enumType, boolean isCurrentOpen, boolean isHighestOpen)
            throws OTMException {
        OpenEnumConverter enumConverter = null;
        OpenToClosedEnumConverter closedEnumConverter = null;

        if (isCurrentOpen && isHighestOpen) {
            enumConverter = new OpenEnumConverter();
        } else {
            OTMConverter otmConverter = enumType.getAnnotation(OTMConverter.class);

            if (otmConverter != null && OTMConverterType.ENUM.equals(otmConverter.type())) {
                try {
                    enumConverter = new OpenToClosedEnumBaseConverter();

                    closedEnumConverter = (OpenToClosedEnumConverter) otmConverter.clazz()
                            .newInstance();

                    if (closedEnumConverter != null) {
                        ((OpenToClosedEnumBaseConverter) enumConverter).setConverter(closedEnumConverter);
                        ((OpenToClosedEnumBaseConverter) enumConverter).setCurrentOpen(isCurrentOpen);
                        closedEnumConverter.setDefaultValue(Enum.valueOf(enumType, otmConverter.defaultValue()));
                        closedEnumConverter.setCurrentOpen(isCurrentOpen);
                    }
                    enumConverter.setType(otmConverter.type());

                } catch (InstantiationException | IllegalAccessException e) {
                    throw new OTMException(e.getMessage(), e);
                }
            }

        }

        return enumConverter;
    }

    public static boolean hasVersion(String namespace) {
        Matcher matcher = nsVersionPattern.matcher(namespace);
        return matcher.find();
    }
}
