/**
 *
 */
package com.travelport.otm.jaxb.converters;

import com.sun.xml.bind.v2.ClassFactory;
import com.travelport.otm.core.exception.CoreRuntimeException;
import com.travelport.otm.jaxb.runtime.Transducer;
import org.springframework.beans.BeanUtils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Eric.Bronson
 */
public class OpenEnumConverter extends OTMVersionConverter<Object, Object> {

    public static final String EXTENSION = "Extension";

    public static final String OTHER = "OTHER_";

    protected Enum<?> otherEnum;

    protected Field enumField;

    protected Field extensionField;

    @SuppressWarnings("rawtypes")
    protected List<Enum> allowedValues = new ArrayList<>();

    @SuppressWarnings("rawtypes")
    protected List<Enum> highestVersionValues = new ArrayList<>();

    protected Transducer<Enum<?>> transducer = null;

    /*
     * To avoid implicit public constructor
     *
     */
    public OpenEnumConverter() {

    }

    @Override
    public Object marshall(Object field, String parentVersion, Object parent) {
        Object obj = parent;
        Enum<?> value;
        try {
            value = (Enum<?>) enumField.get(parent);
            if (value != null && !allowedValues.contains(value)) {
                Object obj2 = ClassFactory.create(parent.getClass());
                BeanUtils.copyProperties(parent, obj2);
                obj = obj2;
                enumField.set(obj, otherEnum);
                extensionField.set(obj, transducer.print(value));
            }
        } catch (Exception e1) {
            // -TODO: Do we want to handle this differently in the future?
            throw new CoreRuntimeException(e1.getMessage(), e1);
        }

        return obj;
    }

    @Override
    public Object unmarshall(Object field, String version, Object parent) {
        String ext;
        try {
            ext = (String) extensionField.get(parent);
            if (ext != null) {
                Enum<?> extValue = (Enum<?>) transducer.parse(ext);
                if (extValue != null && highestVersionValues.contains(extValue)) {
                    extensionField.set(parent, null);
                    enumField.set(parent, extValue);
                }
            }
        } catch (Exception e) {
            // -TODO: Do we want to handle this differently in the future?
            throw new CoreRuntimeException(e.getMessage(), e);
        }
        return parent;
    }

    /**
     * @return the other
     */
    public Enum<?> getOther() {
        return otherEnum;
    }

    /**
     * @param other the other to set
     */
    public void setOther(Enum<?> other) {
        this.otherEnum = other;
    }

    /**
     * @return the enumField
     */
    public Field getEnumField() {
        return enumField;
    }

    /**
     * @param enumField the enumField to set
     */
    public void setEnumField(Field enumField) {
        this.enumField = enumField;
    }

    /**
     * @return the extensionField
     */
    public Field getExtensionField() {
        return extensionField;
    }

    /**
     * @param extensionField the extensionField to set
     */
    public void setExtensionField(Field extensionField) {
        this.extensionField = extensionField;
    }

    /**
     * @return the highestVersionValues
     */
    @SuppressWarnings("rawtypes")
    public List<Enum> getHighestVersionValues() {
        return highestVersionValues;
    }

    /**
     * @param highestVersionValues the highestVersionValues to set
     */
    @SuppressWarnings("rawtypes")
    public void setHighestVersionValues(List<Enum> highestVersionValues) {
        this.highestVersionValues = highestVersionValues;
    }

    /**
     * @return the transducer
     */
    public Transducer<Enum<?>> getTransducer() {
        return transducer;
    }

    /**
     * @param transducer the transducer to set
     */
    public void setTransducer(Transducer<Enum<?>> transducer) {
        this.transducer = transducer;
    }

    /**
     * @return the allowedValues
     */
    @SuppressWarnings("rawtypes")
    public List<Enum> getAllowedValues() {
        return allowedValues;
    }

    /**
     * @param allowedValues the allowedValues to set
     */
    @SuppressWarnings("rawtypes")
    public void setAllowedValues(List<Enum> allowedValues) {
        this.allowedValues = allowedValues;
    }

}