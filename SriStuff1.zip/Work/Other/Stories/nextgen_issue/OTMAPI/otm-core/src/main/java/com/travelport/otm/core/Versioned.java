/**
 *
 */
package com.travelport.otm.core;

import com.travelport.otm.jaxb.converters.OpenEnumConverter;
import com.travelport.otm.jaxb.runtime.OTMVersionListener;

import java.util.List;

/**
 * @author Eric.Bronson
 */
public interface Versioned {

    String getVersion();

    void setVersion(String version);

    OTMVersionListener<?> getVersionListener();

    List<OpenEnumConverter> getOpenEnumConverters();

}
