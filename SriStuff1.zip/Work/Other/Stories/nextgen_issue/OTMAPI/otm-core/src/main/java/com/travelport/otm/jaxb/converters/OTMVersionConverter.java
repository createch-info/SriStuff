/**
 *
 */
package com.travelport.otm.jaxb.converters;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * OTMVersionConverter provides way for setting the type and default Value
 * and used for applying for the converter between versions
 *
 * @author Eric.Bronson
 */
public abstract class OTMVersionConverter<X, Y> {

    private static final Pattern versionPattern = Pattern
            .compile("(\\d+)?(?:_(\\d+))?(?:_(\\d+))?");
    protected Object defaultValue;
    private OTMConverterType type;

    /**
     * Splits the given version identifier according to its component separator
     * characters.
     *
     * @param versionIdentifier the version identifer string to process
     * @return int[]
     */
    protected static int[] splitVersionIdentifier(String versionIdentifier) {
        Matcher m = versionPattern.matcher(versionIdentifier);
        int[] versionParts;

        if (m.matches()) {
            versionParts = new int[3];

            for (int i = 0; i < 3; i++) {
                String versionPart = m.group(i + 1);
                versionParts[i] = Integer.parseInt((versionPart == null) ? "0"
                        : versionPart);
            }
        } else {
            versionParts = new int[]{0, 0, 0};
        }
        return versionParts;
    }

    /**
     * Compares the from and to version with the parent
     * to apply converters
     *
     * @param parentVersion
     * @param fromVersion
     * @param toVersion
     * @return
     */
    public static boolean applyConverter(String parentVersion, String fromVersion,
                                         String toVersion) {
        boolean apply = false;
        fromVersion = fromVersion.length() == 0 ? null : fromVersion;
        toVersion = toVersion.length() == 0 ? null : toVersion;
        VersionIdentifier vi = new VersionIdentifier(parentVersion);
        VersionIdentifier toV = new VersionIdentifier(toVersion);
        VersionIdentifier fromV = new VersionIdentifier(fromVersion);
        if (toVersion != null) {
            if (vi.compareTo(toV) <= 0) {
                if (fromVersion != null) {
                    if (vi.compareTo(fromV) >= 0) {
                        apply = true;
                    }
                } else {
                    apply = true;
                }
            }
        } else if (fromVersion != null && vi.compareTo(fromV) >= 0) {
            apply = true;

        }
        if (fromVersion == null && toVersion == null) {
            apply = true;
        }
        return apply;
    }

    public abstract Y marshall(X field, String version, Object parent);

    public abstract X unmarshall(Y value, String version, Object parent);

    public OTMConverterType getType() {
        return type;
    }

    public void setType(OTMConverterType type) {
        this.type = type;
    }

    public Object getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(Object defaultValue) {
        this.defaultValue = defaultValue;
    }

    /**
     * Encapsulates a single version identifier to use for comparison purposes.
     */
    public static class VersionIdentifier implements Comparable<VersionIdentifier> {

        private int[] versionParts;

        public VersionIdentifier(String versionIdentifier) {
            this.versionParts = (versionIdentifier == null) ? new int[]{0, 0,
                    0} : splitVersionIdentifier(versionIdentifier);
        }

        /**
         * @see java.lang.Comparable#compareTo(java.lang.Object)
         */
        @Override
        public int compareTo(VersionIdentifier that) {
            int result = 0;

            if (that == null) {
                result = 1; // simple case - always greater than a null object

            } else {
                for (int i = 0; i < versionParts.length; i++) {
                    if (this.versionParts[i] != that.versionParts[i]) {
                        result = (this.versionParts[i] < that.versionParts[i]) ? -1
                                : 1;
                        break;
                    }
                }
            }
            return result;
        }

    }

}
