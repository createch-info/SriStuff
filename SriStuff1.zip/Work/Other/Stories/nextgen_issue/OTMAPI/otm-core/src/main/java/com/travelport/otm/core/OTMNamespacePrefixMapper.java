/**
 *
 */
package com.travelport.otm.core;

import com.sun.xml.bind.marshaller.NamespacePrefixMapper;

import java.util.Map;

// SonarQube should really only penalize usage of sun.* package or whatever is internally used
//by an arbitrary JRE/JDK implementation. The com.sun.* package is not JRE/JDK API/impl related at all.

/**
 * @author Eric.Bronson
 */
public class OTMNamespacePrefixMapper extends NamespacePrefixMapper {

    private final Map<String, String> prefixMap;

    public OTMNamespacePrefixMapper(Map<String, String> prefixMap) {
        this.prefixMap = prefixMap;
    }

    /* (non-Javadoc)
     * @see com.sun.xml.bind.marshaller.NamespacePrefixMapper#getPreferredPrefix(java.lang.String, java.lang.String, boolean)
     */
    @Override
    public String getPreferredPrefix(String namespaceUri, String suggestion,
                                     boolean requirePrefix) {
        return prefixMap.get(namespaceUri);
    }

}
