package com.travelport.otm.jaxb.converters;

/**
 * @param <E>
 * @author jason.kramer
 */
@SuppressWarnings("rawtypes")
public class DefaultOpenToClosedEnumConverter<E extends Enum> extends OpenToClosedEnumConverter<E> {

    @SuppressWarnings({"unchecked", "static-access"})
    @Override
    public E marshall(E parent, String parentVersion, String extension) {

        E enumValue = null;
        if (parent != null && (!isCurrentOpen())) {
            if (extension == null) {
                enumValue = getDefaultValue();
            } else {
                try {
                    enumValue = (E) parent.valueOf(parent.getDeclaringClass(), extension);
                } catch (IllegalArgumentException iae) {
                    // treat this as "value not found" and next step is to
                    // set it to the default value
                }


                if (enumValue == null) {
                    // return default value
                    enumValue = getDefaultValue();
                } // if this is not available return other with extension, never
                // makes it to else...

            }
        }

        return enumValue;
    }

    @Override
    public E unmarshall(E parent, String parentVersion, String extension) {
        // -TODO: (Cosmo) This should never happen as a default behavior.
        // Since the generated object will always be open if an open enum is one
        // of the versions,
        // the OpenToClosedEnumConverter will always have the Other_ value and
        // it's extension
        // to represent non existing values. The application handling the XML in
        // will
        // need to take this into account.
        return null;
    }

}
