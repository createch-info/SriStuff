/**
 *
 */
package com.travelport.otm.jaxb.converters;

import com.sun.xml.bind.v2.ClassFactory;
import com.travelport.otm.core.exception.OTMException;
import org.reflections.Reflections;
import org.springframework.beans.BeanUtils;

import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * DefaultJavaTypeConverter used in major versioning when there is JavaType
 * Change between versions
 *
 * @author Eric.Bronson
 */
public class DefaultJavaTypeConverter extends
        OTMJavaTypeConverter<Object, Object> {

    private final Class<?> actual;
    private final Class<?> toClass;

    @SuppressWarnings("rawtypes")
    private final Map<Class, Class> marshalMap;
    @SuppressWarnings("rawtypes")
    private final Map<Class, Class> unMarshalMap;

    @SuppressWarnings({"unchecked", "rawtypes"})
    public DefaultJavaTypeConverter(Class actual, Class toClass)
            throws OTMException {

        this.actual = actual;
        this.toClass = toClass;

        Reflections reflections = new Reflections(actual.getPackage().getName());
        Reflections reflections1 = new Reflections(toClass.getPackage()
                .getName());
        Set<Class<? extends Object>> actualSubClss = reflections.getSubTypesOf(actual);
        Set<Class<? extends Object>> toSubclss = reflections1.getSubTypesOf(toClass);
        Map<Class, Class> marshalMap = new HashMap<Class, Class>();
        Map<Class, Class> unMarshalMap = new HashMap<Class, Class>();
        marshalMap.put(actual, toClass);
        unMarshalMap.put(toClass, actual);
        if (actualSubClss.size() > 0 && toSubclss.size() > 0) {
            boolean flag = false;
            for (Class actSubClass : actualSubClss) {
                for (Class toSubClass : toSubclss) {
                    if (toSubClass.getSimpleName().equals(
                            actSubClass.getSimpleName())) {
                        marshalMap.put(actSubClass, toSubClass);
                        unMarshalMap.put(toSubClass, actSubClass);
                        flag = true;
                    }
                }
            }
            if (!flag) {
                throw new OTMException("Objects are not convertible");
            }
        }
        this.marshalMap = Collections.unmodifiableMap(marshalMap);
        this.unMarshalMap = Collections.unmodifiableMap(unMarshalMap);
    }

    /*
     * To verify whether the Types are convertible
     *
     * @see
     * com.travelport.otm.jaxb.converters.OTMJavaTypeConverter#isConvertible
     * (java.lang.Class)
     */
    @Override
    public boolean isConvertible(Class<?> actual, Class<?> other) {
        return this.actual.isAssignableFrom(actual)
                && this.toClass.isAssignableFrom(toClass);
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * com.travelport.otm.jaxb.converters.OTMVersionConverter#marshall(java.
     * lang.Object, java.lang.String)
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    @Override
    public Object marshall(Object field, String version, Object parent) {
        Object obj = null;
        if (marshalMap.size() > 0) {
            Class c = marshalMap.get(field.getClass());
            try {
                obj = morph(field, ClassFactory.create(c));
            } catch (IllegalAccessException | InvocationTargetException e) {
                obj = null;
            }
        }
        return obj;
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * com.travelport.otm.jaxb.converters.OTMVersionConverter#unmarshall(java
     * .lang.Object, java.lang.String)
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    @Override
    public Object unmarshall(Object value, String version, Object parent) {
        Object obj = null;
        if (unMarshalMap.size() > 0) {
            Class c = unMarshalMap.get(value.getClass());
            try {
                obj = morph(value, ClassFactory.create(c));
            } catch (IllegalAccessException | InvocationTargetException e) {
                obj = null;
            }
        }
        return obj;
    }

    protected Object morph(Object source, Object destination) throws IllegalAccessException, InvocationTargetException {
        BeanUtils.copyProperties(source, destination);
        return destination;
    }

}