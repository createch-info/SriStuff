package com.travelport.otm.jaxb.converters;

public class FloatJavaTypeVersionConverter extends
        OTMJavaTypeConverter<Float, String> {

    /* (non-Javadoc)
    * @see com.travelport.otm.jaxb.OTMVersionConverter#marshall(java.lang.Object, java.lang.String)
    */
    @Override
    public String marshall(Float field, String version, Object parent) {
        return String.valueOf(field);
    }

    /* (non-Javadoc)
    * @see com.travelport.otm.jaxb.OTMVersionConverter#unmarshall(java.lang.Object, java.lang.String)
    */
    @Override
    public Float unmarshall(String value, String version, Object parent) {
        Float returnValue;
        try {
            returnValue = Float.parseFloat(value);
        } catch (Exception e) {
            returnValue = Float.parseFloat(this.defaultValue.toString());
        }
        return returnValue;
    }

    /**
     * @param defaultValue the defaultValue to set
     */
    public void setDefaultValue(Float defaultValue) {
        this.defaultValue = defaultValue;
    }

    @Override
    public boolean isConvertible(Class<?> actual, Class<?> other) {
        return actual.equals(Float.class) && other.equals(String.class);
    }

}
