package com.travelport.otm.core.exception;

public class CoreRuntimeException extends RuntimeException {

    public CoreRuntimeException(String message, Throwable cause,
                                boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /**
     * @param message
     */
    public CoreRuntimeException(String message) {
        super(message);
    }

    /**
     * @param cause
     */
    public CoreRuntimeException(Throwable cause) {
        super(cause);
    }

    /**
     * @param message
     * @param cause
     */
    public CoreRuntimeException(String message, Throwable cause) {
        super(message, cause);
    }


}
