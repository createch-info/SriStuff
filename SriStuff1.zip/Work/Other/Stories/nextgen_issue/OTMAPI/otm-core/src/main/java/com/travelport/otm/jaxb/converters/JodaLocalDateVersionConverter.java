package com.travelport.otm.jaxb.converters;

import org.joda.time.LocalDate;

/**
 * @author jason.kramer
 */
public class JodaLocalDateVersionConverter extends
        OTMJavaTypeConverter<LocalDate, String> {

    /* (non-Javadoc)
    * @see com.travelport.otm.jaxb.OTMVersionConverter#marshall(java.lang.Object, java.lang.String)
    */
    @Override
    public String marshall(LocalDate field, String version, Object parent) {
        return String.valueOf(field);
    }

    /* (non-Javadoc)
    * @see com.travelport.otm.jaxb.OTMVersionConverter#unmarshall(java.lang.Object, java.lang.String)
    */
    @Override
    public LocalDate unmarshall(String value, String version, Object parent) {
        LocalDate returnValue;

        try {
            returnValue = new LocalDate(value);
        } catch (Exception e) {
            returnValue = LocalDate.parse(this.defaultValue.toString());
        }
        return returnValue;
    }

    /**
     * @param defaultValue the defaultValue to set
     */
    public void setDefaultValue(LocalDate defaultValue) {
        this.defaultValue = defaultValue;
    }

    @Override
    public boolean isConvertible(Class<?> actual, Class<?> other) {
        return actual.equals(LocalDate.class) && other.equals(String.class);
    }
}
