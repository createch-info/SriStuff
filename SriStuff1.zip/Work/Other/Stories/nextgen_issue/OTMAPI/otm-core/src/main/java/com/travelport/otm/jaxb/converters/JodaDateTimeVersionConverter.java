package com.travelport.otm.jaxb.converters;

import org.joda.time.DateTime;

/**
 * @author jason.kramer
 */
public class JodaDateTimeVersionConverter extends
        OTMJavaTypeConverter<DateTime, String> {


    /* (non-Javadoc)
    * @see com.travelport.otm.jaxb.OTMVersionConverter#marshall(java.lang.Object, java.lang.String)
    */
    @Override
    public String marshall(DateTime field, String version, Object parent) {
        return String.valueOf(field);
    }

    /* (non-Javadoc)
    * @see com.travelport.otm.jaxb.OTMVersionConverter#unmarshall(java.lang.Object, java.lang.String)
    */
    @Override
    public DateTime unmarshall(String value, String version, Object parent) {
        DateTime returnValue;

        try {
            returnValue = new DateTime(value);
        } catch (Exception e) {
            returnValue = DateTime.parse(this.defaultValue.toString());
        }
        return returnValue;
    }

    /**
     * @param defaultValue the defaultValue to set
     */
    public void setDefaultValue(DateTime defaultValue) {
        this.defaultValue = defaultValue;
    }

    @Override
    public boolean isConvertible(Class<?> actual, Class<?> other) {
        return actual.equals(DateTime.class) && other.equals(String.class);
    }
}
