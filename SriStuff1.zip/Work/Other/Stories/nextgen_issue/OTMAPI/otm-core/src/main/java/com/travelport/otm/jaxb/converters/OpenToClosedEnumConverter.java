package com.travelport.otm.jaxb.converters;

/**
 * This is the abstract representation of what will be used to convert
 * OpenEnum to ClosedEnum
 *
 * @param <E>
 * @author jason.kramer
 */
@SuppressWarnings("rawtypes")
public abstract class OpenToClosedEnumConverter<E extends Enum> {

    protected E defaultValue;
    protected boolean currentOpen = false;


    public abstract E marshall(E parent, String parentVersion, String extension);

    public abstract E unmarshall(E parent, String parentVersion, String extension);

    public boolean isCurrentOpen() {
        return currentOpen;
    }

    public void setCurrentOpen(boolean currentOpen) {
        this.currentOpen = currentOpen;
    }

    public E getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(E defaultValue) {
        this.defaultValue = defaultValue;
    }
}
