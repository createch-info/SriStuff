/**
 *
 */
package com.travelport.otm.jaxb.converters;

import java.util.ArrayList;
import java.util.List;

/**
 * CardinalityConverter used in major versioning when the element moves from
 * non-repeatable to repeatable
 *
 * @author Eric.Bronson
 */
public class CardinalityConverter extends
        OTMVersionConverter<List<Object>, List<Object>> {

    private int index = 0;

    @Override
    public List<Object> marshall(List<Object> field, String version, Object parent) {
        List<Object> newList = field;
        if (field != null) {
            newList = new ArrayList<>();
            newList.add(field.get(index));
        }
        return newList;
    }

    @Override
    public List<Object> unmarshall(List<Object> value, String version, Object parent) {
        // Shouldn't have to worry about this I think
        return value;
    }


    /**
     * @param index the index to set
     */
    public void setIndex(int index) {
        this.index = index;
    }

}
