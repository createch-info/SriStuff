/**
 *
 */
package com.travelport.otm.jaxb.converters;

/**
 * @param <X>
 * @param <Y>
 * @author Eric.Bronson
 */
public abstract class OTMJavaTypeConverter<X, Y> extends OTMVersionConverter<X, Y> {

    public abstract boolean isConvertible(Class<?> actual, Class<?> other);


}
