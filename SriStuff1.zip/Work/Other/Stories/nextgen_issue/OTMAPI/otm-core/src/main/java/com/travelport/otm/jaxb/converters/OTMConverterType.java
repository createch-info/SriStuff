/**
 *
 */
package com.travelport.otm.jaxb.converters;

/**
 * @author Eric.Bronson
 */
public enum OTMConverterType {
    REQUIRED, CARDINALITY, JAVA_TYPE, ENUM, FACET;
}
