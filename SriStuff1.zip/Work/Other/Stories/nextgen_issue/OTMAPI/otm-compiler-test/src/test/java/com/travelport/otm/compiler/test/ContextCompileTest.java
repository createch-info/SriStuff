package com.travelport.otm.compiler.test;

import com.travelport.otm.core.exception.OTMException;
import com.travelport.otm.jaxb.OTMContextFactory;
import org.junit.Test;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;


/**
 * This test is to test if the otp file generates the context correctly.
 *
 * @author nasreen.basheer
 */
public class ContextCompileTest {

    @Test
    public void createContext() throws JAXBException, OTMException {
        JAXBContext context = OTMContextFactory.createContext();
        System.out.println(context.toString());
        System.out.println("Context creation successful");
    }

}
