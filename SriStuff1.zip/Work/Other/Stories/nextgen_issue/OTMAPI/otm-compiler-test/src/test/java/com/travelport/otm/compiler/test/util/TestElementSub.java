/**
 *
 */
package com.travelport.otm.compiler.test.util;

import javax.xml.bind.annotation.*;

/**
 * @author eric.bronson
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "TestElementSub")
@XmlType(name = "TestElementSub", propOrder = {"prop1"})
public class TestElementSub extends TestElement {

    @XmlElement(name = "TestProp")
    private String prop1;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((prop1 == null) ? 0 : prop1.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        TestElementSub other = (TestElementSub) obj;
        if (prop1 == null) {
            if (other.prop1 != null)
                return false;
        } else if (!prop1.equals(other.prop1))
            return false;
        return true;
    }

    public String getProp1() {
        return prop1;
    }

    public void setProp1(String prop1) {
        this.prop1 = prop1;
    }

    @Override
    public String toString() {
        return "TestElementSub [prop1=" + prop1 + ", " + super.toString() + "]";
    }

}