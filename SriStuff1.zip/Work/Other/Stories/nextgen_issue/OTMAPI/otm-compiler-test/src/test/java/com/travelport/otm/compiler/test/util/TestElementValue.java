/**
 *
 */
package com.travelport.otm.compiler.test.util;

import javax.xml.bind.annotation.*;


/**
 * @author eric.bronson
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "TestElementValue")
@XmlType(name = "TestElementValue", propOrder = {"value"})
public class TestElementValue {

    @XmlValue
    private String value;
    @XmlAttribute(name = "att1")
    private String att1;
    @XmlAttribute(name = "att2")
    private String att2;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((att1 == null) ? 0 : att1.hashCode());
        result = prime * result + ((att2 == null) ? 0 : att2.hashCode());
        result = prime * result + ((value == null) ? 0 : value.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TestElementValue other = (TestElementValue) obj;
        if (att1 == null) {
            if (other.att1 != null)
                return false;
        } else if (!att1.equals(other.att1))
            return false;
        if (att2 == null) {
            if (other.att2 != null)
                return false;
        } else if (!att2.equals(other.att2))
            return false;
        if (value == null) {
            if (other.value != null)
                return false;
        } else if (!value.equals(other.value))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "TestElementValue [value=" + value + ", att1=" + att1
                + ", att2=" + att2 + "]";
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getAtt1() {
        return att1;
    }

    public void setAtt1(String att1) {
        this.att1 = att1;
    }

    public String getAtt2() {
        return att2;
    }

    public void setAtt2(String att2) {
        this.att2 = att2;
    }

}
