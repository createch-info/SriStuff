/**
 *
 */
package com.travelport.otm.compiler.test;

import com.travelport.otm.jaxb.OTMContextFactory;
import com.travelport.otm.jaxb.runtime.OTMJAXBContext;
import com.travelport.otm.jaxb.runtime.OTMJAXBContext.MediaType;
import com.travelport.otm.jaxb.runtime.OTMMarshaller;
import com.travelport.otm.jaxb.runtime.unmarshaller.OTMUnmarshaller;
import com.travelport.otm.test._2.VersionedCoreObject;
import org.databene.contiperf.junit.ContiPerfRule;
import org.junit.*;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * @author joseph.savariraj
 */
public class PerformanceTestsJSONVersion {

    private static JAXBContext ctx;
    private static Marshaller m;
    private static OTMUnmarshaller unm;
    @Rule
    public ContiPerfRule i = new ContiPerfRule();
    private ByteArrayInputStream in2;
    private ByteArrayOutputStream out2;

    @BeforeClass
    public static void setup() throws Exception {
        ctx = OTMContextFactory.createContext();
        unm = (OTMUnmarshaller) ctx.createUnmarshaller();
        m = ctx.createMarshaller();

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
    }

    @Before
    public void setUp() throws Exception {
        File file = new File(
                "target/resources/json/examples/TestLibrary2_1_0_0/VersionedCoreObject.json");
        Path path = Paths.get(file.toURI());
        byte[] bytes = Files.readAllBytes(path);
        in2 = new ByteArrayInputStream(bytes);
        out2 = new ByteArrayOutputStream(bytes.length);
        System.out.println(bytes.length);
    }

    @Test
    public void testVersionedObjectV1TO0Json() throws Exception {
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "1");
        VersionedCoreObject testCoreObject1First = (VersionedCoreObject) unm.unmarshal(in2, VersionedCoreObject.class);
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, "0");
        m.marshal(testCoreObject1First, out2);
        out2.reset();
        in2.reset();
    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception {

        if (in2 != null) {
            in2.close();
        }
        if (out2 != null) {
            out2.close();
        }
    }

}
