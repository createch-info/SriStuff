/**
 *
 */
package com.travelport.otm.compiler.test.util;

import javax.xml.bind.annotation.*;

/**
 * @author Eric.Bronson
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "TestClassSub")
@XmlType(name = "TestClassSub", propOrder = {"subClassElement"})
public class TestClassSub extends TestClass {

    @XmlElement(name = "SubClassElement")
    private String subClassElement;

    /**
     * @return the subClassElement
     */
    public String getSubClassElement() {
        return subClassElement;
    }

    /**
     * @param subClassElement the subClassElement to set
     */
    public void setSubClassElement(String subClassElement) {
        this.subClassElement = subClassElement;
    }

}
