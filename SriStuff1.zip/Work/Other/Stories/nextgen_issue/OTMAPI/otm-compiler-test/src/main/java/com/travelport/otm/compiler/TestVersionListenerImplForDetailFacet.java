/*
 * Copyright (c) 2016, Travelport.  All Rights Reserved.
 * Use is subject to license agreement.
 */
package com.travelport.otm.compiler;

import com.travelport.otm.jaxb.runtime.OTMVersionListener;
import com.travelport.otm.test.TestBusinessObject1Detail;

/**
 * <PRE>
 * TestVersionListenerImplForFacet implements methods for OTMVersionListener of type TestBusinessObject1Detail.
 * <p>
 * NOTES:
 * 1. Place any additional notes here. Here are some items that may apply.
 * 2. This class is NOT meant to be sub-classed.
 * 3. Thread-Safe = NO
 * 4. External Service Dependencies = NONE
 * <p>
 * </PRE>
 *
 * @author nasreen.basheer
 */
public class TestVersionListenerImplForDetailFacet implements OTMVersionListener<TestBusinessObject1Detail> {

    @Override
    public TestBusinessObject1Detail beforeMarshal(TestBusinessObject1Detail source, String version) {
        source.setDetailElement("detailedElementAtMarshal");
        source.setDetailInd(true);
        return source;
    }

    @Override
    public void afterUnmarshal(TestBusinessObject1Detail target, String version) {
        if (target != null) {
            target.setIdElement("idElementAtUnmarshal");
        }
    }
}
