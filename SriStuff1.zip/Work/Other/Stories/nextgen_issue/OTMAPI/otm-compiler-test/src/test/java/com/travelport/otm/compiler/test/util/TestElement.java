/**
 *
 */
package com.travelport.otm.compiler.test.util;

import javax.xml.bind.annotation.*;


/**
 * @author eric.bronson
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "TestElement")
@XmlType(name = "TestElement", propOrder = {"elementValue"})
@XmlSeeAlso(TestElementSub.class)
public class TestElement {

    @XmlAttribute(name = "att1")
    private String att1;
    @XmlElement(name = "TestElementValue")
    private TestElementValue elementValue;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((att1 == null) ? 0 : att1.hashCode());
        result = prime * result
                + ((elementValue == null) ? 0 : elementValue.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TestElement other = (TestElement) obj;
        if (att1 == null) {
            if (other.att1 != null)
                return false;
        } else if (!att1.equals(other.att1))
            return false;
        if (elementValue == null) {
            if (other.elementValue != null)
                return false;
        } else if (!elementValue.equals(other.elementValue))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "TestElement [att1=" + att1 + ", elementValue=" + elementValue
                + "]";
    }

    public String getAtt1() {
        return att1;
    }

    public void setAtt1(String att1) {
        this.att1 = att1;
    }

    public TestElementValue getElementValue() {
        return elementValue;
    }

    public void setElementValue(TestElementValue elementValue) {
        this.elementValue = elementValue;
    }
}
