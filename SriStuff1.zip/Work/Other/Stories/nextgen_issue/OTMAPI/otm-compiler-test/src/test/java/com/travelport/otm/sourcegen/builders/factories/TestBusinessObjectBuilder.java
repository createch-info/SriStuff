package com.travelport.otm.sourcegen.builders.factories;

import com.travelport.otm.jaxb.runtime.OTMJAXBContext.MediaType;
import com.travelport.otm.sourcegen.builders.testutility.CustomRecursiveToStringStyle;
import com.travelport.otm.test.*;
import com.travelport.otm.test.abstractresourcetest._4.OffersTest;
import com.travelport.otm.test.abstractresourcetest._4.SampleBusinessObjectUpdateUpdateAge;
import com.travelport.otm.test.abstractresourcetest._4.builders.OffersTestBuilderFactory;
import com.travelport.otm.test.abstractresourcetest._4.builders.SampleBusinessObjectBuilderFactory;
import com.travelport.otm.test.builders.TestBusinessObject1BuilderFactory;
import com.travelport.otm.test.builders.TestCoreObject1BuilderFactory;
import com.travelport.otm.test.builders.TestVWABuilderFactory;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.joda.time.DateTime;
import org.junit.Test;

import java.io.File;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class TestBusinessObjectBuilder {

    private static boolean debug = false;

    @SuppressWarnings("unused")
    @Test
    public void test() throws Exception {


        DateTime dt = new DateTime(2005, 3, 26, 12, 0, 0, 0);
        TestVWABuilderFactory vwaFactory = new TestVWABuilderFactory();
        TestVWA vwa = vwaFactory.toBuilder().indicator1Ind(false).attribute1("VWA-1").build();

        if (debug)
            System.out.println("TestVWA :" + ReflectionToStringBuilder.toString(vwa, new CustomRecursiveToStringStyle(5)));

        TestCoreObject1 coreobj1 = TestCoreObject1.getFactory().toBuilder().id("UC1").summaryAttribute1(dt).role(EnumTestCoreObject1RoleBase.ROLE2).summaryElement1(vwa).build();
        if (debug)
            System.out.println("Use Case 1 :" + ReflectionToStringBuilder.toString(coreobj1, new CustomRecursiveToStringStyle(5)));

        TestCoreObject1Alias coreAlias = TestCoreObject1BuilderFactory.newFactory().buildUpon(coreobj1).toTestCoreObject1Alias().build();
        if (debug)
            System.out.println("Use Case 1 :" + ReflectionToStringBuilder.toString(coreAlias, new CustomRecursiveToStringStyle(5)));

        TestBusinessObject1BuilderFactory builderFactory = TestBusinessObject1.getFactory();
        TestBusinessObject1 obj1 = TestBusinessObject1BuilderFactory.newFactory().toBuilder().idElement("UC1").summaryAttribute("Use case 1").summaryInd(false).testCoreObject1Alias(coreAlias).testCoreObject1Ref(coreobj1).build();
        if (debug)
            System.out.println("Use Case 1 :" + ReflectionToStringBuilder.toString(obj1, new CustomRecursiveToStringStyle(99)));

        TestBusinessObject1ID obj2 = builderFactory.toID().idElement("UC1").build();
        TestBusinessObject1Detail obj3 = builderFactory.toDetail().detailElement("value").build();
        TestBusinessObject1ID obj4 = builderFactory.buildUpon(new TestBusinessObject1Detail()).toID().idElement("UC1").build();
        TestBusinessObject1 obj5 = builderFactory.toBuilder().idElement("UC2").summaryAttribute("UC1").build();
        if (debug)
            System.out.println("Use Case 1 :" + ReflectionToStringBuilder.toString(obj1, new CustomRecursiveToStringStyle(99)));


//		UC2: Load from Example File
//		// load from file
//		new PersonBuilder().fromExample(â€œperson.xmlâ€�).build();


//		// load from classpath location
//		new PersonBuilder().fromExample(â€œclasspath:/com/tvp/person.xmlâ€�).build();
        File f = new File("src/test/resources/examples/builders/TestBusinessObject1Detail.xml");
        TestBusinessObject1 obj7 = builderFactory.toExample(f.toURI().toURL(), MediaType.XML).toBuilder().build();
        builderFactory = TestBusinessObject1.getFactory();
     //   f = new File("src/test/resources/examples/builders/TestBusinessObject1.json");
        
        f = new File("src/test/resources/TestBusinessObject1.json");

        TestBusinessObject1 obj8 = builderFactory.toExample(f.toURI().toURL(), MediaType.JSON).toBuilder().build();
        obj7.setIdElement("UC2");
        if (debug)
            System.out.println("Use case 2 - From File :" + ReflectionToStringBuilder.toString(obj7, new CustomRecursiveToStringStyle(99)));

//		UC3: Load from Example and Tweak
//		new PersonBuilder().fromExample(â€œperson.xmlâ€�).setFirstName(â€œSteveâ€�).build();

//		TestBusinessObject1 obj8 = builderFactory.toExample(sourcefile).toBuilder().summaryAttribute("Use case 3").build();
//		obj4.setIdElement("UC3");
//		System.out.println("Use case 3 :"+ ReflectionToStringBuilder.toString(obj8,new CustomRecursiveToStringStyle(99)));

//		UC4: Load from Existing Instance
//		Person p = new Person();
//
//		p.setFirstName(â€œSteveâ€�);
//		new PersonBuilder().fromInstance( p ).build(); // this is basically a clone
//		// - or -
//		new PersonBuilder().fromInstance( p ).setFirstName(â€œSteveâ€�).build(); // tweak

        TestBusinessObject1 obj9 = builderFactory.buildUpon(obj1).toBuilder().summaryInd(true).build();
        obj9.setIdElement("UC4");
        if (debug)
            System.out.println("Use case 4 :" + ReflectionToStringBuilder.toString(obj9, new CustomRecursiveToStringStyle(99)));

//		UC5: Build to Different Facet Type
//		Person p = new Person();
//
//		p.setFirstName(â€œSteveâ€�);
//		PersonDetail pd = new PersonBuilder().fromInstance( p ).buildDetail();
//		PersonID pid = new PersonBuilder().fromInstance( p ).buildID();
//		PersonCustom pc = new PersonBuilder().fromInstance( p ).buildCustom();

        TestBusinessObject1 obj10 = new TestBusinessObject1();
        obj10.setIdElement("UC5");
        if (debug)
            System.out.println("Use case 5 Object :" + ReflectionToStringBuilder.toString(obj10, new CustomRecursiveToStringStyle(99)));

        TestBusinessObject1Detail obj6Detail = builderFactory.buildUpon(obj10).toDetail().build();
        if (debug)
            System.out.println("Use case 5 Detail Facet:" + ReflectionToStringBuilder.toString(obj6Detail, new CustomRecursiveToStringStyle(99)));

        TestBusinessObject1Summary obj6Summary = builderFactory.buildUpon(obj10).toSummary().build();
        if (debug)
            System.out.println("Use case 5 Summary Facet:" + ReflectionToStringBuilder.toString(obj6Summary, new CustomRecursiveToStringStyle(99)));

        TestBusinessObject1Identifier obj6Indetifier = builderFactory.buildUpon(obj10).toIdentifier().build();
        if (debug)
            System.out.println("Use case 5 Identifier Facet:" + ReflectionToStringBuilder.toString(obj6Indetifier, new CustomRecursiveToStringStyle(99)));

        TestBusinessObject1TestCustomFacet obj6Custom = builderFactory.buildUpon(obj10).toTestBusinessObject1TestCustomFacet().build();
        if (debug)
            System.out.println("Use case 5 Custom Facet:" + ReflectionToStringBuilder.toString(obj6Custom, new CustomRecursiveToStringStyle(99)));

        TestBusinessObject1QueryTestQueryFacet qf = builderFactory.toTestBusinessObject1QueryTestQueryFacet().detailElement("Query Facet").summaryAttribute("Use case 5").detailElement("nill").build();
        TestBusinessObject1QueryTestQueryFacet obj6QueryFacet = builderFactory.buildUpon(qf).toTestBusinessObject1QueryTestQueryFacet().build();
        if (debug)
            System.out.println("Use case 5 Query Facet :" + ReflectionToStringBuilder.toString(obj6QueryFacet, new CustomRecursiveToStringStyle(99)));


//		UC6: Build to Different Alias Type
//		Person p = new Person(); // Passenger is an alias for Person
//
//		p.setFirstName(â€œSteveâ€�);
//		Passenger pax = new PersonBuilder().fromInstance( p ).buildPassenger();

        TestBusinessObject1 obj11 = new TestBusinessObject1();
        obj11.setIdElement("UC6");
        if (debug)
            System.out.println("Use case 6 Object:" + ReflectionToStringBuilder.toString(obj11, new CustomRecursiveToStringStyle(99)));

        TestBusinessObject1Alias obj7Alias = builderFactory.buildUpon(obj11).toTestBusinessObject1Alias().build();
        if (debug)
            System.out.println("Use case 6 Alias:" + ReflectionToStringBuilder.toString(obj7Alias, new CustomRecursiveToStringStyle(99)));


//
//		UC7: Build to Different Facet and Alias Type
//		Person p = new Person();
//
//		p.setFirstName(â€œSteveâ€�);
//		PassengerDetail paxd = new PersonBuilder()
//		.fromInstance( p ).buildPassengerDetail();
//		PassengerID paxId = new PersonBuilder().fromInstance( p ).buildPassengerID();
//		PassengerCustom paxc = new PersonBuilder()
//		.fromInstance( p ).buildPassengerCustom();

        TestBusinessObject1 obj12 = new TestBusinessObject1();
        obj12.setIdElement("UC7");
        if (debug)
            System.out.println("Use case 6 Object:" + ReflectionToStringBuilder.toString(obj11, new CustomRecursiveToStringStyle(99)));

        TestBusinessObject1AliasDetail obj7AliasDetail = builderFactory.buildUpon(obj12).toTestBusinessObject1AliasDetail().build();
        if (debug)
            System.out.println("Use case 7 Detail Facet:" + ReflectionToStringBuilder.toString(obj7AliasDetail, new CustomRecursiveToStringStyle(99)));

        TestBusinessObject1AliasSummary obj7AliasSummary = builderFactory.buildUpon(obj12).toTestBusinessObject1AliasSummary().build();
        if (debug)
            System.out.println("Use case 7 Summary Facet:" + ReflectionToStringBuilder.toString(obj7AliasSummary, new CustomRecursiveToStringStyle(99)));

        TestBusinessObject1AliasIdentifier obj7AliasIndetifier = builderFactory.buildUpon(obj12).toTestBusinessObject1AliasIdentifier().build();
        if (debug)
            System.out.println("Use case 7 Identifier Facet:" + ReflectionToStringBuilder.toString(obj7AliasIndetifier, new CustomRecursiveToStringStyle(99)));

        TestBusinessObject1AliasTestCustomFacet obj7AliasCustom = builderFactory.buildUpon(obj12).toTestBusinessObject1AliasTestCustomFacet().build();
        if (debug)
            System.out.println("Use case 7 Custom Facet:" + ReflectionToStringBuilder.toString(obj7AliasCustom, new CustomRecursiveToStringStyle(99)));

        TestBusinessObject1QueryTestQueryFacet obj = builderFactory.toTestBusinessObject1QueryTestQueryFacet().detailElement("Query Facet 7").summaryAttribute("Use case 7").build();
        TestBusinessObject1AliasQueryTestQueryFacet obj7AliasQueryFacet = builderFactory.buildUpon(obj).toTestBusinessObject1AliasQueryTestQueryFacet().build();
        if (debug)
            System.out.println("Use case 7 Query Facet :" + ReflectionToStringBuilder.toString(obj7AliasQueryFacet, new CustomRecursiveToStringStyle(99)));
//		

//		UC8: Nested Objects and Builders
//		I am not really sure how to design this, but we need to figure out how to handle nested objects.  Do we create a structure of nested builders? 
//		Or do we build them separately and assemble into a nested structure of OTM objects?  I am looking for suggestions and ideas for this one. ï�Š

        TestBusinessObject1 obj13 = TestBusinessObject1BuilderFactory.newFactory().toBuilder().summaryAttribute("Use case 8").summaryInd(false).build();
        obj9.setIdElement("UC8");
        if (debug)
            System.out.println("Use Case 8 :" + ReflectionToStringBuilder.toString(obj13, new CustomRecursiveToStringStyle(99)));

        TestBusinessObject1Detail obj9Detail = TestBusinessObject1BuilderFactory.newFactory().toDetail().idElement("Details").detailElement("details").build();
        if (debug)
            System.out.println("Use Case 8 Detail :" + ReflectionToStringBuilder.toString(obj9Detail, new CustomRecursiveToStringStyle(99)));

        TestBusinessObject1 obj9summary = TestBusinessObject1BuilderFactory.newFactory().toSummary().idElement("Summary").idInd(true).build();
        if (debug)
            System.out.println("Use Case 8 Summary :" + ReflectionToStringBuilder.toString(obj9summary, new CustomRecursiveToStringStyle(99)));

        TestBusinessObject1ID obj9identifer = TestBusinessObject1BuilderFactory.newFactory().toSummary().idElement("Identifer").idInd(false).build();
        if (debug)
            System.out.println("Use Case 8 Identifier :" + ReflectionToStringBuilder.toString(obj9identifer, new CustomRecursiveToStringStyle(99)));

        TestBusinessObject1TestCustomFacet obj9custom = TestBusinessObject1BuilderFactory.newFactory()
                .toTestBusinessObject1TestCustomFacet()
                .idElement("CustomFacet")
                .summaryAttribute("CustomFacet")
                .build();
        if (debug)
            System.out.println("Use Case 8 Custom Facet :" + ReflectionToStringBuilder.toString(obj9custom, new CustomRecursiveToStringStyle(99)));

        File offersTestFile = new File("src/test/resources/OffersTest.xml");
        OffersTest rsp = OffersTestBuilderFactory.newFactory().toExample(offersTestFile.toURI().toURL(), MediaType.XML).toBuilder().build();
        if (debug)
            System.out.println("Use Case 9 test the URL value with Dozer Mapping: " + ReflectionToStringBuilder.toString(rsp, new CustomRecursiveToStringStyle(99)));

        //ODT-22

        Integer expectedAge = new Integer(6);
        Integer expectedUpdateAttribute = new Integer(1);
        boolean expectedUpdateIndicator = true;

        SampleBusinessObjectUpdateUpdateAge sampleBusinessObjectUpdateUpdateAge = SampleBusinessObjectBuilderFactory
                .newFactory()
                .toSampleBusinessObjectUpdateUpdateAge()
                .updateAttribute(expectedUpdateAttribute)
                .updateIndicatorInd(expectedUpdateIndicator)
                .age(expectedAge)
                .build();

        assertNotNull(sampleBusinessObjectUpdateUpdateAge);
        assertEquals(expectedAge, sampleBusinessObjectUpdateUpdateAge.getAge());
        assertEquals(expectedUpdateAttribute, sampleBusinessObjectUpdateUpdateAge.getUpdateAttribute());
        assertEquals(expectedUpdateIndicator, sampleBusinessObjectUpdateUpdateAge.isUpdateIndicatorInd());

        if (debug) System.out.println("Use Case 10 Custom Facet :" + ReflectionToStringBuilder
                .toString(sampleBusinessObjectUpdateUpdateAge, new CustomRecursiveToStringStyle(99)));

    }

}
