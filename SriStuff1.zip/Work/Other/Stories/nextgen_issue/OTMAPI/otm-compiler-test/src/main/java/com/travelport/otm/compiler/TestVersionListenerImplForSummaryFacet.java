/*
 * Copyright (c) 2016, Travelport.  All Rights Reserved.
 * Use is subject to license agreement.
 */
package com.travelport.otm.compiler;

import com.travelport.otm.jaxb.runtime.OTMVersionListener;
import com.travelport.otm.test.TestCoreObject2;

/**
 * <PRE>
 * TestVersionListenerImplForFacet implements methods for OTMVersionListener of type TestCoreObject2.
 * <p>
 * NOTES:
 * 1. Place any additional notes here. Here are some items that may apply.
 * 2. This class is NOT meant to be sub-classed.
 * <p>
 * </PRE>
 *
 * @author nasreen.basheer
 */
public class TestVersionListenerImplForSummaryFacet implements OTMVersionListener<TestCoreObject2> {

    @Override
    public TestCoreObject2 beforeMarshal(TestCoreObject2 source, String version) {
        source.setAttribute1("newAtt");
        return source;
    }

    @Override
    public void afterUnmarshal(TestCoreObject2 target, String version) {
        if (target != null) {
            target.setAttribute3(890);
            target.setIdElement("newID");
        }
    }
}
