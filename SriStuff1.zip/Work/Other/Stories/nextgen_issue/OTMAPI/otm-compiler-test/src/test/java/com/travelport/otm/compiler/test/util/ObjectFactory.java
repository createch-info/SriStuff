/**
 *
 */
package com.travelport.otm.compiler.test.util;

import javax.xml.bind.annotation.XmlRegistry;

/**
 * @author Eric.Bronson
 */
@XmlRegistry
public class ObjectFactory {

    public TestClass createTestClass() {
        return new TestClass();
    }

    public TestClassSub createTestClassSub() {
        return new TestClassSub();
    }

}
