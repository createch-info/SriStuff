/**
 *
 */
package com.travelport.otm.compiler.test;

import com.travelport.otm.jaxb.OTMContextFactory;
import com.travelport.otm.jaxb.runtime.OTMJAXBContext;
import com.travelport.otm.jaxb.runtime.OTMJAXBContext.MediaType;
import com.travelport.otm.jaxb.runtime.OTMMarshaller;
import com.travelport.otm.jaxb.runtime.unmarshaller.OTMUnmarshaller;
import com.travelport.otm.test.TestCoreObject2;
import com.travelport.otm.test._2.TestBusinessObject1;
import com.travelport.otm.test._2.VersionedCoreObject;
import org.databene.contiperf.PerfTest;
import org.databene.contiperf.junit.ContiPerfRule;
import org.databene.contiperf.report.CSVLatencyReportModule;
import org.databene.contiperf.report.CSVSummaryReportModule;
import org.databene.contiperf.report.HtmlReportModule;
import org.junit.*;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * @author Eric.Bronson
 */

/**
 * How to run this test using contiperf rule?
 * contiperf works till junit 4.10 only, otm api uses junit 4.12
 * 1. Do a clean install in the parent project
 * 2. For the comiler-test project alone change junit version to 4.10
 * 3. Uncomment @PerfTest and @Rule throughout this class
 * 4. Run the test and revert back the changes made at 2 and 3
 *
 */
@PerfTest(duration = 3600000, threads = 500, warmUp = 1000)
public class PerformanceTestsXML {
    private static JAXBContext ctx;
    private static Marshaller m;
    private static OTMUnmarshaller unm;
    @Rule
    public ContiPerfRule i = new ContiPerfRule(new HtmlReportModule(),
            new CSVSummaryReportModule(), new CSVLatencyReportModule());
    private ByteArrayInputStream in;
    private ByteArrayOutputStream out;
    private ByteArrayInputStream in2;
    private ByteArrayOutputStream out2;
    private ByteArrayInputStream in3;
    private ByteArrayOutputStream out3;

    @BeforeClass
    public static void setup() throws Exception {
        ctx = OTMContextFactory.createContext();
        unm = (OTMUnmarshaller) ctx.createUnmarshaller();
        m = ctx.createMarshaller();

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
    }


    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
        File file = new File(
                "target/resources/schemas/examples/TestLibrary_0_0_0/TestCoreObject2.xml");
        Path path = Paths.get(file.toURI());
        byte[] bytes = Files.readAllBytes(path);
        in = new ByteArrayInputStream(bytes);
        out = new ByteArrayOutputStream(bytes.length);
        System.out.println("bytes in length: " + bytes.length);

        file = new File(
                "target/resources/schemas/examples/TestLibrary2_1_0_0/VersionedCoreObject.xml");
        path = Paths.get(file.toURI());
        bytes = Files.readAllBytes(path);
        in2 = new ByteArrayInputStream(bytes);
        out2 = new ByteArrayOutputStream(bytes.length);
        System.out.println("bytes in length: " + bytes.length);

        //TestBusinessObject1_ForPerfTestsXML uses TestBusinessObject1
        file = new File(
                "src/main/resources/TestBusinessObject1_ForPerfTestsXML.xml");
        path = Paths.get(file.toURI());
        bytes = Files.readAllBytes(path);
        in3 = new ByteArrayInputStream(bytes);
        out3 = new ByteArrayOutputStream(bytes.length);
        System.out.println("bytes in length: " + bytes.length);
    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception {
        if (in != null) {
            in.close();
        }
        if (out != null) {
            out.close();
        }

        if (in2 != null) {
            in2.close();
        }
        if (out2 != null) {
            out2.close();
        }
    }

    @Test
    @PerfTest(duration = 3600000, warmUp = 1000)
    public void testToRunTestBusinessObject1_ForPerfTestsXML() throws Exception {

        OTMUnmarshaller unm1 = (OTMUnmarshaller) ctx.createUnmarshaller();
        Marshaller m1 = ctx.createMarshaller();

        unm1.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m1.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);

        unm1.setProperty(OTMUnmarshaller.INPUT_VERSION, "1");
        TestBusinessObject1 testBO = (TestBusinessObject1) unm1.unmarshal(in3);
        m1.setProperty(OTMMarshaller.OUTPUT_VERSION, "0");
        m1.marshal(testBO, out3);
        out3.reset();
        in3.reset();
    }

    @Test
    @PerfTest(duration = 11000, warmUp = 1000)
    public void testTestCoreObject2Xml() throws Exception {
        TestCoreObject2 core2 = (TestCoreObject2) unm.unmarshal(in);
        m.marshal(core2, out);
        out.reset();
        in.reset();
    }

    @Test
    @PerfTest(duration = 11000, warmUp = 1000)
    public void testVersionedObjectV1TO0Xml() throws Exception {
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "1");
        VersionedCoreObject testCoreObject1First = (VersionedCoreObject) unm.unmarshal(in2);
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, "0");
        m.marshal(testCoreObject1First, out2);
        out2.reset();
        in2.reset();
    }

}
