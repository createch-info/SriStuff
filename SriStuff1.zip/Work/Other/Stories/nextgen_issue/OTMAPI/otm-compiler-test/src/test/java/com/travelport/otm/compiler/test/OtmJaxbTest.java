package com.travelport.otm.compiler.test;

import com.travelport.otm.jaxb.OTMContextFactory;
import com.travelport.otm.jaxb.runtime.OTMJAXBContext;
import com.travelport.otm.jaxb.runtime.OTMJAXBContext.MediaType;
import com.travelport.otm.jaxb.runtime.OTMMarshaller;
import com.travelport.otm.jaxb.runtime.URType;
import com.travelport.otm.jaxb.runtime.unmarshaller.OTMUnmarshaller;
import com.travelport.otm.test.*;
import com.travelport.otm.test._2.TestBusinessObject1;
import com.travelport.otm.test._2.VersionedCoreObject;
import com.travelport.otm.test._2.VersionedCoreObjectDetail;
import com.travelport.otm.test.abstractresourcetest._4.Offers;
import com.travelport.otm.test.abstractresourcetest._4.SampleBusinessObjectUpdateUpdateAge;
import com.travelport.otm.test.childcontextual.FlightTypeCode;
import com.travelport.otm.test.testlibrary.big.offers._5.NestedConFBOTest;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.rules.TestName;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import java.io.*;
import java.util.Properties;

import org.junit.Rule;
import static org.junit.Assert.*;

// Create marshaller and unmarshaller for each test case, otherwise thread conflict (cross pollution) would occur.

public class OtmJaxbTest {

    private static final String testOutputDir = "target" + File.separator + "OtmJaxbTest-Output";
    private static JAXBContext ctx;
    private static Marshaller m;
    private static OTMUnmarshaller unm;
    @Rule public TestName testName = new TestName();
    private File f;
    private File fXml;
    private FileInputStream in;
    private FileOutputStream fos;
    private FileInputStream inXml;
    private FileOutputStream fosXml;
    private File fXml2;
    private String schemaPath = null;
    private String messagePath = null;
    private String version = null;

    @BeforeClass
    public static void setupBeforeClass() throws Exception {
        System.setProperty(JAXBContext.JAXB_CONTEXT_FACTORY, "com.travelport.otm.jaxb.OTMContextFactory");
        System.setProperty(OTMJAXBContext.SET_MILLIS, "false");
        ctx = OTMContextFactory.createContext();
        unm = (OTMUnmarshaller) ctx.createUnmarshaller();
        m = ctx.createMarshaller();
        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        unm.setEventHandler(new TestValidationEventHandler());

        File baseOutputDir = new File(testOutputDir);
        if(!baseOutputDir.exists()) {
            baseOutputDir.mkdirs();
        }
    }

    @After
    public void tearDown() throws Exception {   	
        try {

        } finally {
            closeStream(in);
            closeStream(inXml);
            closeStream(fos);
            closeStream(fosXml);

        }
    }

    private void closeStream(Closeable stream) {
        if (stream != null)
            try {
                stream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
    }

    /* Create a test file with parent dir testOutputDir and extension based on mediaType.
     */
    private File createTestFile(String testName, MediaType mediaType) {

        String extension;

        if (MediaType.XML.equals(mediaType)) {
            extension = ".xml";
        } else
            extension = ".json";

        File targetFile;
        int incrementor = 0;
        StringBuilder builder;

        do {

            builder = new StringBuilder(testName);
            builder.append("_");
            builder.append(incrementor++);
            builder.append(extension);
            targetFile = new File(testOutputDir, builder.toString());

        } while (targetFile.exists());

        return targetFile;
    }

    @Test public void testToVerifyVersionListenerAtSummaryFacet() throws Exception {
        // This is test for version listener at summary facet (TestCoreObject2),
        // here the detail facet (TestCoreObject2Detail) extending
        // summary class will also be affected in change while marshalling and
        // unmarshalling
        String oldAtt = "oldAtt1";

        TestCoreObject2 tco = new TestCoreObject2();
        tco.setAttribute1(oldAtt);
        tco.setIdElement("oldID");

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        f = createTestFile(testName.getMethodName(), MediaType.XML);
        fosXml = new FileOutputStream(f);
        m.marshal(tco, f);
        assertTrue(tco.getAttribute1() != null);
        assertFalse(oldAtt.equals(tco.getAttribute1()));
        assertTrue("newAtt".equals(tco.getAttribute1()));

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        TestCoreObject2 tco2 = (TestCoreObject2) unm.unmarshal(f);
        assertEquals("Marshal and Unmarshal is not successful", "newID", tco2.getIdElement());
        assertTrue("Marshal and Unmarshal is not successful", tco2.getAttribute3().equals(890));

        TestCoreObject2Detail tcod = new TestCoreObject2Detail();
        tcod.setAttribute1("detailAtt1");
        tcod.setIdElement("detailID");

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m.marshal(tcod, f);
        assertTrue(tcod.getAttribute1() != null);
        assertFalse("detailAtt1".equals(tcod.getAttribute1()));
        assertTrue("newAtt".equals(tcod.getAttribute1()));

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        TestCoreObject2Detail tcod2 = (TestCoreObject2Detail) unm.unmarshal(f);
        assertEquals("Value not set by Required Converter", "newID", tco2.getIdElement());
        assertTrue("Marshal and Unmarshal is not successful", tcod2.getAttribute3().equals(890));
        assertEquals("Marshal and Unmarshal is not successful", "newID", tco2.getIdElement());

    }

    @Test
    public void testToVerifyVersionListenerAtDetailFacet() throws Exception {
        // This is test for version listener at detail facet
        // (TestBusinessObject1Detail) extending
        // this class will also be affected in change while marshaling and
        // unmarshaling

        String detailElement = "oldElement";

        TestBusinessObject1Detail tbod = new TestBusinessObject1Detail();
        tbod.setDetailElement("oldElement");
        tbod.setIdElement("oldID");

        assertTrue(detailElement.equals(tbod.getDetailElement()));

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        f = createTestFile(testName.getMethodName(), MediaType.XML);
        fosXml = new FileOutputStream(f);
        m.marshal(tbod, fosXml);
        assertFalse(detailElement.equals(tbod.getDetailElement()));
        assertTrue("detailedElementAtMarshal".equals(tbod.getDetailElement()));

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        TestBusinessObject1Detail tbod2 = (TestBusinessObject1Detail) unm.unmarshal(f);
        assertEquals("Marshal and Unmarshal is not successful", "idElementAtUnmarshal", tbod2.getIdElement());

    }

    @Test
    public void testVersionListenerAtValueWithAttributes() throws Exception {

        TestVWA vwa = new TestVWA();
        vwa.setAttribute1("attribute1");
        Marshaller marshaller = ctx.createMarshaller();
        marshaller.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        f = createTestFile(testName.getMethodName(), MediaType.XML);
        fosXml = new FileOutputStream(f);
        marshaller.marshal(vwa, fosXml);
        assertTrue(vwa.getAttribute1() != null);
        assertFalse("Marshal and Unmarshal is not successful", "attribute1".equals(vwa.getAttribute1()));
        assertTrue("Marshal and Unmarshal is not successful", "att1AtMarshal".equals(vwa.getAttribute1()));

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        TestVWA vwa2 = (TestVWA) unm.unmarshal(f);

        assertEquals("Marshal and Unmarshal is not successful", "version1AttributeAtUnmarshal",
                vwa2.getVersion1Attribute());
    }

    @Test
    public void testItShouldCreateContextAutomatically() throws Exception {
        JAXBContext ctx = OTMContextFactory.createContext();
        assertNotNull(ctx);
        // First, unmarshal from the XML file
        in = new FileInputStream("target/resources/schemas/examples/TestLibrary_0_0_0/TestCoreObject1.xml");
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        Object testCoreObject1First = unm.unmarshal(in);
        Marshaller marshaller = ctx.createMarshaller();
        marshaller.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        File fXml1 = createTestFile(testName.getMethodName(), MediaType.XML);
        fosXml = new FileOutputStream(fXml1);
        // Second, marshal back into XML, different file
        marshaller.marshal(testCoreObject1First, fosXml);
        closeStream(fosXml);
        // make sure something was written
        assertTrue(fXml1.length() > 0);
    }

    @Test
    public void testItShouldCreateContextUsingOnlyAClass() throws Exception {
        JAXBContext ctx = OTMContextFactory.createContext(new Class[]{TestCoreObject2.class}, null);
        assertNotNull(ctx);
        // First, unmarshal from the XML file
        in = new FileInputStream("target/resources/schemas/examples/TestLibrary_0_0_0/TestCoreObject2.xml");
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        Object testCoreObject1First = unm.unmarshal(in);

        fXml2 = createTestFile(testName.getMethodName(), MediaType.XML);
        fosXml = new FileOutputStream(fXml2);
        // Second, marshal back into XML, different file
        Marshaller marshaller = ctx.createMarshaller();
        marshaller.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        marshaller.marshal(testCoreObject1First, fosXml);
        if (fosXml != null) {
            fosXml.close();
        }
        // make sure something was written
        assertTrue(fXml2.length() > 0);
    }

    @Test
    public void testItShouldBuildASchema() throws Exception {
        System.setProperty(OTMJAXBContext.BUILD_SCHEMAS, "true");
        Schema schema = OTMContextFactory.getValidationSchema();
        assertNotNull("No schema generated.", schema);
        JAXBContext ctx = OTMContextFactory.createContext();
        assertNotNull(ctx);
        assertNotNull("No schema for marshaller.", ctx.createMarshaller().getSchema());
        assertNotNull("No schema for unmarshaller.", ctx.createUnmarshaller().getSchema());
    }

    @Test
    public void testItShouldNotBuildASchema() throws Exception {
        System.setProperty(OTMJAXBContext.BUILD_SCHEMAS, "false");
        JAXBContext ctx = OTMContextFactory.createContext();
        assertNotNull(ctx);
        assertNull("Schema for marshaller.", ctx.createMarshaller().getSchema());
        assertNull("Schema for unmarshaller.", ctx.createUnmarshaller().getSchema());
    }

    @Test
    public void testItShouldCreateJaxbPropertiesFileInEachPackage() throws Exception {
        Properties props = new Properties();
        in = new FileInputStream("target/generated-sources/otm/META-INF/com.travelport.otm.context.properties");
        props.load(in);
        String pkgContext = props.getProperty("com.travelport.otm.contextPath");
        for (String pkg : pkgContext.split(":")) {
            File packageDir = new File("target/generated-sources/otm/" + pkg.replace(".", File.separator));
            if (packageDir.exists()) {
                File jaxbFile = new File(packageDir + "/jaxb.properties");
                assertTrue("No jaxb.properties file.", jaxbFile.exists());
            }
        }
    }

    @Test
    public void testTestCoreObject1() throws Exception {
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File("target/resources/schemas/TestLibrary_0_0_0.xsd"));
        unm.setSchema(schema);
        in = new FileInputStream("target/resources/schemas/examples/TestLibrary_0_0_0/TestCoreObject1.xml");
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // First, unmarshal from the XML file
        Object testCoreObject1First = unm.unmarshal(in);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m.setSchema(schema);
        fXml = createTestFile(testName.getMethodName(), MediaType.XML);
        fosXml = new FileOutputStream(fXml);
        // Second, marshal back into XML, different file
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, "0");
        m.marshal(testCoreObject1First, fosXml);
        if (fosXml != null) {
            fosXml.close();
        }

        inXml = new FileInputStream(fXml);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // Unmarshal for a second object to use for the compare
        Object testCoreObject1Second = unm.unmarshal(inXml);
        if (inXml != null) {
            inXml.close();
        }

        fosXml = new FileOutputStream(fXml);
        // Marshal back into a second XML file
        m.marshal(testCoreObject1First, fosXml);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Now marshal into JSON
        m.marshal(testCoreObject1First, fos);
        if (fos != null) {
            fos.close();
        }
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        // And unmarshal from JSON

  //      in = new FileInputStream("target/resources/json/examples/TestLibrary_0_0_0/TestCoreObject1.json");
        in = new FileInputStream("src/test/resources/TestCoreObject1.json");

        // First, unmarshal from the JSON file
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "0");
        TestCoreObject1 testCoreObject1JSONFirst = unm.unmarshal(in, TestCoreObject1.class);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Second, marshal back into JSON, different file
        m.marshal(testCoreObject1JSONFirst, fos);
        if (fos != null) {
            fos.close();
        }

        in = new FileInputStream(f);
        // Unmarshal for a second object to use for the compare
        TestCoreObject1 testCoreObject1JSONSecond = unm.unmarshal(in, TestCoreObject1.class);

        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(testCoreObject1First, testCoreObject1Second));
        assertTrue("UnMarshalled JSON Objects are not Equal",
                ObjectCompareTester.compareObjects(testCoreObject1JSONFirst, testCoreObject1JSONSecond));

    }

    @Test
    public void testTestCoreObject1JsonExample() throws Exception {
    //    in = new FileInputStream("target/resources/json/examples/TestLibrary_0_0_0/TestCoreObject1.json");
        in = new FileInputStream("src/test/resources/TestCoreObject1.json");

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "0");
        // First, unmarshal from the JSON file
        TestCoreObject1 testCoreObject1First = unm.unmarshal(in, TestCoreObject1.class);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Second, marshal back into JSON, different file
        m.marshal(testCoreObject1First, fos);
        if (fos != null) {
            fos.close();
        }

        in = new FileInputStream(f);
        // Unmarshal for a second object to use for the compare
        TestCoreObject1 testCoreObject1Second = unm.unmarshal(in, TestCoreObject1.class);
        if (in != null) {
            in.close();
        }
        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(testCoreObject1First, testCoreObject1Second));
    }

    @Test
    public void testTestCoreObject2() throws Exception {
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File("target/resources/schemas/TestLibrary_0_0_0.xsd"));
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "0");
        unm.setSchema(schema);
        in = new FileInputStream("target/resources/schemas/examples/TestLibrary_0_0_0/TestCoreObject2.xml");
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // First, unmarshal from the XML file
        Object testCoreObject2First = unm.unmarshal(in);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m.setSchema(schema);
        fXml = createTestFile(testName.getMethodName(), MediaType.XML);
        fosXml = new FileOutputStream(fXml);
        // Second, marshal back into XML, different file
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, "0");
        m.marshal(testCoreObject2First, fosXml);
        if (fosXml != null) {
            fosXml.close();
        }

        inXml = new FileInputStream(fXml);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // Unmarshal for a second object to use for the compare
        Object testCoreObject2Second = unm.unmarshal(inXml);
        if (inXml != null) {
            inXml.close();
        }

        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(testCoreObject2First, testCoreObject2Second));

        fosXml = new FileOutputStream(fXml);
        // Marshal back into a second XML file
        m.marshal(testCoreObject2First, fosXml);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Now marshal into JSON
        m.marshal(testCoreObject2First, fos);

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        in = new FileInputStream(f);
        StreamSource source = new StreamSource(in);
        // And unmarshal from JSON
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "0");
        Object testCoreObject2JSON = unm.unmarshal(source, testCoreObject2First.getClass());

        assertTrue("Objects are not Equal", ObjectCompareTester.compareObjects(testCoreObject2First,
                ((JAXBElement<?>) testCoreObject2JSON).getValue()));
    }

    @Test
    public void testTestCoreObject2JsonExample() throws Exception {
    	
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File("target/resources/schemas/TestLibrary_0_0_0.xsd"));
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "0");
        unm.setSchema(schema);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
  //    in = new FileInputStream("target/resources/json/examples/TestLibrary_0_0_0/TestCoreObject2.json");
        in = new FileInputStream("src/test/resources/TestCoreObject2.json");

        // First, unmarshal from the JSON file
        TestCoreObject2 testCoreObject2First = unm.unmarshal(in, TestCoreObject2.class);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        m.setSchema(schema);
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, "0"); 
        
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Second, marshal back into JSON, different file
        m.marshal(testCoreObject2First, fos);
        if (fos != null) {
            fos.close();
        }

        in = new FileInputStream(f);
        // Unmarshal for a second object to use for the compare
        TestCoreObject2 testCoreObject2Second = unm.unmarshal(in, TestCoreObject2.class);
        if (in != null) {
            in.close();
        }
        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(testCoreObject2First, testCoreObject2Second));
    }

    @Test
    public void testTestCoreObject3() throws Exception {
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File("target/resources/schemas/TestLibrary_0_0_0.xsd"));
        unm.setSchema(schema);
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "0");
        /*
         * in = new FileInputStream(
		 * "src/test/resources/examples/TestLibrary_0_0_0/TestCoreObject3.xml");
		 */
        in = new FileInputStream("target/resources/schemas/examples/TestLibrary_0_0_0/TestCoreObject3.xml");
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // First, unmarshal from the XML file
        Object testCoreObject3First = unm.unmarshal(in);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m.setSchema(schema);
        fXml = createTestFile(testName.getMethodName(), MediaType.XML);
        fosXml = new FileOutputStream(fXml);
        // Second, marshal back into XML, different file
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, "0");
        m.marshal(testCoreObject3First, fosXml);
        if (fosXml != null) {
            fosXml.close();
        }

        inXml = new FileInputStream(fXml);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // Unmarshal for a second object to use for the compare
        Object testCoreObject3Second = unm.unmarshal(inXml);
        if (inXml != null) {
            inXml.close();
        }

        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(testCoreObject3First, testCoreObject3Second));

        fosXml = new FileOutputStream(fXml);
        // Marshal back into a second XML file
        m.marshal(testCoreObject3First, fosXml);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Now marshal into JSON
        m.marshal(testCoreObject3First, fos);

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        in = new FileInputStream(f);
        StreamSource source = new StreamSource(in);
        // And unmarshal from JSON
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "0");
        Object testCoreObject3JSON = unm.unmarshal(source, testCoreObject3First.getClass());
        assertTrue("Objects are not Equal", ObjectCompareTester.compareObjects(testCoreObject3First,
                ((JAXBElement<?>) testCoreObject3JSON).getValue()));

    }

    @Test
    public void testTestCoreObject3JsonExample() throws Exception {
    	
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File("target/resources/schemas/TestLibrary_0_0_0.xsd"));
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "0");
        unm.setSchema(schema);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
   //   in = new FileInputStream("target/resources/json/examples/TestLibrary_0_0_0/TestCoreObject3.json");
        in = new FileInputStream("src/test/resources/TestCoreObject3.json");
        
        
        // First, unmarshal from the JSON file
        TestCoreObject3 testCoreObject3First = unm.unmarshal(in, TestCoreObject3.class);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        m.setSchema(schema);
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, "0");        
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Second, marshal back into JSON, different file
        m.marshal(testCoreObject3First, fos);
        if (fos != null) {
            fos.close();
        }

        in = new FileInputStream(f);
        // Unmarshal for a second object to use for the compare
        TestCoreObject3 testCoreObject3Second = unm.unmarshal(in, TestCoreObject3.class);
        if (in != null) {
            in.close();
        }
        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(testCoreObject3First, testCoreObject3Second));

    }

    @Test
    public void testBusinessObject2() throws Exception {
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File("target/resources/schemas/TestLibrary_0_0_0.xsd"));
        unm.setSchema(schema);
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "0");
        in = new FileInputStream("target/resources/schemas/examples/TestLibrary_0_0_0/TestBusinessObject2.xml");
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // First, unmarshal from the XML file
        Object testCoreObject1First = unm.unmarshal(in);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m.setSchema(schema);
        fXml = createTestFile(testName.getMethodName(), MediaType.XML);
        fosXml = new FileOutputStream(fXml);
        // Second, marshal back into XML, different file
        m.marshal(testCoreObject1First, fosXml);
        if (fosXml != null) {
            fosXml.close();
        }

        inXml = new FileInputStream(fXml);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // Unmarshal for a second object to use for the compare
        Object testCoreObject1Second = unm.unmarshal(inXml);
        if (inXml != null) {
            inXml.close();
        }

        fosXml = new FileOutputStream(fXml);
        // Marshal back into a second XML file
        m.marshal(testCoreObject1First, fosXml);

        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(testCoreObject1First, testCoreObject1Second));

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Now marshal into JSON
        m.marshal(testCoreObject1First, fos);

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        in = new FileInputStream(f);
        StreamSource source = new StreamSource(in);
        // And unmarshal from JSON
        Object testCoreObject1JSON = unm.unmarshal(source, testCoreObject1First.getClass());
        assertTrue("Objects are not Equal", ObjectCompareTester.compareObjects(testCoreObject1First,
                ((JAXBElement<?>) testCoreObject1JSON).getValue()));
    }

    @Test
    public void testBusinessObject2JsonExample() throws Exception {
    //    in = new FileInputStream("target/resources/json/examples/TestLibrary_0_0_0/TestBusinessObject2.json");
        in = new FileInputStream("src/test/resources/TestBusinessObject2.json");
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        // First, unmarshal from the JSON file
        TestBusinessObject2Detail testCoreObject1First = unm.unmarshal(in, TestBusinessObject2Detail.class);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Second, marshal back into JSON, different file
        m.marshal(testCoreObject1First, fos);
        if (fos != null) {
            fos.close();
        }

        in = new FileInputStream(f);
        // Unmarshal for a second object to use for the compare
        TestBusinessObject2Detail testCoreObject1Second = unm.unmarshal(in, TestBusinessObject2Detail.class);
        if (in != null) {
            in.close();
        }

        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(testCoreObject1First, testCoreObject1Second));
    }

    @Test
    public void testBusinessObject1JsonExample() throws Exception {
    //    in = new FileInputStream("target/resources/json/examples/TestLibrary_0_0_0/TestBusinessObject1.json");
        in = new FileInputStream("src/test/resources/TestBusinessObject1.json");

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "0");
        // First, unmarshal from the JSON file
        TestBusinessObject1Detail testObject1First = unm.unmarshal(in, TestBusinessObject1Detail.class);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Second, marshal back into JSON, different file
        m.marshal(testObject1First, fos);
        if (fos != null) {
            fos.close();
        }

        in = new FileInputStream(f);
        // Unmarshal for a second object to use for the compare
        TestBusinessObject1Detail testObject1Second = unm.unmarshal(in, TestBusinessObject1Detail.class);
        if (in != null) {
            in.close();
        }

        assertTrue("Objects are not Equal", ObjectCompareTester.compareObjects(testObject1First, testObject1Second));
    }


    /*NOTE james.collings 8/17/2017 ODT-22
     *
     * This test was based on testBusinessObjectExtensionPoint, in this same test suite.
     * So our goal with this test is to marshal and unmarshal the file. We start with XML and
     * convert it to Java and then we convert it back to XML. The source file is a message. Our
     * goal is to marshal and unmarshal it.
     */
    @Test
    public void testItShouldMarshallAndUnmarshallUpdateObject() throws Exception {

        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

        //NOTE 8/22/2017 james.collings This XSD represents the schema that validates TestBusinessObject1.xml
        Schema schema = sf.newSchema(new File("src/test/resources/examples/schemas/TestLibrary5_0_0_0.xsd"));
        unm.setSchema(schema); //NOTE 8/22/2017 james.collings Sets validation on.

        //NOTE 8/17/2017 james.collings This is the source test message file.
        in = new FileInputStream("src/test/resources/examples/TestLibrary4_0_0_0/SampleBusinessObjectUpdateUpdateAge.xml");

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // First, unmarshal from the XML file

        SampleBusinessObjectUpdateUpdateAge sampleBusinessObjectUpdateUpdateAge =
                (SampleBusinessObjectUpdateUpdateAge) unm.unmarshal(in);

        testHelper(schema, sampleBusinessObjectUpdateUpdateAge);

    }

    private void testHelper(Schema schema, URType urType) throws JAXBException, IOException, IllegalAccessException {

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, "0");
        m.setSchema(schema);
        fXml = createTestFile(testName.getMethodName(), MediaType.XML);
        fosXml = new FileOutputStream(fXml);
        // Second, marshal back into XML, different file
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, "0");
        m.marshal(urType, fosXml);
        if (fosXml != null) {
            fosXml.close();
        }

        inXml = new FileInputStream(fXml);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // Unmarshal for a second object to use for the compare
        Object testCoreObject1Second = unm.unmarshal(inXml);
        if (inXml != null) {
            inXml.close();
        }

        fosXml = new FileOutputStream(fXml);
        // Marshal back into a second XML file
        m.marshal(urType, fosXml);

        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(urType, testCoreObject1Second));

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Now marshal into JSON
        m.marshal(urType, fos);

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        in = new FileInputStream(f);
        StreamSource source = new StreamSource(in);
        // And unmarshal from JSON
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "0");
        Object testCoreObject1JSON = unm.unmarshal(source, urType.getClass());
        assertTrue("Objects are not Equal", ObjectCompareTester.compareObjects(urType,
                ((JAXBElement<?>) testCoreObject1JSON).getValue()));
    }

    @Test
    public void testBusinessObjectExtensionPoint() throws Exception {
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File("src/test/resources/examples/schemas/TestLibrary2_0_0_0.xsd"));
        unm.setSchema(schema);
        in = new FileInputStream("src/test/resources/examples/TestLibrary2_0_0_0/TestBusinessObject1.xml");
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // First, unmarshal from the XML file
        TestBusinessObject1 testCoreObject1First = (TestBusinessObject1) unm.unmarshal(in);

        testHelper(schema, testCoreObject1First);

    }

    /*
     *  Extension point elements are rolled up to minor version
     *  as per schema extension point is allowed and it should not break.
    */
    @Test
    public void testBusinessObject1Library2V010() throws Exception {
        String version = "0_1";
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File("src/test/resources/examples/schemas/TestLibrary2_0_1_0.xsd"));
        unm.setSchema(schema);
        unm.setValidating(true);
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, version);
        in = new FileInputStream("src/test/resources/examples/TestLibrary2_0_1_0/TestBusinessObject1.xml");
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // First, unmarshal from the XML file
        TestBusinessObject1 testBusinessObject1First = (TestBusinessObject1) unm.unmarshal(in);
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, version);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        fXml = createTestFile(testName.getMethodName(), MediaType.XML);
        fosXml = new FileOutputStream(fXml);
        // Second, marshal back into XML, different file
        m.marshal(testBusinessObject1First, fosXml);
        if (fosXml != null) {
            fosXml.close();
        }

        inXml = new FileInputStream(fXml);
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, version);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // Unmarshal for a second object to use for the compare
        TestBusinessObject1 testBusinessObject1Second = (TestBusinessObject1) unm.unmarshal(inXml);
        if (inXml != null) {
            inXml.close();
        }

        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(testBusinessObject1First, testBusinessObject1Second));
        unm.setValidating(false);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Now marshal into JSON
        m.marshal(testBusinessObject1First, fos);

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        in = new FileInputStream(f);
        StreamSource source = new StreamSource(in);
        // And unmarshal from JSON
        Object testCoreObject1JSON = unm.unmarshal(source, testBusinessObject1First.getClass());
        TestBusinessObject1 jsonSecond = (TestBusinessObject1) ((JAXBElement<?>) testCoreObject1JSON).getValue();
        assertTrue("Objects are not Equal", ObjectCompareTester.compareObjects(testBusinessObject1First, jsonSecond));
    }

    /* NOTE 8/23/2017 james.collings reformatted for readability.
     * Extension point elements are rolled up to minor version
     * as per schema extension point is allowed and it should not break.
     * */
    @Test
    public void testBusinessObject1Library2V010JSON() throws Exception {
        OTMUnmarshaller unm = (OTMUnmarshaller) ctx.createUnmarshaller();
        String version = "0_1";
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, version);
        in = new FileInputStream("src/test/resources/examples/TestLibrary2_0_1_0/TestBusinessObject1.json");

        TestBusinessObject1 testBusinessObject1First = (TestBusinessObject1) unm.unmarshal(in,
                TestBusinessObject1.class);
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, version);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        // m.setSchema(schema);
        File fjson = createTestFile(testName.getMethodName(), MediaType.JSON);
        // Second, marshal back into XML, different file
        FileInputStream inJson;
        TestBusinessObject1 testBusinessObject1Second;
        try (FileOutputStream fosJson = new FileOutputStream(fjson)) {
            m.marshal(testBusinessObject1First, fosJson);

            inJson = new FileInputStream(fjson);
            unm.setProperty(OTMUnmarshaller.INPUT_VERSION, version);
            unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
            // Unmarshal for a second object to use for the compare
            testBusinessObject1Second = (TestBusinessObject1) unm.unmarshal(inJson,
                    TestBusinessObject1.class);

        }
        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(testBusinessObject1First, testBusinessObject1Second));
    }

    @Test
    public void testVersionedObjectV0() throws Exception {
        String version = "0";
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File("src/test/resources/examples/schemas/TestLibrary2_0_0_0.xsd"));
        unm.setSchema(schema);
        unm.setValidating(true);
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, version);
        in = new FileInputStream("src/test/resources/examples/TestLibrary2_0_0_0/VersionedCoreObject.xml");
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // First, unmarshal from the XML file
        VersionedCoreObject testCoreObject1First = (VersionedCoreObject) unm.unmarshal(in);
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, version);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m.setSchema(schema);
        fXml = createTestFile(testName.getMethodName(), MediaType.XML);
        fosXml = new FileOutputStream(fXml);
        // Second, marshal back into XML, different file
        m.marshal(testCoreObject1First, fosXml);
        if (fosXml != null) {
            fosXml.close();
        }

        inXml = new FileInputStream(fXml);
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, version);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // Unmarshal for a second object to use for the compare
        VersionedCoreObject testCoreObject1Second = (VersionedCoreObject) unm.unmarshal(inXml);
        if (inXml != null) {
            inXml.close();
        }
        assertNotNull(testCoreObject1Second.getVwaNamespace2());
        fosXml = new FileOutputStream(fXml);
        // Marshal back into a second XML file
        m.marshal(testCoreObject1First, fosXml);

        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(testCoreObject1First, testCoreObject1Second));
        unm.setValidating(false);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Now marshal into JSON
        m.marshal(testCoreObject1First, fos);

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        in = new FileInputStream(f);
        StreamSource source = new StreamSource(in);
        // And unmarshal from JSON
        Object testCoreObject1JSON = unm.unmarshal(source, testCoreObject1First.getClass());
        VersionedCoreObject jsonSecond = (VersionedCoreObject) ((JAXBElement<?>) testCoreObject1JSON).getValue();
        assertNotNull(jsonSecond.getVwaNamespace2());
        // This fails due to ambiguites in primitive lists
        assertTrue("Objects are not Equal", ObjectCompareTester.compareObjects(testCoreObject1First, jsonSecond));
    }

    @Test
    public void testVersionedObjectV1() throws Exception {
        String version = "1";
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File("src/test/resources/examples/schemas/TestLibrary2_1_0_0.xsd"));
        unm.setSchema(schema);
        unm.setValidating(true);
        in = new FileInputStream("src/test/resources/examples/TestLibrary2_1_0_0/VersionedCoreObject.xml");
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // First, unmarshal from the XML file
        VersionedCoreObject testCoreObject1First = (VersionedCoreObject) unm.unmarshal(in);
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, version);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m.setSchema(schema);
        fXml = createTestFile(testName.getMethodName(), MediaType.XML);
        fosXml = new FileOutputStream(fXml);
        // Second, marshal back into XML, different file
        m.marshal(testCoreObject1First, fosXml);
        if (fosXml != null) {
            fosXml.close();
        }

        inXml = new FileInputStream(fXml);
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, version);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // Unmarshal for a second object to use for the compare
        VersionedCoreObject testCoreObject1Second = (VersionedCoreObject) unm.unmarshal(inXml);
        if (inXml != null) {
            inXml.close();
        }
        fosXml = new FileOutputStream(fXml);
        // Marshal back into a second XML file
        m.marshal(testCoreObject1First, fosXml);

        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(testCoreObject1First, testCoreObject1Second));
        unm.setValidating(false);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Now marshal into JSON
        m.marshal(testCoreObject1First, fos);

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        in = new FileInputStream(f);
        StreamSource source = new StreamSource(in);
        // And unmarshal from JSON
        Object testCoreObject1JSON = unm.unmarshal(source, testCoreObject1First.getClass());
        VersionedCoreObject jsonSecond = (VersionedCoreObject) ((JAXBElement<?>) testCoreObject1JSON).getValue();
        assertTrue("Objects are not Equal", ObjectCompareTester.compareObjects(testCoreObject1First, jsonSecond));
    }

    // Properties are rolled up to major version -2
    @Test
    public void testVersionedObjectV2() throws Exception {
        String version = "2";
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File("src/test/resources/examples/schemas/TestLibrary2_2_0_0.xsd"));
        unm.setSchema(schema);
        unm.setValidating(true);
        in = new FileInputStream("src/test/resources/examples/TestLibrary2_2_0_0/VersionedCoreObject.xml");
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // First, unmarshal from the XML file
        VersionedCoreObject testCoreObject1First = (VersionedCoreObject) unm.unmarshal(in);
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, version);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m.setSchema(schema);
        fXml = createTestFile(testName.getMethodName(), MediaType.XML);
        fosXml = new FileOutputStream(fXml);
        // Second, marshal back into XML, different file
        m.marshal(testCoreObject1First, fosXml);
        if (fosXml != null) {
            fosXml.close();
        }

        inXml = new FileInputStream(fXml);
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, version);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // Unmarshal for a second object to use for the compare
        VersionedCoreObject testCoreObject1Second = (VersionedCoreObject) unm.unmarshal(inXml);
        if (inXml != null) {
            inXml.close();
        }
        fosXml = new FileOutputStream(fXml);
        // Marshal back into a second XML file
        m.marshal(testCoreObject1First, fosXml);

        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(testCoreObject1First, testCoreObject1Second));
        unm.setValidating(false);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Now marshal into JSON
        m.marshal(testCoreObject1First, fos);

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        in = new FileInputStream(f);
        StreamSource source = new StreamSource(in);
        // And unmarshal from JSON
        Object testCoreObject1JSON = unm.unmarshal(source, testCoreObject1First.getClass());
        VersionedCoreObject jsonSecond = (VersionedCoreObject) ((JAXBElement<?>) testCoreObject1JSON).getValue();
        assertTrue("Objects are not Equal", ObjectCompareTester.compareObjects(testCoreObject1First, jsonSecond));
    }

    @Test
    public void testVersionedObjectPatchVersion1To0() throws Exception {
        String version = "1";
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File("src/test/resources/examples/schemas/TestLibrary2_1_0_0.xsd"));
        unm.setSchema(schema);
        unm.setValidating(true);
        in = new FileInputStream("src/test/resources/examples/TestLibrary2_1_0_0/VersionedCoreObject.xml");
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);

        // First, unmarshal from the XML file
        VersionedCoreObjectDetail testCoreObject1First = (VersionedCoreObjectDetail) unm.unmarshal(in);
        assertNull(testCoreObject1First.getVwaNamespace2());
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, version);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m.setSchema(schema);
        fXml = createTestFile(testName.getMethodName(), MediaType.XML);
        fosXml = new FileOutputStream(fXml);
        // Second, marshal back into XML, different file
        m.marshal(testCoreObject1First, fosXml);
        if (fosXml != null) {
            fosXml.close();
        }
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        inXml = new FileInputStream(fXml);
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, version);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // Unmarshal for a second object to use for the compare

        fosXml = new FileOutputStream(fXml);
        version = "0";
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, version);
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, version);
        // Marshal back into a second XML file

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m.marshal(testCoreObject1First, fosXml);
        VersionedCoreObject testCoreObject1Second = (VersionedCoreObject) unm.unmarshal(inXml);

        if (inXml != null) {
            inXml.close();
        }
        unm.setValidating(false);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Now marshal into JSON
        m.marshal(testCoreObject1First, fos);

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        in = new FileInputStream(f);
        StreamSource source = new StreamSource(in);
        // And unmarshal from JSON
        Object testCoreObject1JSON = unm.unmarshal(source, testCoreObject1Second.getClass());
        VersionedCoreObject jsonSecond = (VersionedCoreObject) ((JAXBElement<?>) testCoreObject1JSON).getValue();
        assertTrue("Objects are not Equal", ObjectCompareTester.compareObjects(testCoreObject1Second, jsonSecond));
    }


    /*
     * Testing for undefined elements in an extension point.
     * <Internal1> <Internal11>check1</Internal11> <Internal12>abc</Internal12>
     * </Internal1> <Internal2>test1</Internal2>
     */
    @Test
    public void testBusinessObject1Library2V0() throws Exception {
        String version = "0";
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File("src/test/resources/examples/schemas/TestLibrary2_0_0_0.xsd"));
        unm.setSchema(schema);
        unm.setValidating(true);
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, version);
        in = new FileInputStream("src/test/resources/examples/TestLibrary2_0_0_0/TestBusinessObject1.xml");
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // First, unmarshal from the XML file
        TestBusinessObject1 testBusinessObject1First = (TestBusinessObject1) unm.unmarshal(in);
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, version);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m.setSchema(schema);
        fXml = createTestFile(testName.getMethodName(), MediaType.XML);
        fosXml = new FileOutputStream(fXml);
        // Second, marshal back into XML, different file
        m.marshal(testBusinessObject1First, fosXml);
        if (fosXml != null) {
            fosXml.close();
        }

        inXml = new FileInputStream(fXml);
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, version);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // Unmarshal for a second object to use for the compare
        TestBusinessObject1 testBusinessObject1Second = (TestBusinessObject1) unm.unmarshal(inXml);
        if (inXml != null) {
            inXml.close();
        }

        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(testBusinessObject1First, testBusinessObject1Second));
        unm.setValidating(false);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Now marshal into JSON
        m.marshal(testBusinessObject1First, fos);

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        in = new FileInputStream(f);
        StreamSource source = new StreamSource(in);
        // And unmarshal from JSON
        Object testCoreObject1JSON = unm.unmarshal(source, testBusinessObject1First.getClass());
        TestBusinessObject1 jsonSecond = (TestBusinessObject1) ((JAXBElement<?>) testCoreObject1JSON).getValue();
        assertTrue("Objects are not Equal", ObjectCompareTester.compareObjects(testBusinessObject1First, jsonSecond));
    }


    /* Testing for undefined elements in an extension point.
     * {"TestInternal2":"test1", "TestInternal" :{ "Internal1":"test2" } },
     */
    @Test
    public void testBusinessObject1Library2V0JSON() throws Exception {
        String version = "0";
        OTMUnmarshaller unm = (OTMUnmarshaller) ctx.createUnmarshaller();
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, version);
 //       in = new FileInputStream("src/test/resources/examples/TestLibrary2_0_0_0/TestBusinessObject1.json");
        in = new FileInputStream("src/test/resources/TestBusinessObject1.json");

        TestBusinessObject1 testBusinessObject1First = (TestBusinessObject1) unm.unmarshal(in,
                TestBusinessObject1.class);
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, version);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        // m.setSchema(schema);
        File fjson = createTestFile(testName.getMethodName(), MediaType.JSON);
        FileInputStream inJson;
        TestBusinessObject1 testBusinessObject1Second;
        try (FileOutputStream fosJson = new FileOutputStream(fjson)) {
            // Second, marshal back into XML, different file
            m.marshal(testBusinessObject1First, fosJson);

            inJson = new FileInputStream(fjson);
            unm.setProperty(OTMUnmarshaller.INPUT_VERSION, version);
            unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
            // Unmarshal for a second object to use for the compare
            testBusinessObject1Second = (TestBusinessObject1) unm.unmarshal(inJson,
                    TestBusinessObject1.class);

            fjson.delete();
        }
        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(testBusinessObject1First, testBusinessObject1Second));
    }

    @Test
    public void testActionFacet() throws Exception {
        String version = "0";
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File("target/resources/schemas/TestLibrary_0_0_0.xsd"));
        unm.setSchema(schema);
        unm.setValidating(true);
        // unm = (OTMUnmarshaller) ctx.createUnmarshaller();
        in = new FileInputStream("target/resources/schemas/examples/TestLibrary_0_0_0/SubstitutionGroup.xml");
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "0");
        // First, unmarshal from the XML file
        Object testActionFacet = unm.unmarshal(in);
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, version);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m.setSchema(schema);
        fXml = createTestFile(testName.getMethodName(), MediaType.XML);
        fosXml = new FileOutputStream(fXml);
        // Second, marshal back into XML, different file
        m.marshal(testActionFacet, fosXml);
        if (fosXml != null) {
            fosXml.close();
        }
        inXml = new FileInputStream(fXml);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // Unmarshal for a second object to use for the compare
        Object testActionFacetSecond = unm.unmarshal(inXml);
        if (inXml != null) {
            inXml.close();
        }

        fosXml = new FileOutputStream(fXml);
        // Marshal back into a second XML file
        m.marshal(testActionFacet, fosXml);

        assertTrue("Objects are not Equal", ObjectCompareTester.compareObjects(testActionFacet, testActionFacetSecond));

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Now marshal into JSON
        m.marshal(testActionFacet, fos);

        if (fos != null) {
            fos.close();
        }

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);

        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, version);
        // And unmarshal from JSON
        in = new FileInputStream("src/test/resources/SubstitutionGroup.json");

 //       in = new FileInputStream("target/resources/json/examples/TestLibrary_0_0_0/SubstitutionGroup.json");
    //    /otm-compiler-test/src/test/resources/examples/TestLibrary_0_0_0/SubstitutionGroup.json
        // First, unmarshal from the JSON file
        SubstitutionGroup testActionFacetObject1First = unm.unmarshal(in, SubstitutionGroup.class);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Second, marshal back into JSON, different file
        m.marshal(testActionFacetObject1First, fos);

        if (fos != null) {
            fos.close();
        }

        in = new FileInputStream(f);
        // Unmarshal for a second object to use for the compare
        SubstitutionGroup testActionFacetSecondJSON = unm.unmarshal(in, SubstitutionGroup.class);

        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(testActionFacetObject1First, testActionFacetSecondJSON));

    }

    @Test
    public void testTestVWA2JsonExample() throws Exception {

        baseTestForMarshallAndUnmarshallForJSON();
    }

    @Test
    @Ignore
    /*NOTE james.collings 8/23/2017 Reformatted for readability / spelling corrections.
     * In this test the TestMinorVersion property is associated to the "0_1" version. In versionedClassBeanInfoImpl
     * handleVersioning(VersionGraph, OTMJAXBContext) method the properties for un-marshallers are created for
     * TestBusinessObject2Detail.java and its super class (TestBusinessObject2ID.java) and <u>not</u> for the
     * TestBusinessObject2.java The TestMinorVersion is in the TestBusinessObject2.java, and the properties for
     * un-marshallers are created only for TestBusinessObject2.java and its super class TestBusinessObject2ID.java
     * In the below test of the TestBusinessObject2.xml, the <TestBusinessObject2Detail> is the root element
     * which is associated to TestBusinessObject2Detail and its superclass TestBusinessObject2ID properties.
     * So the un-marshaller for TestMinorVersion property is not found in the list and it will throw an exception.
     */
    public void testBusinessObject1LibraryV010() throws Exception {

        schemaPath = "target/resources/schemas/TestLibrary_0_1_0.xsd";
        messagePath = "target/resources/schemas/examples/TestLibrary_0_1_0/TestBusinessObject2.xml";
        version = "0_1";

        baseTestForMarshallAndUnmarshallForXML(schemaPath, messagePath, version);

    }

    @Test
    public void testTestVWA2XMLExample() throws Exception {
        schemaPath = "target/resources/schemas/TestLibrary_0_0_0.xsd";
        messagePath = "target/resources/schemas/examples/TestLibrary_0_0_0/TestVWA2.xml";
        version = "0";

        baseTestForMarshallAndUnmarshallForXML(schemaPath, messagePath, version);
    }

    @Test
    public void testToMarshallAndUnmarshallParentBOForV0() throws Exception {
        // testing message in v0 containing business object containing ID and
        // Summary facets only

        schemaPath = "target/resources/schemas/TestLibrary3_0_0_0.xsd";
        messagePath = "target/resources/schemas/examples/TestLibrary3_0_0_0/Product.xml";
        version = "0";

        baseTestForMarshallAndUnmarshallForXML(schemaPath, messagePath, version);
    }

    @Test
    public void testItShouldMarshallAndUnmarshallChildContextualFacetOfAParentBO() throws Exception {

        /*NOTE 8/23/2017 james.collings Reformatted for readability.
        * Testing message in v0 containing business object containing ID,Summary facets and a child Contextual facet in
        * different package the child has a property segment while the parent does not that is verified at the end.
        * */

        schemaPath = "target/resources/schemas/TestLibrary3_1_0_0.xsd";
        messagePath = "src/test/resources/examples/TestLibrary3_1_0_0/ProductAirSchedule.xml";
        version = "1";

        baseTestForMarshallAndUnmarshallForXML(schemaPath, messagePath, version);
    }

    private void baseTestForMarshallAndUnmarshallForJSON()
            throws Exception {
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File("target/resources/schemas/TestLibrary_0_0_0.xsd"));
        unm.setSchema(schema);
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "0");
        unm.setValidating(true);
        in = new FileInputStream("target/resources/json/examples/TestLibrary_0_0_0/TestVWA2.json");
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        // First, unmarshal from the JSON file
        TestVWA2 testCoreObject2First = unm.unmarshal(in, TestVWA2.class);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Second, marshal back into JSON, different file
        m.marshal(testCoreObject2First, fos);
        if (fos != null) {
            fos.close();
        }

        in = new FileInputStream(f);
        // Unmarshal for a second object to use for the compare
        TestVWA2 testCoreObject2Second = unm.unmarshal(in, TestVWA2.class);
        if (in != null) {
            in.close();
        }
        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(testCoreObject2First, testCoreObject2Second));
    }

    private void baseTestForMarshallAndUnmarshallForXML(String schemaPath, String messagePath, String version)
            throws Exception {
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File(schemaPath));
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, version);
        unm.setSchema(schema);
        in = new FileInputStream(messagePath);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // First, unmarshal from the XML file
        Object childContextual = unm.unmarshal(in);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m.setSchema(schema);
        fXml = createTestFile(testName.getMethodName(), MediaType.XML);
        fosXml = new FileOutputStream(fXml);
        // Second, marshal back into XML, different file
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, version);
        m.marshal(childContextual, fosXml);
        if (fosXml != null) {
            fosXml.close();
        }

        inXml = new FileInputStream(fXml);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // Unmarshal for a second object to use for the compare
        Object productSecond = unm.unmarshal(inXml);
        if (inXml != null) {
            inXml.close();
        }

        assertTrue("Objects are not Equal", ObjectCompareTester.compareObjects(childContextual, productSecond));

        fosXml = new FileOutputStream(fXml);
        // Marshal back into a second XML file
        m.marshal(childContextual, fosXml);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Now marshal into JSON
        m.marshal(childContextual, fos);

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        in = new FileInputStream(f);
        StreamSource source = new StreamSource(in);
        // And unmarshal from JSON
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, version);
        Object productJSON = unm.unmarshal(source, childContextual.getClass());

        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(childContextual, ((JAXBElement<?>) productJSON).getValue()));
    }

    @Test
    public void testItShouldMarshallAndUnmarshallChildConFacet2HavingAParentConFacet1WithAParentBO() throws Exception {
        // testing message in v0 containing parent Bo in package1 and child
        // contextualfacet1
        // in different package2 which has a child contextualFacet2 in package3
        // the child has a property segment while the parent does not that is
        // verified at the end.

        schemaPath = "target/resources/schemas/TestLibrary3_2_0_0.xsd";
        messagePath = "src/test/resources/examples/TestLibrary3_2_0_0/ProductAirScheduleScheduleTest3.xml";
        version = "2";

        baseTestForMarshallAndUnmarshallForXML(schemaPath, messagePath, version);
    }

    @Test
    public void testItShouldMarshallAndUnmarshallMessageWithChildFromALibraryOfDuplicateNamespace() throws Exception {
        // testing a message from a library with child whose namespace is same
        // as that of
        // another library. This message has to be umarshalled and unmarshalled
        // correctly.
        // Key method in the
        // process:BaseJavaTransformer.getNamedEntityFromQNameForChildren();

        schemaPath = "target/resources/schemas/SameNamespace2Library_0_0_0.xsd";
        messagePath = "src/test/resources/examples/SameNamespace2Library2_0_0_0/ProductContextualAir.xml";
        version = "0";

        baseTestForMarshallAndUnmarshallForXML(schemaPath, messagePath, version);
    }

    @Test
    public void testItShouldMarshallAndUnmarshallMessageWithContextualChildFromLowerVersionLibraryThanParentObject()
            throws Exception {
        // testing a message from a contextual facet of a package with lower
        // version
        // while parent is in higher version of different package.
        // Key method in the
        // process:NamedEntityToJavaClassTransformer.getJavaClass(), by adding
        // annotations

        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File("target/resources/schemas/TestLibrary3_2_0_0.xsd"));
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "2");
        unm.setSchema(schema);
        in = new FileInputStream("src/test/resources/examples/TestLibrary3_2_0_0/FlightTypeCode.xml");
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // First, unmarshal from the XML file
        Object childContextual = unm.unmarshal(in);
        FlightTypeCode code = (FlightTypeCode) childContextual;
        assertTrue(code.getCarrierName().equals("Delta767"));
        assertTrue(code.getPassengers().equals("645"));

        // making sure if the attribute from parent is getting populated
        assertTrue(code.getFlightID().equals("flightType_1"));

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m.setSchema(schema);
        fXml = createTestFile(testName.getMethodName(), MediaType.XML);
        fosXml = new FileOutputStream(fXml);
        // Second, marshal back into XML, different file
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, "2");
        m.marshal(childContextual, fosXml);
        if (fosXml != null) {
            fosXml.close();
        }

        inXml = new FileInputStream(fXml);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // Unmarshal for a second object to use for the compare
        Object productSecond = unm.unmarshal(inXml);
        if (inXml != null) {
            inXml.close();
        }

        assertTrue("Objects are not Equal", ObjectCompareTester.compareObjects(childContextual, productSecond));

        fosXml = new FileOutputStream(fXml);
        // Marshal back into a second XML file
        m.marshal(childContextual, fosXml);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Now marshal into JSON
        m.marshal(childContextual, fos);

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        in = new FileInputStream(f);
        StreamSource source = new StreamSource(in);
        // And unmarshal from JSON
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "2");
        Object productJSON = unm.unmarshal(source, childContextual.getClass());

        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(childContextual, ((JAXBElement<?>) productJSON).getValue()));
    }

    @Test
    public void testItShouldMarshallAndUnmarshallActionFacetLabelOffersToOffersObject()
            throws Exception {
        // testing a message from a contextual facet of a package with lower
        // version
        // while parent is in higher version of different package.
        // Key method in the
        // process:NamedEntityToJavaClassTransformer.getJavaClass(), by adding
        // annotations

        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File("target/resources/schemas/TestLibrary4_0_0_0.xsd"));
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "0");
        unm.setSchema(schema);
        in = new FileInputStream("src/test/resources/Offers.xml");
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // First, unmarshal from the XML file
        Object childContextual = unm.unmarshal(in);
        Offers offers = (Offers) childContextual;

        assertTrue(offers.getDefaultCurrency().equals("Example String Value"));

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m.setSchema(schema);
        fXml = createTestFile(testName.getMethodName(), MediaType.XML);

        fosXml = new FileOutputStream(fXml);
        // Second, marshal back into XML, different file
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, "0");
        m.marshal(childContextual, fosXml);
        if (fosXml != null) {
            fosXml.close();
        }

        inXml = new FileInputStream(fXml);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // Unmarshal for a second object to use for the compare
        Object productSecond = unm.unmarshal(inXml);
        if (inXml != null) {
            inXml.close();
        }

        assertTrue("Objects are not Equal", ObjectCompareTester.compareObjects(childContextual, productSecond));

        fosXml = new FileOutputStream(fXml);
        // Marshal back into a second XML file
        m.marshal(childContextual, fosXml);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Now marshal into JSON
        m.marshal(childContextual, fos);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        in = new FileInputStream(f);
        StreamSource source = new StreamSource(in);
        // And unmarshal from JSON
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "0");
        Object productJSON = unm.unmarshal(source, childContextual.getClass());

        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(childContextual, ((JAXBElement<?>) productJSON).getValue()));
    }
    
    
    @Test
    public void testJSONSubstutitionGroupsShouldHaveAnAtTypeOnTheVariable()
            throws Exception {

        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File("target/resources/schemas/TestLibrary5_0_0_0.xsd"));
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "0");
        unm.setSchema(schema);
        in = new FileInputStream("src/test/resources/OffersLib5test.xml");
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // First, unmarshal from the XML file
        Object childContextual = unm.unmarshal(in);

        com.travelport.otm.test.testlibrary.offers._5.Offers offers = 
        		(com.travelport.otm.test.testlibrary.offers._5.Offers) childContextual;

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m.setSchema(schema);
        fXml = createTestFile(testName.getMethodName(), MediaType.XML);

        fosXml = new FileOutputStream(fXml);
        // Second, marshal back into XML, different file
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, "0");
        m.marshal(childContextual, fosXml);
        if (fosXml != null) {
            fosXml.close();
        }

        inXml = new FileInputStream(fXml);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // Unmarshal for a second object to use for the compare
        Object productSecond = unm.unmarshal(inXml);
        if (inXml != null) {
            inXml.close();
        }

        assertTrue("Objects are not Equal", ObjectCompareTester.compareObjects(childContextual, productSecond));

        fosXml = new FileOutputStream(fXml);
        // Marshal back into a second XML file
        m.marshal(childContextual, fosXml);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Now marshal into JSON
        m.marshal(childContextual, fos);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        in = new FileInputStream(f);
        StreamSource source = new StreamSource(in);
        // And unmarshal from JSON
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "0");
        Object productJSON = unm.unmarshal(source, childContextual.getClass());

        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(childContextual, ((JAXBElement<?>) productJSON).getValue()));
    }
    
    @Test
    public void testJSONSubstutitionGroupsForNestedContextualFacetsShouldHaveAnAtTypeOnTheVariableAndParentReference()
            throws Exception {

        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File("target/resources/schemas/TestLibrary5_1_0_0.xsd"));
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "1");
        unm.setSchema(schema);
 //       in = new FileInputStream("src/test/resources/NestedConFBOTest.xml");
        in = new FileInputStream("src/test/resources/NestedConFBOTest_Copy.xml");

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // First, unmarshal from the XML file
        Object childContextual = unm.unmarshal(in);
        
        NestedConFBOTest offers = (NestedConFBOTest) childContextual;


        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m.setSchema(schema);
        fXml = createTestFile(testName.getMethodName(), MediaType.XML);

        fosXml = new FileOutputStream(fXml);
        // Second, marshal back into XML, different file
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, "1");
        m.marshal(childContextual, fosXml);
        if (fosXml != null) {
            fosXml.close();
        }

        inXml = new FileInputStream(fXml);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        // Unmarshal for a second object to use for the compare
        Object productSecond = unm.unmarshal(inXml);
        if (inXml != null) {
            inXml.close();
        }

        assertTrue("Objects are not Equal", ObjectCompareTester.compareObjects(childContextual, productSecond));

        fosXml = new FileOutputStream(fXml);
        // Marshal back into a second XML file
        m.marshal(childContextual, fosXml);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        f = createTestFile(testName.getMethodName(), MediaType.JSON);
        fos = new FileOutputStream(f);
        // Now marshal into JSON
        m.marshal(childContextual, fos);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        in = new FileInputStream(f);
        StreamSource source = new StreamSource(in);
        // And unmarshal from JSON
        unm.setProperty(OTMUnmarshaller.INPUT_VERSION, "1");
        Object productJSON = unm.unmarshal(source, childContextual.getClass());

        assertTrue("Objects are not Equal",
                ObjectCompareTester.compareObjects(childContextual, ((JAXBElement<?>) productJSON).getValue()));
    }

    
    

}
