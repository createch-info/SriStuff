package com.travelport.otm.compiler.test.compare.generated.reflection;

import com.travelport.otm.sourcegen.common.builder.AbstractOTMBuilder;
import com.travelport.otm.sourcegen.common.builder.factory.AbstractOTMBuilderFactory;
import com.travelport.otm.sourcegen.common.builder.factory.IOTMBuilderFactory;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.reflections.ReflectionUtils;
import org.reflections.Reflections;

import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


//TODO : Note this Test is just a skeleton which has hooks for writing robust tests for Builders. THIS IS NOT COMPLETE.

public class BuilderTemplateVarificationTest {

    private static Reflections reflections;
    @SuppressWarnings("rawtypes")
    private static Set<Class<? extends IOTMBuilderFactory>> classes;

    private static boolean debug = false;

    @Before
    public void setUp() throws Exception {
        reflections = new Reflections("com.travelport.otm");
        classes = reflections.getSubTypesOf(IOTMBuilderFactory.class);
        classes.remove(AbstractOTMBuilderFactory.class);
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void testValidateBuilderFactoryTemplate()
            throws InstantiationException, IllegalAccessException {
        for (Class<? extends IOTMBuilderFactory> clazz : classes) {
            if (debug) System.out.println(clazz.getName());
            valiadteClassInheritance(clazz);

        }
    }

    private void valiadteClassInheritance(
            @SuppressWarnings("rawtypes") Class<? extends IOTMBuilderFactory> clazz) {
        if (debug) System.out
                .println("Checking for AbstarctOTMBuilderFactory Inheritance.");
        Assert.assertSame(clazz.getSuperclass(),
                AbstractOTMBuilderFactory.class);

        ParameterizedType ptype = (ParameterizedType) clazz
                .getGenericSuperclass();
        Type[] types = ptype.getActualTypeArguments();
        Map<String, Class<?>> factoryGenericTypeMap = new HashMap<>();
        factoryGenericTypeMap.put("BASE", ReflectionUtils.forName(types[0].toString().replaceFirst("class ", ""), ClassLoader.getSystemClassLoader()));
        factoryGenericTypeMap.put("CONSTANT_FACTORY", ReflectionUtils.forName(types[1].toString().replaceFirst("class ", ""), ClassLoader.getSystemClassLoader()));
        factoryGenericTypeMap.put("BUILDER", ReflectionUtils.forName(types[2].toString().replaceFirst("class ", ""), ClassLoader.getSystemClassLoader()));

        for (String key : factoryGenericTypeMap.keySet()) {
            Class<?> value = factoryGenericTypeMap.get(key);
            if (debug)
                System.out.println(key + " = " + value.getSimpleName() + " ----> Canonical Name:" + value.getCanonicalName());
        }

        validateFactoryMethods(clazz.getMethods(), factoryGenericTypeMap);
        validateDeclaredClasses(factoryGenericTypeMap.get("BASE"), clazz.getDeclaredClasses());

    }

    private void validateDeclaredClasses(Class<?> factoryClass, Class<?>[] declaredClasses) {
        for (Class<?> declaredClass : declaredClasses) {
            if (debug) System.out.println("Declared Class : " + declaredClass.getName());
            Assert.assertSame(declaredClass.getSuperclass(),
                    AbstractOTMBuilder.class);
            ParameterizedType ptype = (ParameterizedType) declaredClass
                    .getGenericSuperclass();
            Type[] types = ptype.getActualTypeArguments();
            Class<?> objectGeneric = ReflectionUtils.forName(types[0].toString().replaceFirst("class ", ""), ClassLoader.getSystemClassLoader());
            if (debug)
                System.out.println("Object to be built : " + " = " + objectGeneric.getSimpleName() + " ----> Canonical Name:" + objectGeneric.getCanonicalName());
            validateBuilderClassTemplate(declaredClass);
            validateFactoryMethodsForFacetBuilder(factoryClass, declaredClass);
        }
    }

    private void validateFactoryMethodsForFacetBuilder(Class<?> factoryClass, Class<?> declaredClass) {
        String methodname = getMethodString(factoryClass.getSimpleName(), declaredClass.getSimpleName());
        if (debug)
            System.out.println("Base class name : " + " = " + factoryClass.getSimpleName() + " ----> Declared Class Name:" + declaredClass.getSimpleName());
        if (debug) System.out.println("Facet Method Name : " + methodname);

    }

    private String getMethodString(String clazzName, String facetClazzname) {
        String methodName = "toBuilder";
        clazzName = clazzName.replaceFirst("ID", "");
        Pattern pattern = Pattern.compile(clazzName);
        Matcher matcher = pattern.matcher(facetClazzname);
        if (matcher.find()) {
            methodName = (matcher.replaceAll("to"));
        }

        return methodName;
    }

    private void validateBuilderClassTemplate(Class<?> declaredClass) {
        final String builderMethod = "build";
        Method[] methods = declaredClass.getMethods();
        List<Method> methodList = Arrays.asList(methods);
        Predicate predicate = new Predicate() {
            public boolean evaluate(Object object) {
                return ((Method) object).getName().equals(builderMethod);
            }
        };
        Method result = (Method) CollectionUtils.find(methodList, predicate);
        Assert.assertNotNull(result);
        Assert.assertSame(result.getName(), builderMethod);
        if (debug) System.out.println("Found Method inside Builder : " + result.getName());
    }

    private void validateFactoryMethods(Method[] methods, Map<String, Class<?>> factoryGenericTypeMap) {
        String[] factoryMethods = {"buildUpon", "toExample", "toBuilder", "newFactory"};
        List<Method> methodList = Arrays.asList(methods);

        for (String method : factoryMethods) {
            final String meth = method;
            Predicate predicate = new Predicate() {
                public boolean evaluate(Object object) {
                    return ((Method) object).getName().equals(meth);
                }
            };
            Method res = (Method) CollectionUtils.find(methodList, predicate);
            Assert.assertNotNull(res);
            Assert.assertSame(res.getName(), method);
            if (debug) System.out.println("Found Method inside Factory : " + method);
        }

        Predicate predicate = new Predicate() {
            public boolean evaluate(Object object) {
                return ((Method) object).getName().equals("toBuilder");
            }
        };
        Method res = (Method) CollectionUtils.find(methodList, predicate);
        Assert.assertNotNull(res);
        Assert.assertSame(res.getName(), "toBuilder");
        //Assert.assertSame(res.getGenericReturnType().getClass().getSimpleName(), factoryGenericTypeMap.get("BUILDER").getSimpleName());


        predicate = new Predicate() {
            public boolean evaluate(Object object) {
                return ((Method) object).getName().equals("newFactory");
            }
        };
        res = (Method) CollectionUtils.find(methodList, predicate);
        Assert.assertNotNull(res);
        Assert.assertSame(res.getName(), "newFactory");
        //Assert.assertSame(res.getReturnType().getClass().getSimpleName(), factoryGenericTypeMap.get("CONSTANT_FACTORY").getSimpleName());

        predicate = new Predicate() {
            public boolean evaluate(Object object) {
                return ((Method) object).getName().equals("newFactory");
            }
        };
        res = (Method) CollectionUtils.find(methodList, predicate);
        Assert.assertNotNull(res);
        Assert.assertSame(res.getName(), "newFactory");
        //Assert.assertSame(res.getReturnType().getClass().getSimpleName(), factoryGenericTypeMap.get("CONSTANT_FACTORY").getSimpleName());

        predicate = new Predicate() {
            public boolean evaluate(Object object) {
                return ((Method) object).getName().equals("buildUpon");
            }
        };
        res = (Method) CollectionUtils.find(methodList, predicate);
        Assert.assertNotNull(res);
        Assert.assertSame(res.getName(), "buildUpon");
        //Assert.assertSame(res.getReturnType().getClass().getSimpleName(), factoryGenericTypeMap.get("BASE").getSimpleName());

        predicate = new Predicate() {
            public boolean evaluate(Object object) {
                return ((Method) object).getName().equals("toExample");
            }
        };
        res = (Method) CollectionUtils.find(methodList, predicate);
        Assert.assertNotNull(res);
        Assert.assertSame(res.getName(), "toExample");
        //Assert.assertSame(res.getReturnType().getClass().getSimpleName(), factoryGenericTypeMap.get("BASE").getSimpleName());
    }

}
