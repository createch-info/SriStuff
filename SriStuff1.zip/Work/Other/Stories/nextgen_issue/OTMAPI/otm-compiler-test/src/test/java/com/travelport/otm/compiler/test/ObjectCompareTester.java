/**
 *
 */
package com.travelport.otm.compiler.test;

import org.unitils.reflectionassert.ReflectionAssert;

public class ObjectCompareTester {

    public static boolean compareObjects(Object firstObject, Object secondObject) throws IllegalArgumentException, IllegalAccessException {
        boolean comparionResult = true;
        ReflectionAssert.assertReflectionEquals(firstObject, secondObject);
        return comparionResult;
    }

}
