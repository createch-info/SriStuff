/**
 *
 */
package com.travelport.otm.compiler.test;

import com.travelport.otm.jaxb.OTMContextFactory;
import com.travelport.otm.jaxb.runtime.OTMJAXBContext;
import com.travelport.otm.jaxb.runtime.OTMJAXBContext.MediaType;
import com.travelport.otm.jaxb.runtime.OTMMarshaller;
import com.travelport.otm.jaxb.runtime.unmarshaller.OTMUnmarshaller;
import com.travelport.otm.test.TestCoreObject2;

import javax.xml.bind.JAXBContext;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * @author Eric.Bronson
 */
public class PerformanceTestsJSONApp {
    private static JAXBContext ctx;
    private static OTMMarshaller m;
    private static OTMUnmarshaller unm;

    private ByteArrayInputStream in;
    private ByteArrayOutputStream out;

    private ByteArrayInputStream in2;
    private ByteArrayOutputStream out2;

    public PerformanceTestsJSONApp() throws Exception {
        ctx = OTMContextFactory.createContext();
        unm = (OTMUnmarshaller) ctx.createUnmarshaller();
        m = (OTMMarshaller) ctx.createMarshaller();
        unm.setProperty(OTMUnmarshaller.ENABLE_VALIDATION, false);
        m.setProperty(OTMMarshaller.ENABLE_VALIDATION, false);
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);

        File file = new File(
                "target/resources/schemas/examples/TestLibrary_0_0_0/TestCoreObject2.json");
        Path path = Paths.get(file.toURI());
        byte[] bytes = Files.readAllBytes(path);
        in = new ByteArrayInputStream(bytes);
        out = new ByteArrayOutputStream(bytes.length);
        System.out.println(bytes.length);

    }

    public static void main(String[] args) {
        PerformanceTestsJSONApp app;
        try {
            app = new PerformanceTestsJSONApp();
            while (true) {
                app.run();
            }
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }

    }

    /**
     * @throws java.lang.Exception public void setUp() throws Exception {
     *                             <p>
     *                             }
     *                             <p>
     *                             /**
     * @throws java.lang.Exception
     */
    public void tearDown() throws Exception {
        if (in != null) {
            in.close();
        }
        if (out != null) {
            out.close();
        }

        if (in2 != null) {
            in2.close();
        }
        if (out2 != null) {
            out2.close();
        }
    }

    public void run() throws Exception {
        TestCoreObject2 core2 = (TestCoreObject2) unm.unmarshal(in,
                TestCoreObject2.class);
        m.marshal(core2, out);
        out.reset();
        in.reset();
    }
}
