package com.travelport.otm.compiler.test.util;

import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "TestClass2")
@XmlType(name = "TestClass2", propOrder = {"element"})
public class TestClass2 {

    @XmlElementRef
    private TestElement element;

    public TestClass2() {
        // TODO Auto-generated constructor stub
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((element == null) ? 0 : element.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TestClass2 other = (TestClass2) obj;
        if (element == null) {
            if (other.element != null)
                return false;
        } else if (!element.equals(other.element))
            return false;
        return true;
    }

    public TestElement getElement() {
        return element;
    }

    public void setElement(TestElement element) {
        this.element = element;
    }
}
