package com.travelport.otm.compiler.test;

import com.travelport.otm.jaxb.OTMContextFactory;
import com.travelport.otm.jaxb.runtime.OTMJAXBContext;
import com.travelport.otm.jaxb.runtime.OTMJAXBContext.MediaType;
import com.travelport.otm.jaxb.runtime.unmarshaller.OTMUnmarshaller;
import com.travelport.otm.test.TestJodaFlightInfoObject;
import com.travelport.otm.test.TestJodaVWA1;
import com.travelport.otm.test.TestJodaVWA2;
import org.joda.time.*;
import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Scanner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

// Create marshaller and unmarshaller for each test case, otherwise thread conflict (cross pollution) would occur.
public class JodaCompilerRuntimeTest {

    private static JAXBContext ctx;
    private static Marshaller m;
    private static OTMUnmarshaller unm;
    @Rule
    // The TemporaryFolder Rule allows creation of files and folders that should
    // be deleted when the test method finishes
    public TemporaryFolder tempFolder = new TemporaryFolder();
    private File fXml;
    private FileOutputStream fosXml;
    private boolean debug = false;
    private Scanner scanner;
    // Create a temporary file.
    private File tempFile;

    @BeforeClass
    public static void setupBeforeClass() throws Exception {
        System.setProperty(JAXBContext.JAXB_CONTEXT_FACTORY, "com.travelport.otm.jaxb.OTMContextFactory");
        System.setProperty(OTMJAXBContext.BUILD_SCHEMAS, "true");
        ctx = OTMContextFactory.createContext();
        unm = (OTMUnmarshaller) ctx.createUnmarshaller();
        m = ctx.createMarshaller();
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        unm.setEventHandler(new TestValidationEventHandler());
        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception {
        if (fosXml != null) {
            fosXml.close();
        }

        if (tempFile != null) {
            tempFile.delete();
        }
        if (fXml != null) {
            fXml.delete();
        }

        System.clearProperty(OTMJAXBContext.SET_MILLIS);
    }

    /***************************** XSDDateTimeTests ***********************/
    @Test
    public void testItShouldConvertXSDDateTimeWithMillisToJodaTimes() throws Exception {
        DateTimeZone.setDefault(DateTimeZone.UTC);
        System.setProperty(OTMJAXBContext.SET_MILLIS, "true");
        TestJodaFlightInfoObject tjc = new TestJodaFlightInfoObject();
        DateTime dt = new DateTime(2011, 5, 30, 11, 2, 30, 567);
        tjc.setDepartureDateTime(dt);
        LocalDate date = new LocalDate(2011, 5, 30);
        tjc.setArrivalDate(date);
        File xmlJodaFile = tempFolder.newFile("testOutputXml");
        m.marshal(tjc, xmlJodaFile);

        if (debug)
            m.marshal(tjc, System.out);
        scanner = new Scanner(xmlJodaFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains("2011-05-30"));
            assertTrue(lineFromFile.contains("2011-05-30T11:02:30.567Z"));
        }
        scanner.close();

        TestJodaFlightInfoObject tjc2 = (TestJodaFlightInfoObject) unm.unmarshal(xmlJodaFile);
        assertTrue(tjc2.getDepartureDateTime().equals(dt));
        assertTrue(tjc2.getArrivalDate().equals(date));
    }

    @Test
    public void testItShouldConvertXSDDateTimeWithNoMillisToJodaTimes() throws Exception {
        DateTimeZone.setDefault(DateTimeZone.UTC);
        TestJodaFlightInfoObject tjc = new TestJodaFlightInfoObject();
        DateTime dt = new DateTime(2011, 5, 30, 11, 2, 30, 0);
        tjc.setDepartureDateTime(dt);
        LocalDate date = new LocalDate(2011, 5, 30);
        tjc.setArrivalDate(date);
        File xmlJodaFile = tempFolder.newFile("testOutputXml");
        m.marshal(tjc, xmlJodaFile);

        if (debug)
            m.marshal(tjc, System.out);
        scanner = new Scanner(xmlJodaFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains("2011-05-30"));
            assertTrue(lineFromFile.contains("2011-05-30T11:02:30Z"));
        }
        scanner.close();

        TestJodaFlightInfoObject tjc2 = (TestJodaFlightInfoObject) unm.unmarshal(xmlJodaFile);
        assertTrue(tjc2.getDepartureDateTime().equals(dt));
        assertTrue(tjc2.getArrivalDate().equals(date));
    }

    /***************************** LocalDateTimeTests ***********************/

    @Test
    public void testItShouldConvertLocalDateTimeToJodaDateTimeWithNoMillis() throws Exception {
        String dateTime = "2002-05-30T09:00:00";
        LocalDateTime localDateTime = new LocalDateTime(dateTime);

        TestJodaVWA2 jodaTime = new TestJodaVWA2();
        jodaTime.setDateTime(localDateTime);

        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        tempFile = tempFolder.newFile("testOutputXml");
        fosXml = new FileOutputStream(tempFile);
        m.marshal(jodaTime, fosXml);
        if (debug)
            m.marshal(jodaTime, System.out);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains(dateTime));
        }
        scanner.close();

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        TestJodaVWA2 jodaTime2 = (TestJodaVWA2) unm.unmarshal(tempFile);
        assertEquals("Marshal and Unmarshal is not successful", localDateTime, jodaTime2.getDateTime());

        String dateTimeWithMillis = "2002-05-30T09:00:00.03";
        jodaTime = new TestJodaVWA2();
        jodaTime.setDateTime(new LocalDateTime(dateTimeWithMillis));

        tempFile = tempFolder.newFile("testOutputXml2");
        fosXml = new FileOutputStream(tempFile);
        m.marshal(jodaTime, fosXml);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains(dateTime));
        }
        scanner.close();

        jodaTime2 = (TestJodaVWA2) unm.unmarshal(tempFile);
        assertEquals("Marshal and Unmarshal is not successful", localDateTime, jodaTime2.getDateTime());
    }

    @Test
    public void testItShouldConvertLocalDateTimeToJodaDateTimeWithMillis() throws Exception {
        String dateTime = "2002-05-30T09:00:00";
        LocalDateTime localDateTime = new LocalDateTime(dateTime);

        System.setProperty(OTMJAXBContext.SET_MILLIS, "true");
        TestJodaVWA2 jodaTime = new TestJodaVWA2();
        jodaTime.setDateTime(localDateTime);

        tempFile = tempFolder.newFile("testOutputXml");
        fosXml = new FileOutputStream(tempFile);
        m.marshal(jodaTime, fosXml);
        if (debug)
            m.marshal(jodaTime, System.out);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains(localDateTime.toString()));
        }
        scanner.close();

        TestJodaVWA2 jodaTime2 = (TestJodaVWA2) unm.unmarshal(tempFile);
        assertEquals("Marshal and Unmarshal is not successful", localDateTime, jodaTime2.getDateTime());

        dateTime = "2002-05-30T09:00:00.03";
        localDateTime = new LocalDateTime(dateTime);

        jodaTime = new TestJodaVWA2();
        jodaTime.setDateTime(localDateTime);

        tempFile = tempFolder.newFile("testOutputXml2");
        fosXml = new FileOutputStream(tempFile);
        if (debug)
            m.marshal(jodaTime, System.out);
        m.marshal(jodaTime, fosXml);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains(localDateTime.toString()));
        }
        scanner.close();

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        jodaTime2 = (TestJodaVWA2) unm.unmarshal(tempFile);
        assertEquals("Marshal and Unmarshal is not successful", localDateTime, jodaTime2.getDateTime());
    }

    /*************************** LocalTimeTests ****************************/

    @Test
    public void testItShouldConvertLocalTimeToJodaTimeWithMillis() throws Exception {
        String time = "09:00:00";
        LocalTime localTime = new LocalTime(time);
        System.setProperty(OTMJAXBContext.SET_MILLIS, "true");
        TestJodaVWA1 jodaTime = new TestJodaVWA1();
        jodaTime.setTimeAtr(localTime);

        tempFile = tempFolder.newFile("testOutputXml");
        fosXml = new FileOutputStream(tempFile);
        if (debug)
            m.marshal(jodaTime, System.out);
        m.marshal(jodaTime, fosXml);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains(localTime.toString()));
        }
        scanner.close();

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        TestJodaVWA1 jodaTime2 = (TestJodaVWA1) unm.unmarshal(tempFile);
        assertEquals("Marshal and Unmarshal is not successful", localTime, jodaTime2.getTimeAtr());

        // with milliseconds position 1
        time = "09:30:10.5";
        localTime = new LocalTime(time);

        jodaTime = new TestJodaVWA1();
        jodaTime.setTimeAtr(localTime);

        tempFile = tempFolder.newFile("testOutputXml2");
        fosXml = new FileOutputStream(tempFile);
        if (debug)
            m.marshal(jodaTime, System.out);
        m.marshal(jodaTime, fosXml);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains(time));
        }
        scanner.close();

        jodaTime2 = (TestJodaVWA1) unm.unmarshal(tempFile);
        assertEquals("Marshal and Unmarshal is not successful", localTime, jodaTime2.getTimeAtr());

        // with milliseconds 3 positions
        time = "09:30:10.556";
        localTime = new LocalTime(time);

        jodaTime = new TestJodaVWA1();
        jodaTime.setTimeAtr(localTime);

        tempFile = tempFolder.newFile("testOutputXml3");
        fosXml = new FileOutputStream(tempFile);
        if (debug)
            m.marshal(jodaTime, System.out);
        m.marshal(jodaTime, fosXml);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains(time));
        }
        scanner.close();

        jodaTime2 = (TestJodaVWA1) unm.unmarshal(tempFile);
        assertEquals("Marshal and Unmarshal is not successful", localTime, jodaTime2.getTimeAtr());
    }

    @Test
    public void testItShouldConvertLocalTimeToJodaTimeWithNoMillis() throws Exception {
        String time = "09:00:00";
        LocalTime localTime = new LocalTime(time);

        TestJodaVWA1 jodaTime = new TestJodaVWA1();
        jodaTime.setTimeAtr(localTime);

        tempFile = tempFolder.newFile("testOutputXml");
        fosXml = new FileOutputStream(tempFile);
        if (debug)
            m.marshal(jodaTime, System.out);
        m.marshal(jodaTime, fosXml);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains(time));
        }
        scanner.close();

        TestJodaVWA1 jodaTime2 = (TestJodaVWA1) unm.unmarshal(tempFile);
        assertEquals("Marshal and Unmarshal is not successful", localTime, jodaTime2.getTimeAtr());

        // with milliseconds position 1
        time = "09:30:10.5";
        localTime = new LocalTime(time);
        jodaTime = new TestJodaVWA1();
        jodaTime.setTimeAtr(localTime);

        LocalTime localTimeNoMillis = new LocalTime("09:30:10");
        tempFile = tempFolder.newFile("testOutputXml2");
        fosXml = new FileOutputStream(tempFile);
        if (debug)
            m.marshal(jodaTime, System.out);
        m.marshal(jodaTime, fosXml);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains("09:30:10"));
        }
        scanner.close();

        jodaTime2 = (TestJodaVWA1) unm.unmarshal(tempFile);
        assertEquals("Marshal and Unmarshal is not successful", localTimeNoMillis, jodaTime2.getTimeAtr());

        // with milliseconds 3 positions
        time = "09:30:10.556";
        localTime = new LocalTime(time);

        jodaTime = new TestJodaVWA1();
        jodaTime.setTimeAtr(localTime);

        tempFile = tempFolder.newFile("testOutputXml3");
        fosXml = new FileOutputStream(tempFile);
        if (debug)
            m.marshal(jodaTime, System.out);
        m.marshal(jodaTime, fosXml);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains("09:30:10"));
        }
        scanner.close();

        jodaTime2 = (TestJodaVWA1) unm.unmarshal(tempFile);
        assertEquals("Marshal and Unmarshal is not successful", localTimeNoMillis, jodaTime2.getTimeAtr());
    }

    @Test
    public void testItShouldConvertLocalDateToJodaDate() throws Exception {
        String dateString = "2011-01-24";
        LocalDate dateObject = new LocalDate(dateString);

        TestJodaVWA1 jodaDate = new TestJodaVWA1();
        jodaDate.setDateAtr(dateObject);

        tempFile = tempFolder.newFile("testOutputXml");
        fosXml = new FileOutputStream(tempFile);
        if (debug)
            m.marshal(jodaDate, System.out);
        m.marshal(jodaDate, fosXml);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains("2011-01-24"));
        }
        scanner.close();

        TestJodaVWA1 jodaDate2 = (TestJodaVWA1) unm.unmarshal(tempFile);
        LocalDate localDate = new LocalDate("2011-01-24");
        assertEquals("Marshal and Unmarshal is not successful", localDate, jodaDate2.getDateAtr());
    }

    /********************************************* UTCDateTests ****************************************************/
    @Test
    public void testItShouldConvertUTCLocalDateToJodaDate() throws Exception {
        String dateString = "2011-01-24";
        LocalDate dateObject = new LocalDate(dateString);

        TestJodaVWA1 jodaDate = new TestJodaVWA1();
        jodaDate.setDateAtr(dateObject);

        tempFile = tempFolder.newFile("testOutputXml");
        fosXml = new FileOutputStream(tempFile);
        m.marshal(jodaDate, fosXml);
        if (debug)
            m.marshal(jodaDate, System.out);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains("2011-01-24"));
        }
        scanner.close();

        TestJodaVWA1 jodaDate2 = (TestJodaVWA1) unm.unmarshal(tempFile);
        LocalDate localDate = new LocalDate("2011-01-24");
        assertEquals("Marshal and Unmarshal is not successful", localDate, jodaDate2.getDateAtr());
    }

    @Test
    public void testItShouldConvertZuluLocalDateToJodaDate() throws Exception {
        // to test pattern yyyy-MM-ddZ

        File file = new File("src/test/resources/zuluUTCDateAndUTCTime.xml");

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        TestJodaVWA1 jodaDate2 = (TestJodaVWA1) unm.unmarshal(file);
        assertEquals("Marshal and Unmarshal is not successful", new LocalDate("2002-09-24"), jodaDate2.getDateAtr());
    }

    @Test
    public void testItShouldConvertUTCLocalDateWithOffsetToJodaDate() throws Exception {
        // to test pattern yyyy-MM-dd-hh

        File file = new File("src/test/resources/offsetUTCDateAndUTCTime.xml");

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        TestJodaVWA1 jodaDate2 = (TestJodaVWA1) unm.unmarshal(file);
        assertEquals("Marshal and Unmarshal is not successful", new LocalDate("2002-09-24"), jodaDate2.getDateAtr());
    }

    /********************************************* UTCTimeTests ****************************************************/

    @Test
    public void testItShouldConvertUTCLocalTimeWithOffsetToJodaTime() throws Exception {
        // to test pattern HH-mm-ss(-/+)hh

        File file = new File("src/test/resources/offsetUTCDateAndUTCTime.xml");

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        TestJodaVWA1 jodaDate2 = (TestJodaVWA1) unm.unmarshal(file);
        assertEquals("Marshal and Unmarshal is not successful", new LocalTime("15:30:10"), jodaDate2.getTimeAtr());
    }

    @Test
    public void testItShouldConvertZuluLocalTimeToJodaTime() throws Exception {
        // to test pattern yyyy-MM-dd-hh

        File file = new File("src/test/resources/zuluUTCDateAndUTCTime.xml");

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        TestJodaVWA1 jodaDate2 = (TestJodaVWA1) unm.unmarshal(file);
        assertEquals("Marshal and Unmarshal is not successful", new LocalTime("09:30:10"), jodaDate2.getTimeAtr());
    }

    @Test
    public void testItShouldConvertUTCLocalTimeToJodaTimeWithNoMillis() throws Exception {
        String time = "09:00:00";
        LocalTime localTime = new LocalTime(time);

        TestJodaVWA1 jodaTime = new TestJodaVWA1();
        jodaTime.setTimeAtr(localTime);

        tempFile = tempFolder.newFile("testOutputXml");
        fosXml = new FileOutputStream(tempFile);
        m.marshal(jodaTime, fosXml);
        if (debug)
            m.marshal(jodaTime, System.out);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains(time));
        }
        scanner.close();

        TestJodaVWA1 jodaTime2 = (TestJodaVWA1) unm.unmarshal(tempFile);
        assertEquals("Marshal and Unmarshal is not successful", localTime, jodaTime2.getTimeAtr());
    }

    @Test
    public void testItShouldConvertUTCLocalTimeToJodaTimeWithMillis() throws Exception {
        System.setProperty(OTMJAXBContext.SET_MILLIS, "true");
        String time = "09:00:00.565";
        LocalTime localTime = new LocalTime(time);

        TestJodaVWA1 jodaTime = new TestJodaVWA1();
        jodaTime.setTimeAtr(localTime);

        tempFile = tempFolder.newFile("testOutputXml");
        fosXml = new FileOutputStream(tempFile);
        m.marshal(jodaTime, fosXml);
        if (debug)
            m.marshal(jodaTime, System.out);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains(time));
        }
        scanner.close();

        TestJodaVWA1 jodaTime2 = (TestJodaVWA1) unm.unmarshal(tempFile);
        assertEquals("Marshal and Unmarshal is not successful", localTime, jodaTime2.getTimeAtr());

        time = "09:00:00.5";
        localTime = new LocalTime(time);

        jodaTime = new TestJodaVWA1();
        jodaTime.setTimeAtr(localTime);

        tempFile = tempFolder.newFile("testOutputXml2");
        fosXml = new FileOutputStream(tempFile);
        m.marshal(jodaTime, fosXml);
        if (debug)
            m.marshal(jodaTime, System.out);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains(time));
        }
        scanner.close();

        jodaTime2 = (TestJodaVWA1) unm.unmarshal(tempFile);
        assertEquals("Marshal and Unmarshal is not successful", localTime, jodaTime2.getTimeAtr());
    }

    @Test
    public void testToConvertUTCDateTimeWithOffsetNoMillisToJodaDateTime() throws Exception {

        TestJodaFlightInfoObject jodaObject = new TestJodaFlightInfoObject();

        // one with positive offset
        DateTime timeObject = new DateTime(2011, 2, 3, 10, 15, 0, 0, DateTimeZone.forID("America/Los_Angeles"));
        jodaObject.setArivalDateTime(timeObject);

        tempFile = tempFolder.newFile("testOutputXml");
        fosXml = new FileOutputStream(tempFile);
        m.marshal(jodaObject, fosXml);
        if (debug)
            m.marshal(jodaObject, System.out);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains("2011-02-03T10:15:00-08:00"));
        }
        scanner.close();

        TestJodaFlightInfoObject jodaObject2 = (TestJodaFlightInfoObject) unm.unmarshal(tempFile);
        assertEquals("Marshal and Unmarshal is not successful", new DateTime("2011-02-03T11:15:00.000-07:00"),
                jodaObject2.getArivalDateTime());

        // one with negative offset
        timeObject = new DateTime(2011, 2, 3, 10, 15, 7, 345, DateTimeZone.forID("Asia/Kolkata"));
        jodaObject.setArivalDateTime(timeObject);

        tempFile = tempFolder.newFile("testOutputXml3");
        fosXml = new FileOutputStream(tempFile);
        m.marshal(jodaObject, fosXml);
        if (debug)
            m.marshal(jodaObject, System.out);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains("2011-02-03T10:15:07+05:30"));
        }
        scanner.close();

        jodaObject2 = (TestJodaFlightInfoObject) unm.unmarshal(tempFile);

        // As for the time zone shifting at unmarshal they should be fine since
        // the time instant (the long integer value representing the number of
        // millis since midnight on 1/1/1970) resolves to be the same
        assertEquals("Marshal and Unmarshal is not successful", new DateTime("2011-02-02T21:45:07.000-07:00"),
                jodaObject2.getArivalDateTime());
    }

    @Test
    public void testToConvertUTCDateTimeWithOffsetWithMillisToJodaDateTime() throws Exception {

        System.setProperty(OTMJAXBContext.SET_MILLIS, "true");
        TestJodaFlightInfoObject jodaObject = new TestJodaFlightInfoObject();
        // one with negative offset
        DateTime timeObject = new DateTime(2011, 2, 3, 10, 15, 33, 555, DateTimeZone.forID("America/Los_Angeles"));
        jodaObject.setArivalDateTime(timeObject);

        tempFile = tempFolder.newFile("testOutputXml");
        fosXml = new FileOutputStream(tempFile);
        m.marshal(jodaObject, fosXml);
        if (debug)
            m.marshal(jodaObject, System.out);
        Scanner scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains("2011-02-03T10:15:33.555-08:00"));
        }
        scanner.close();

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        TestJodaFlightInfoObject jodaObject2 = (TestJodaFlightInfoObject) unm.unmarshal(tempFile);
        assertEquals("Marshal and Unmarshal is not successful", new DateTime("2011-02-03T11:15:33.555-07:00"),
                jodaObject2.getArivalDateTime());

        // one with positive offset
        timeObject = new DateTime(2011, 2, 3, 10, 15, 7, 345, DateTimeZone.forID("Asia/Kolkata"));
        jodaObject.setArivalDateTime(timeObject);

        tempFile = tempFolder.newFile("testOutputXml2");
        fosXml = new FileOutputStream(tempFile);
        m.marshal(jodaObject, fosXml);
        if (debug)
            m.marshal(jodaObject, System.out);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains("2011-02-03T10:15:07.345+05:30"));
        }
        scanner.close();

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        jodaObject2 = (TestJodaFlightInfoObject) unm.unmarshal(tempFile);

        // As for the time zone shifting at unmarshal they should be fine since
        // the time instant(the long integer value representing the number of
        // millis since midnight on 1/1/1970) resolves to be the same
        assertEquals("Marshal and Unmarshal is not successful", new DateTime("2011-02-02T21:45:07.345-07:00"),
                jodaObject2.getArivalDateTime());

    }

    @Test
    public void testToConvertUTCDateTimeWithNoMillisToJodaDateTime() throws Exception {
        DateTimeZone.setDefault(DateTimeZone.UTC);
        TestJodaFlightInfoObject jodaObject = new TestJodaFlightInfoObject();
        DateTime timeObject = new DateTime(2002, 5, 30, 9, 30, 10, 567);
        jodaObject.setArivalDateTime(timeObject);

        tempFile = tempFolder.newFile("testOutputXml");
        fosXml = new FileOutputStream(tempFile);
        m.marshal(jodaObject, fosXml);
        if (debug)
            m.marshal(jodaObject, System.out);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains("2002-05-30T09:30:10Z"));
        }
        scanner.close();

        TestJodaFlightInfoObject jodaObject2 = (TestJodaFlightInfoObject) unm.unmarshal(tempFile);
        // timeObject2 is timeObject1 without millis
        DateTime timeObject2 = new DateTime("2002-05-30T09:30:10");
        assertEquals("Marshal and Unmarshal is not successful", timeObject2, jodaObject2.getArivalDateTime());
    }

    @Test
    public void testToConvertUTCDateTimeWithMillisToJodaDateTime() throws Exception {
        System.setProperty(OTMJAXBContext.SET_MILLIS, "true");
        DateTimeZone.setDefault(DateTimeZone.UTC);
        TestJodaFlightInfoObject jodaObject = new TestJodaFlightInfoObject();
        DateTime timeObject = new DateTime("2002-05-30T09:30:10.567");

        jodaObject.setArivalDateTime(timeObject);

        tempFile = tempFolder.newFile("testOutputXml");
        fosXml = new FileOutputStream(tempFile);
        m.marshal(jodaObject, fosXml);
        if (debug)
            m.marshal(jodaObject, System.out);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains("2002-05-30T09:30:10.567Z"));
        }
        scanner.close();

        TestJodaFlightInfoObject jodaObject2 = (TestJodaFlightInfoObject) unm.unmarshal(tempFile);
        assertEquals("Marshal and Unmarshal is not successful", timeObject, jodaObject2.getArivalDateTime());

        // millis with 2 positions after '.'
        timeObject = new DateTime("2002-05-30T09:30:10.67");
        jodaObject.setArivalDateTime(timeObject);

        tempFile = tempFolder.newFile("testOutputXml2");
        fosXml = new FileOutputStream(tempFile);
        m.marshal(jodaObject, fosXml);
        if (debug)
            m.marshal(jodaObject, System.out);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains("2002-05-30T09:30:10.670Z"));
        }
        scanner.close();

        jodaObject2 = (TestJodaFlightInfoObject) unm.unmarshal(tempFile);
        assertEquals("Marshal and Unmarshal is not successful", timeObject, jodaObject2.getArivalDateTime());

        // millis with 1 positions after '.'
        timeObject = new DateTime("2002-05-30T09:30:10.6");
        jodaObject.setArivalDateTime(timeObject);

        tempFile = tempFolder.newFile("testOutputXml3");
        fosXml = new FileOutputStream(tempFile);
        m.marshal(jodaObject, fosXml);
        if (debug)
            m.marshal(jodaObject, System.out);
        scanner = new Scanner(tempFile);
        while (scanner.hasNextLine()) {
            String lineFromFile = scanner.nextLine();
            assertTrue(lineFromFile.contains("2002-05-30T09:30:10.600Z"));
        }
        scanner.close();

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        jodaObject2 = (TestJodaFlightInfoObject) unm.unmarshal(tempFile);
        assertEquals("Marshal and Unmarshal is not successful", timeObject, jodaObject2.getArivalDateTime());
    }

    @Test
    public void testToUnmarshalDateTimeObjectInZuluWithNoMillis() throws Exception {
        DateTimeZone.setDefault(DateTimeZone.UTC);
        File file = new File("src/test/resources/zuluUTCDateTime.xml");

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        TestJodaFlightInfoObject jodaObject = (TestJodaFlightInfoObject) unm.unmarshal(file);
        DateTime timeObject = new DateTime("2002-05-30T09:30:10Z");

        assertEquals("Marshal and Unmarshal is not successful", timeObject, jodaObject.getArivalDateTime());
    }

}
