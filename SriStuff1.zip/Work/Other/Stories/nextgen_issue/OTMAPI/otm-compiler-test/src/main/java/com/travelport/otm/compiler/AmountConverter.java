package com.travelport.otm.compiler;

import com.travelport.otm.jaxb.converters.OTMJavaTypeConverter;
import com.travelport.otm.test._2.Amount;

public class AmountConverter extends OTMJavaTypeConverter<Amount, Double> {

    @Override
    public boolean isConvertible(Class<?> actual, Class<?> other) {
        return actual.equals(Amount.class) && other.equals(Double.class);
    }

    @Override
    public Double marshall(Amount field, String version, Object parent) {
        return field.getValue();
    }

    @Override
    public Amount unmarshall(Double value, String version, Object parent) {
        Amount amount = new Amount();
        amount.setValue(value);
        return amount;

    }
}
