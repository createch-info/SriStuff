/**
 *
 */
package com.travelport.otm.compiler.test.util;

import com.travelport.otm.jaxb.runtime.URType;

import javax.xml.bind.annotation.*;
import java.util.List;

/**
 * @author eric.bronson
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "TestClass")
@XmlType(name = "TestClass", propOrder = {"prop1", "prop2", "values", "elements"})
@XmlSeeAlso({TestClassSub.class})
public class TestClass implements URType {

    @XmlElement(name = "Prop1")
    private String prop1;
    @XmlAttribute(name = "att1")
    private int att1;
    @XmlElement(name = "Value")
    private List<String> values;
    @XmlElementRef(name = "TestElement")
    private List<TestElement> elements;
    @XmlElement
    private TestClass2 prop2;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + att1;
        result = prime * result
                + ((elements == null) ? 0 : elements.hashCode());
        result = prime * result + ((prop1 == null) ? 0 : prop1.hashCode());
        result = prime * result + ((prop2 == null) ? 0 : prop2.hashCode());
        result = prime * result + ((values == null) ? 0 : values.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TestClass other = (TestClass) obj;
        if (att1 != other.att1)
            return false;
        if (elements == null) {
            if (other.elements != null)
                return false;
        } else if (!elements.equals(other.elements))
            return false;
        if (prop1 == null) {
            if (other.prop1 != null)
                return false;
        } else if (!prop1.equals(other.prop1))
            return false;
        if (prop2 == null) {
            if (other.prop2 != null)
                return false;
        } else if (!prop2.equals(other.prop2))
            return false;
        if (values == null) {
            if (other.values != null)
                return false;
        } else if (!values.equals(other.values))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "TestClass [prop1=" + prop1 + ", att1=" + att1 + ", values="
                + values + ", elements=" + elements + ", prop2=" + prop2 + "]";
    }

    public String getProp1() {
        return prop1;
    }

    public void setProp1(String prop1) {
        this.prop1 = prop1;
    }

    public int getAtt1() {
        return att1;
    }

    public void setAtt1(int att1) {
        this.att1 = att1;
    }

    public List<String> getValues() {
        return values;
    }

    public void setValues(List<String> values) {
        this.values = values;
    }

    public List<TestElement> getElements() {
        return elements;
    }

    public void setElements(List<TestElement> elements) {
        this.elements = elements;
    }

    /**
     * @return the prop2
     */
    public TestClass2 getProp2() {
        return prop2;
    }

    /**
     * @param prop2 the prop2 to set
     */
    public void setProp2(TestClass2 prop2) {
        this.prop2 = prop2;
    }


}
