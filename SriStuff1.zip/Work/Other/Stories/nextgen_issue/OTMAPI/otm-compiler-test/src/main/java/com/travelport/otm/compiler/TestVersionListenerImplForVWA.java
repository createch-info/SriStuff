/*
 * Copyright (c) 2016, Travelport.  All Rights Reserved.
 * Use is subject to license agreement.
 */
package com.travelport.otm.compiler;

import com.travelport.otm.jaxb.runtime.OTMVersionListener;
import com.travelport.otm.test.TestVWA;

/**
 * <PRE>
 * TestVersionListenerImplForVWA implements methods for OTMVersionListener of type TestVWA.
 * <p>
 * NOTES:
 * 1. Place any additional notes here. Here are some items that may apply.
 * 2. This class is NOT meant to be sub-classed.
 * 3. Thread-Safe = NO
 * 4. External Service Dependencies = NONE
 * <p>
 * </PRE>
 *
 * @author Nasreen.Basheer
 */
public class TestVersionListenerImplForVWA implements OTMVersionListener<TestVWA> {

    @Override
    public TestVWA beforeMarshal(TestVWA source, String version) {
        source.setAttribute1("att1AtMarshal");
        source.setIndicator1Ind(true);
        return source;
    }

    @Override
    public void afterUnmarshal(TestVWA target, String version) {
        if (target != null) {
            target.setVersion1Attribute("version1AttributeAtUnmarshal");
            target.setIndicator1Ind(true);
        }
    }
}