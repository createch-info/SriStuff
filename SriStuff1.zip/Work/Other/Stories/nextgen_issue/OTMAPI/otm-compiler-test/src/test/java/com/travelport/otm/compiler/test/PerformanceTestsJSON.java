/**
 *
 */
package com.travelport.otm.compiler.test;

import com.travelport.otm.jaxb.OTMContextFactory;
import com.travelport.otm.jaxb.runtime.OTMJAXBContext;
import com.travelport.otm.jaxb.runtime.OTMJAXBContext.MediaType;
import com.travelport.otm.jaxb.runtime.unmarshaller.OTMUnmarshaller;
import com.travelport.otm.test.TestCoreObject2;
import org.databene.contiperf.PerfTest;
import org.databene.contiperf.junit.ContiPerfRule;
import org.junit.*;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * @author Eric.Bronson
 */
@PerfTest(duration = 11000, threads = 1, warmUp = 1000)
public class PerformanceTestsJSON {
    private static JAXBContext ctx;
    private static Marshaller m;
    private static OTMUnmarshaller unm;
    @Rule
    public ContiPerfRule i = new ContiPerfRule();
    private ByteArrayInputStream in;


//	ObjectMapper mapper = new ObjectMapper().registerModule(new JaxbAnnotationModule());
//	ObjectReader reader = mapper.reader(TestCoreObject2Detail.class).with(DeserializationFeature.UNWRAP_ROOT_VALUE);
//	ObjectWriter writer = mapper.writerFor(TestCoreObject2Detail.class).with(SerializationFeature.WRAP_ROOT_VALUE);
    private ByteArrayOutputStream out;

    @BeforeClass
    public static void setup() throws Exception {
        ctx = OTMContextFactory.createContext();
        unm = (OTMUnmarshaller) ctx.createUnmarshaller();
        m = ctx.createMarshaller();

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.JSON);
    }


    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
        File file = new File(
                "target/resources/json/examples/TestLibrary_0_0_0/TestCoreObject2.json");
        Path path = Paths.get(file.toURI());
        byte[] bytes = Files.readAllBytes(path);
        in = new ByteArrayInputStream(bytes);
        out = new ByteArrayOutputStream(bytes.length);
        System.out.println(bytes.length);

    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception {
        if (in != null) {
            in.close();
        }
        if (out != null) {
            out.close();
        }

    }

    @Test
    public void testTestCoreObject2Json() throws Exception {
        //long t = System.currentTimeMillis();
        TestCoreObject2 core2 = (TestCoreObject2) unm.unmarshal(in, TestCoreObject2.class);
        m.marshal(core2, out);
        out.reset();
        in.reset();
        //System.out.println(System.currentTimeMillis() - t);
    }


}
