/**
 *
 */
package com.travelport.otm.compiler.test;

import com.travelport.otm.jaxb.OTMContextFactory;
import com.travelport.otm.jaxb.runtime.OTMJAXBContext;
import com.travelport.otm.jaxb.runtime.OTMJAXBContext.MediaType;
import com.travelport.otm.jaxb.runtime.OTMMarshaller;
import com.travelport.otm.jaxb.runtime.unmarshaller.OTMUnmarshaller;
import com.travelport.otm.test._2.VersionedCoreObject;
import com.travelport.otm.test._2.VersionedCoreObjectDetail;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * @author Eric.Bronson
 */
public class PerformanceTestsXMLApp {
    private static JAXBContext ctx;
    private static Marshaller m;
    private static OTMUnmarshaller unm;
    private ByteArrayInputStream in;
    private ByteArrayOutputStream out;

    private ByteArrayInputStream in2;
    private ByteArrayOutputStream out2;
    private VersionedCoreObject vo;
    private boolean patchVersion = false;

    public PerformanceTestsXMLApp() throws Exception {
        ctx = OTMContextFactory.createContext();
        unm = (OTMUnmarshaller) ctx.createUnmarshaller();
        m = ctx.createMarshaller();

        unm.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);
        m.setProperty(OTMJAXBContext.MEDIA_TYPE, MediaType.XML);


        if (patchVersion) {
            // For patch version
            patch();
        } else {
            // for rolled over patch version
            rolledOverPatch();
        }
    }

    public static void main(String[] args) {
        PerformanceTestsXMLApp app;
        try {
            app = new PerformanceTestsXMLApp();
            while (true) {
                app.run();
            }
        } catch (Exception e1) {
            e1.printStackTrace();
        }

    }

    void patch() throws IOException, JAXBException {

        File file2 = new File(
                "src/test/resources/examples/TestLibrary2_0_0_1/VersionedCoreObjectForPerformanceTestApp.xml");
        Path path2 = Paths.get(file2.toURI());
        byte[] bytes2 = Files.readAllBytes(path2);
        in2 = new ByteArrayInputStream(bytes2);
        out2 = new ByteArrayOutputStream(bytes2.length);
        System.out.println(bytes2.length);
        vo = (VersionedCoreObjectDetail) unm.unmarshal(in2);
        String version = "1";
        m.setProperty(OTMMarshaller.OUTPUT_VERSION, version);
    }

    void rolledOverPatch() throws IOException, JAXBException {

        File file2 = new File(
                "src/test/resources/examples/TestLibrary2_2_0_0/VersionedCoreObjectForPerformanceTestApp.xml");
        Path path2 = Paths.get(file2.toURI());
        byte[] bytes2 = Files.readAllBytes(path2);
        in2 = new ByteArrayInputStream(bytes2);
        out2 = new ByteArrayOutputStream(bytes2.length);
        System.out.println(bytes2.length);
        vo = (VersionedCoreObject) unm.unmarshal(in2);
    }

    /**
     * @throws java.lang.Exception public void setUp() throws Exception {
     *                             <p>
     *                             }
     *                             <p>
     *                             /**
     * @throws java.lang.Exception
     */
    public void tearDown() throws Exception {
        if (in != null) {
            in.close();
        }
        if (out != null) {
            out.close();
        }

        if (in2 != null) {
            in2.close();
        }
        if (out2 != null) {
            out2.close();
        }
    }

    public void run() throws Exception {

        m.marshal(vo, out2);
        // m.marshal(vo, System.out);
        System.out.println();

        out2.reset();
    }

}
