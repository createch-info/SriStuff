package com.travelport.otm.compiler.test;

import org.junit.BeforeClass;
import org.junit.Test;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.HashMap;
import java.util.Map;


/**
 * @author jason.kramer
 */
public class PlainJaxbTest {

    private static JAXBContext ctx;
    private static Marshaller m;
    private static Unmarshaller unm;
    private static boolean debug = false;

    @BeforeClass
    public static void setup() throws Exception {
        try (URLClassLoader classLoader = new URLClassLoader(new URL[]
                {new File("target/generated-sources/otm")
                        .toURI().toURL()});) {
            Map<String, Object> contextProps = new HashMap<>();
            // contextProps.put(JAXBRIContext.ANNOTATION_READER, new OTMJaxbAnnotationReader());
            ctx = JAXBContext.newInstance(
                    "com.travelport.otm.test:com.travelport.otm.test._2:org.opentravel.common.message:org.opentravel.common",
                    classLoader, contextProps);

            unm = ctx.createUnmarshaller();
            m = ctx.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, new Boolean(true));
            unm.setEventHandler(new TestValidationEventHandler());

        } catch (MalformedURLException exp) {
            throw exp;
        } catch (IOException ioe) {

        }

    }


    @Test
    public void testUnmarshallTestCoreObject1() throws Exception {
        /*FileInputStream in = new FileInputStream(
				"src/test/resources/examples/TestLibrary_0_0_0/TestCoreObject2.xml");*/
        FileInputStream in = new FileInputStream(
                "target/resources/schemas/examples/TestLibrary_0_0_0/TestCoreObject2.xml");
        Object testCoreObject1 = unm.unmarshal(in);

        if (debug) m.marshal(testCoreObject1, System.out);
    }

}
