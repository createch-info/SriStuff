package com.travelport.otm.compiler.test.compare.generated.reflection;

import com.travelport.otm.jaxb.runtime.URType;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.reflections.Reflections;
import org.unitils.reflectionassert.ReflectionAssert;
import org.unitils.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Set;

public class ObjectComparisionTest {

    private static Reflections reflections;
    private static Set<Class<? extends URType>> classes;

    private static boolean debug = false;

    @Before
    public void setUp() throws Exception {
        reflections = new Reflections("com.travelport.otm.test");
        classes = reflections.getSubTypesOf(URType.class);
    }

    @Test
    public void testObjectComparision() throws InstantiationException, IllegalAccessException {
        for (Class<? extends URType> clazz : classes) {
            if (debug) System.out.println(clazz.getName());
            Object a = clazz.newInstance();
            Object b = clazz.newInstance();
            if (debug) System.out.println("Comparing Object : " + a.toString() + " with : " + b.toString());
            ReflectionAssert.assertReflectionEquals(a, b);
            compareParameters(a, b);
            compareMethods(a, b);
        }
    }

    private void compareMethods(Object a, Object b) {
//		Set<Method> aMethod = 
//				ReflectionUtils.getAllMethods(a.getClass());
//		Set<Method> bMethod = 
//				ReflectionUtils.getAllMethods(a.getClass());
        Iterator<Method> aMethodItr = ReflectionUtils.getAllMethods(a.getClass()).iterator();
        Iterator<Method> bMethodItr = ReflectionUtils.getAllMethods(a.getClass()).iterator();
        while (aMethodItr.hasNext() && bMethodItr.hasNext()) {
            Method aMethod = aMethodItr.next();
            Method bMethod = bMethodItr.next();
            if (debug)
                System.out.println("Comparing Method instance A : " + aMethod.getName() + " with instance B: " + bMethod.getName());
            Assert.assertSame(aMethod.getReturnType(), bMethod.getReturnType());
            Assert.assertSame(aMethod.getParameterTypes().getClass(), bMethod.getParameterTypes().getClass());
        }
    }

    private void compareParameters(Object a, Object b) {
//		Set<Field> aFields = 
//				ReflectionUtils.getAllFields(a.getClass());
//		Set<Field> bFields = 
//				ReflectionUtils.getAllFields(a.getClass());
        Iterator<Field> aFieldItr = ReflectionUtils.getAllFields(a.getClass()).iterator();
        Iterator<Field> bFieldItr = ReflectionUtils.getAllFields(a.getClass()).iterator();
        while (aFieldItr.hasNext() && bFieldItr.hasNext()) {
            Field aField = aFieldItr.next();
            Field bField = bFieldItr.next();
            if (debug)
                System.out.println("Comparing Field instance A : " + aField.getName() + " with instance B: " + bField.getName());
            Assert.assertSame(aField.getName(), bField.getName());
            Assert.assertSame(aField.getType(), bField.getType());
            Assert.assertSame(aField.getModifiers(), bField.getModifiers());
            Assert.assertSame(aField.isAccessible(), bField.isAccessible());
            Assert.assertSame(aField.isEnumConstant(), bField.isEnumConstant());
        }

    }
}
