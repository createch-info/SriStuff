package network;

import org.junit.Test;
import writers.CsvWriter;
import writers.SonarResultsWriter;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class SonarWebAPIClientTest {
    private CountDownLatch lock = new CountDownLatch(1);
    private List<String> keys;
    private String serverUrl = "http://vhldvssbs012.tvlport.net:9000/api/";

    @Test
    public void testSonarWebApiClientGetQualityGates() throws Exception {
        SonarWebAPIClient client = new SonarWebAPIClient();
        String key = "com.travelport.hotel.rules:hotel-at-rules-1g";
        String cleanedKey = "com.travelport.hotel.rules-hotel-at-rules-1g";

        keys = new ArrayList<>(1);
        keys.add(key);

        SonarResultsWriter writer = new CsvWriter();
        client.getQualityGateStatuses(serverUrl, keys, writer);

        lock.await(2000, TimeUnit.MILLISECONDS);

        File f = new File(CsvWriter.FILE_PATH + cleanedKey);
        assertTrue(f.exists());
        f.delete();
    }

    @Test
    public void testBadUrl() throws Exception {
        SonarWebAPIClient client = new SonarWebAPIClient();
        String key = "com.travelport.hotel.rules:hotel-at-rules-1g";
        String cleanedKey = "com.travelport.hotel.rules-hotel-at-rules-1g";


        keys = new ArrayList<>(1);
        keys.add(key);

        SonarResultsWriter writer = new CsvWriter();
        client.getQualityGateStatuses("http://no.way.this.is.a.url", keys, writer);
        File f = new File(CsvWriter.FILE_PATH + cleanedKey);
        assertFalse(f.exists());
        f.delete();
    }

    @Test
    public void testSonarWebApiClientGetQualityGatesBadKey() throws Exception {
        SonarWebAPIClient client = new SonarWebAPIClient();
        String key = "com.travelport.hotel.rulsdafsdfasdfeshotel-at-rules-1g";

        keys = new ArrayList<>(1);
        keys.add(key);

        SonarResultsWriter writer = new CsvWriter();

        client.getQualityGateStatuses(serverUrl, keys, writer);

        lock.await(2000, TimeUnit.MILLISECONDS);

        File f = new File(CsvWriter.FILE_PATH + key);
        assertFalse(f.exists());

    }
}
