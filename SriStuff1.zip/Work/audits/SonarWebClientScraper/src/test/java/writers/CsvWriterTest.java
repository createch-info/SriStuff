package writers;

import model.Condition;
import model.Period;
import model.ProjectStatus;
import model.ProjectStatusBody;
import org.junit.AfterClass;
import org.junit.Ignore;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import static model.ProjectStatusTest.conditions;
import static org.junit.Assert.*;

public class CsvWriterTest {
    private static final String C_STATUS = "STATUS";
    private static final String C_ACTUAL_VALUE = "VALUE";
    private static final String C_ERROR_THRESHOLD = "THRESHOLD";
    private static final int C_PERIOD_INDEX = 1;
    private static final String C_COMPARATOR = "COMPARATOR";
    private static final String C_METRIC_KEY = "METRIC";
    private static final int P_INDEX = 2;
    private static final String P_MODE = "MODE";
    private static final String P_DATE = "DATE";
    private static final String P_PARAMETER = "PARAMETER";
    private static final String PROJECT_STATUS = "PROJECT_STATUS";

    @Test
    public void testWriteResultsGood() throws Exception {
        String goodProjectKey = "goodKey";

        SonarResultsWriter writer = new CsvWriter();
        writer.writeResults(goodProjectKey, getTestBody());

        // A file called output/goodProjectKey should exist
        File f = new File("output/" + goodProjectKey);
        assertTrue(f.exists());

        // Read the file
        BufferedReader fr = new BufferedReader(new FileReader(f));
        String line = fr.readLine();
        String[] lines = line.split(",");
        assertEquals(C_STATUS, lines[0]);
        assertEquals(C_METRIC_KEY, lines[1]);
        assertEquals(C_COMPARATOR, lines[2]);
        assertEquals(C_PERIOD_INDEX, Integer.valueOf(lines[3]).intValue());
        assertEquals(C_ERROR_THRESHOLD, lines[4]);
        assertEquals(C_ACTUAL_VALUE, lines[5]);

        fr.close();
        f.delete();
    }

    @Test(expected = IOException.class)
    public void testWriteResultsBadFile() throws Exception {
        String badProjectKey = "\\";

        SonarResultsWriter writer = new CsvWriter();
        writer.writeResults(badProjectKey, getTestBody());
    }

    @Ignore
    private final ProjectStatusBody getTestBody() {
        ProjectStatusBody body = new ProjectStatusBody();
        ProjectStatus status = new ProjectStatus();
        Condition condition = new Condition();
        condition.setStatus(C_STATUS);
        condition.setActualValue(C_ACTUAL_VALUE);
        condition.setErrorThreshold(C_ERROR_THRESHOLD);
        condition.setPeriodIndex(C_PERIOD_INDEX);
        condition.setComparator(C_COMPARATOR);
        condition.setMetricKey(C_METRIC_KEY);

        Period period = new Period();
        period.setIndex(P_INDEX);
        period.setMode(P_MODE);
        period.setDate(P_DATE);
        period.setParameter(P_PARAMETER);

        ArrayList<Period> periods = new ArrayList<>(1);
        periods.add(period);
        ArrayList<Condition> conditions = new ArrayList<>(1);
        conditions.add(condition);

        status.setStatus(PROJECT_STATUS);
        status.setPeriods(periods);
        status.setConditions(conditions);

        body.setProjectStatus(status);

        return body;
    }

    @AfterClass
    public static void cleanup() {
    }

}