package model;

import org.junit.BeforeClass;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class ProjectStatusTest {

    public static ProjectStatus ps;
    public static String STATUS = "STATUS";
    public static String MODE = "MODE";
    public static List<Condition> conditions;
    public static List<Period> periods;

    @BeforeClass
    public static void setup() {
        ps = new ProjectStatus();

        Condition c = new Condition();
        c.setStatus(STATUS);

        Period p = new Period();
        p.setMode(MODE);

        conditions = new ArrayList<>(1);
        conditions.add(c);

        periods = new ArrayList<>(1);
        periods.add(p);
    }

    @Test
    public void getStatus() throws Exception {
        ps.status = STATUS;
        assertEquals(STATUS, ps.getStatus());
    }

    @Test
    public void setStatus() throws Exception {
        ps.setStatus(STATUS);
        assertEquals(STATUS, ps.status);
    }

    @Test
    public void getConditions() throws Exception {
        ps.conditions = conditions;
        List<Condition> c = ps.getConditions();
        assertNotNull(c);
        assertEquals(STATUS, c.get(0).getStatus());
    }

    @Test
    public void setConditions() throws Exception {
        ps.setConditions(conditions);
        List<Condition> c = ps.conditions;
        assertNotNull(c);
        assertEquals(STATUS, c.get(0).getStatus());
    }

    @Test
    public void getPeriods() throws Exception {
        ps.periods = periods;
        List<Period> p = ps.getPeriods();
        assertNotNull(p);
        assertEquals(MODE, p.get(0).getMode());
    }

    @Test
    public void setPeriods() throws Exception {
        ps.setPeriods(periods);
        List<Period> p = ps.periods;
        assertNotNull(p);
        assertEquals(MODE, p.get(0).getMode());
    }

}