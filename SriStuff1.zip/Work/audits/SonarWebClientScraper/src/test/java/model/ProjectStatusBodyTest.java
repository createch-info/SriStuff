package model;

import org.junit.Test;

import static org.junit.Assert.*;

public class ProjectStatusBodyTest {
    ProjectStatusBody body = new ProjectStatusBody();
    ProjectStatus status = new ProjectStatus();
    private static final String UNIQUE_STATUS = "SO_UNEEK";

    @Test
    public void getProjectStatus() throws Exception {
        status.setStatus(UNIQUE_STATUS);
        body.projectStatus = status;
        assertEquals(UNIQUE_STATUS, body.getProjectStatus().getStatus());
    }

    @Test
    public void setProjectStatus() throws Exception {
        status.setStatus(UNIQUE_STATUS);
        body.setProjectStatus(status);
        assertEquals(UNIQUE_STATUS, body.projectStatus.getStatus());
    }

}