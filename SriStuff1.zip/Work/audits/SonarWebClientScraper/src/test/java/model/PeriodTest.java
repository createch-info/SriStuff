package model;

import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

public class PeriodTest {

    public static Period p;
    public static int INDEX = 9001;
    public static String MODE = "MODE";
    public static String DATE = "DATE";
    public static String PARAMETER = "PARAMETER";

    @BeforeClass
    public static void setup() {
        p = new Period();
    }

    @Test
    public void getIndex() throws Exception {
        p.index = INDEX;
        assertEquals(INDEX, p.getIndex());
    }

    @Test
    public void setIndex() throws Exception {
        p.setIndex(INDEX);
        assertEquals(INDEX, p.index);
    }

    @Test
    public void getMode() throws Exception {
        p.mode = MODE;
        assertEquals(MODE, p.getMode());
    }

    @Test
    public void setMode() throws Exception {
        p.setMode(MODE);
        assertEquals(MODE, p.mode);
    }

    @Test
    public void getDate() throws Exception {
        p.date = DATE;
        assertEquals(DATE, p.getDate());
    }

    @Test
    public void setDate() throws Exception {
        p.setDate(DATE);
        assertEquals(DATE, p.date);
    }

    @Test
    public void getParameter() throws Exception {
        p.parameter = PARAMETER;
        assertEquals(PARAMETER, p.getParameter());
    }

    @Test
    public void setParameter() throws Exception {
        p.setParameter(PARAMETER);
        assertEquals(PARAMETER, p.parameter);
    }

}