package model;

import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

public class ConditionTest {


    private static final String COMPARATOR = "COMPARATOR";
    private final static String STATUS = "STATUS";
    private final static String METRIC_KEY = "METRIC_KEY";
    private static final int PERIOD_INDEX = 9001;
    private static final String ERROR_THRESHOLD = "ERROR_THRESHOLD";
    private static final String ACTUAL_VALUE = "ACTUAL_GOLDANG_VALUE";

    static Condition c;

    @BeforeClass
    public static void testSetup() {
        c = new Condition();
    }

    @Test
    public void getStatus() throws Exception {
        c.status = STATUS;
        assertEquals(STATUS, c.getStatus());
    }

    @Test
    public void setStatus() throws Exception {
        c.setStatus(STATUS);
        assertEquals(STATUS, c.status);
    }

    @Test
    public void getMetricKey() throws Exception {
        c.metricKey = METRIC_KEY;
        assertEquals(METRIC_KEY, c.getMetricKey());
    }

    @Test
    public void setMetricKey() throws Exception {
        c.setMetricKey(METRIC_KEY);
        assertEquals(METRIC_KEY, c.metricKey);
    }

    @Test
    public void getComparator() throws Exception {
        c.comparator = COMPARATOR;
        assertEquals(COMPARATOR, c.getComparator());
    }

    @Test
    public void setComparator() throws Exception {
        c.setComparator(COMPARATOR);
        assertEquals(COMPARATOR, c.comparator);
    }

    @Test
    public void getPeriodIndex() throws Exception {
        c.periodIndex = PERIOD_INDEX;
        assertEquals(PERIOD_INDEX, c.getPeriodIndex());
    }

    @Test
    public void setPeriodIndex() throws Exception {
        c.setPeriodIndex(PERIOD_INDEX);
        assertEquals(PERIOD_INDEX, c.periodIndex);
    }

    @Test
    public void getErrorThreshold() throws Exception {
        c.errorThreshold = ERROR_THRESHOLD;
        assertEquals(ERROR_THRESHOLD, c.getErrorThreshold());
    }

    @Test
    public void setErrorThreshold() throws Exception {
        c.setErrorThreshold(ERROR_THRESHOLD);
        assertEquals(ERROR_THRESHOLD, c.errorThreshold);
    }

    @Test
    public void getActualValue() throws Exception {
        c.actualValue = ACTUAL_VALUE;
        assertEquals(ACTUAL_VALUE, c.getActualValue());
    }

    @Test
    public void setActualValue() throws Exception {
        c.setActualValue(ACTUAL_VALUE);
        assertEquals(ACTUAL_VALUE, c.actualValue);
    }

}