package network;

import model.ProjectStatusBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface SonarWebAPIService {
    @GET("qualitygates/project_status")
    Call<ProjectStatusBody> getQualityGatesProjectStatus(@Query(value = "projectKey") String projectKey);
}
