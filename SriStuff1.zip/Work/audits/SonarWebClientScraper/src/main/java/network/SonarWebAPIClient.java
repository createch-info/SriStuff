package network;

import model.ProjectStatusBody;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import writers.SonarResultsWriter;

import java.io.IOException;
import java.util.List;

public class SonarWebAPIClient {

    private static final Logger logger = LogManager.getLogger("SonarWebAPIClient");

    public static SonarWebAPIService getInstance(String url) {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.NONE);
        OkHttpClient client = new OkHttpClient.Builder().addInterceptor(interceptor).build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(url)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        return retrofit.create(SonarWebAPIService.class);
    }

    public void getQualityGateStatuses(final String sonarServerUrl,
                                       final List<String> projectKeys,
                                       final SonarResultsWriter writer) throws IOException{
        SonarWebAPIService service = SonarWebAPIClient.getInstance(sonarServerUrl);
        projectKeys.forEach(
                key -> {
                    logger.info("\t Looking up project " + key);

                    try {
                        getQualityStatusForService(service, key, writer);
                    } catch (IOException e) {
                        logger.error(e.getLocalizedMessage());
                        logger.error("Couldn't look up " + key);
                    }
                }
        );
    }

    private void getQualityStatusForService(final SonarWebAPIService service,
                                            final String projectKey,
                                            final SonarResultsWriter writer) throws IOException {
        service.getQualityGatesProjectStatus(projectKey)
                .enqueue(new Callback<ProjectStatusBody>() {
                    @Override
                    public void onResponse(Call<ProjectStatusBody> call, Response<ProjectStatusBody> response) {
                        try {
                            writer.writeResults(projectKey, response.body());
                            logger.info("Response Status : " + response.code());
                            long responseTime = response.raw().receivedResponseAtMillis() - response.raw().sentRequestAtMillis();
                            logger.info("Response time   : " + String.valueOf(responseTime));
                        } catch (IOException e) {
                            logger.error("Failed to call sonar for " + projectKey);
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFailure(Call<ProjectStatusBody> call, Throwable t) {
                        logger.error("Likely a bad project key?" + projectKey);
                        logger.error("... or Sonar is down.");
                    }
                });
    }
}
