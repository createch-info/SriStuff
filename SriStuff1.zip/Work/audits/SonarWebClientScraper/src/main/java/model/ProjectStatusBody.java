package model;

public class ProjectStatusBody {
    public ProjectStatus projectStatus;

    public ProjectStatusBody() {

    }

    public ProjectStatus getProjectStatus() {
        return projectStatus;
    }

    public void setProjectStatus(ProjectStatus projectStatus) {
        this.projectStatus = projectStatus;
    }
}
