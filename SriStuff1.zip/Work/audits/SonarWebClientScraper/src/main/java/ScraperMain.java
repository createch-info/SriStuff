import network.SonarWebAPIClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import writers.CsvWriter;
import writers.SonarResultsWriter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.LinkedList;
import java.util.List;

public class ScraperMain {

    private static final String COMMENT = "*";
    private static final String KEYS_FILE = "projects";
    private static final String SONAR_SERVER = "http://vhldvssbs012.tvlport.net:9000/api/";

    private static final Logger logger = LogManager.getLogger("ScraperMain");

    private static List<String> getKeys(String filename) {
        LinkedList<String> projectKeys = new LinkedList<>();

        try {
            BufferedReader br = new BufferedReader(new FileReader(new File(filename)));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith(COMMENT)) continue;
                projectKeys.add(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading project keys from file.");
        }

        return projectKeys;
    }

    public static void main(String[] args) {
        LocalTime start = LocalTime.now();
        logger.info("Started at: " + start.toString());

        List<String> keys = getKeys(KEYS_FILE);
        SonarWebAPIClient client = new SonarWebAPIClient();
        SonarResultsWriter writer = new CsvWriter();

        try {
            client.getQualityGateStatuses(SONAR_SERVER, keys, writer);
        } catch (IOException e) {
            logger.fatal("Problem getting sonar statuses.");
            logger.fatal(e.getLocalizedMessage());
        }

        LocalTime stop = LocalTime.now();
        logger.info("Stopped at: " + stop.toString());
        logger.info("Total time elapsed : " + ChronoUnit.SECONDS.between(start, stop));
    }
}
