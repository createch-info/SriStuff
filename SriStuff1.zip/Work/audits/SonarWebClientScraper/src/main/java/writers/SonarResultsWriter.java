package writers;

import model.ProjectStatusBody;

import java.io.IOException;

public interface SonarResultsWriter {
    void writeResults(final String projectKey, final ProjectStatusBody body) throws IOException;
}
