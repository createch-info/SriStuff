package writers;

import model.Condition;
import model.ProjectStatusBody;

import java.io.FileWriter;
import java.io.IOException;

public class CsvWriter implements SonarResultsWriter {

    public static String FILE_PATH = "output/";

    public CsvWriter() {
    }

    @Override
    public void writeResults(String projectKey, ProjectStatusBody body) throws IOException{
        FileWriter fw = null;
        try {
            if ((body != null) &&
                    (body.getProjectStatus() != null) &&
                    (body.getProjectStatus().getConditions() != null) &&
                    (!body.getProjectStatus().getConditions().isEmpty())) {
                fw = new FileWriter(FILE_PATH + cleanProjectKey(projectKey), true);

                for (final Condition c : body.getProjectStatus().getConditions()) {
                    if (c != null) {
                        fw.write(getFormattedLine(c));
                    }
                }

                fw.write(String.format("%n"));
            }
        } catch (IOException ioe) {
            System.out.println("Error writing to disk at location.");
            System.out.println(ioe.getLocalizedMessage());
            throw(ioe);
        } finally {
            if (fw != null) {
                fw.close();
            }
        }
    }

    private String getFormattedLine(final Condition c) {
        String DELIM = ",";
        return c.getStatus() + DELIM +
                    c.getMetricKey()+ DELIM +
                    c.getComparator()+ DELIM +
                    String.valueOf(c.getPeriodIndex())+ DELIM +
                    c.getErrorThreshold()+ DELIM +
                    c.getActualValue()+ DELIM;
    }

    private static String cleanProjectKey(String projectKey) {
        return projectKey.replaceAll(":", "-");
    }

}
