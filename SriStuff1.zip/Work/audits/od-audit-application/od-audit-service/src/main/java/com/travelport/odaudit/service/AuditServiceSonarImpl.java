/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.odaudit.service;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import org.codehaus.plexus.util.FileUtils;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.revwalk.RevCommit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.travelport.odaudit.service.sonarresponse.Measure;
import com.travelport.odaudit.service.sonarresponse.SonarIndexResponse;
import com.travelport.odaudit.service.sonarresponse.SonarMetricResponse;
import com.travelport.otm.odaudit.dao.DAOException;
import com.travelport.otm.odaudit.dao.DAOFactory;
import com.travelport.otm.odaudit.dao.GitRepositoryDAO;
import com.travelport.otm.odaudit.dao.ODScanDAO;
import com.travelport.otm.odaudit.dao.OdProgramReportDAO;
import com.travelport.otm.odaudit.dao.RepositoryReportDAO;
import com.travelport.otm.odaudit.dao.SonarScanInfoDAO;
import com.travelport.otm.odaudit.model.GitRepositoryEntity;
import com.travelport.otm.odaudit.model.ODScanEntity;
import com.travelport.otm.odaudit.model.OdProgramReportEntity;
import com.travelport.otm.odaudit.model.RepositoryReportEntity;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;
import com.travelport.otm.odaudit.type.KPIType;
import com.travelport.otm.odaudit.type.ScanType;
import com.travelport.otm.odaudit.validation.ValidationException;

@Path("/od_audit/sonarScan/{odProgramReportId}")
@Produces({MediaType.TEXT_PLAIN})
public class AuditServiceSonarImpl implements AuditServiceSonar {

  private static final Logger LOGGER = LoggerFactory.getLogger(AuditServiceSonarImpl.class);

  private String gitBranch;
  private String gitRepoName;
  private Date gitCommitTime;
  private Date sonarScanDate;
  private String projectKey;
  private String sonarProjectURL;
  private OdProgramReportEntity odProgramReportEntity = new OdProgramReportEntity();

  private DAOFactory daoFactory = new DAOFactory();
  private Client client = ClientBuilder.newClient();
  private ObjectMapper mapper = new ObjectMapper();

  @POST
  @Path("/repositories")
  public Response getAllRepositoryDetails(@PathParam("odProgramReportId") long odProgramReportId)
      throws DAOException {
    DAOFactory.initializeJPAServices();
    odProgramReportEntity = getOdProgramReport(odProgramReportId);
    GitRepositoryDAO gitRepositoryDAO = daoFactory.newGitRepositoryDAO();
    List<GitRepositoryEntity> repoList = gitRepositoryDAO.findAll();
    if (repoList.isEmpty()) {
      throw new DAOException(
          "Error while retrieving Repository Details for provided OD Program ID");
    }
    for (GitRepositoryEntity repositoryDetail : repoList) {
      String gitURL = repositoryDetail.getRepositoryUrl();
      gitBranch = repositoryDetail.getBranch();
      gitRepoName = repositoryDetail.getRepositoryName();
      projectKey = repositoryDetail.getProjectKey();
      getGitRepoDetails(gitRepoName, gitURL, gitBranch);
      getSonarIndex(gitCommitTime, projectKey);
      getSonarMetrics(projectKey, sonarScanDate, repositoryDetail);
    }
    DAOFactory.shutdownJPAServices();
    return Response.status(Status.OK).entity("The Sonar Data is uploaded for all Git repositoriess")
        .build();
  }

  @POST
  @Path("/repositories/{gitURL}")
  public Response getRepositoryDetails(@PathParam("odProgramReportId") long odProgramReportId,
      @PathParam("gitURL") String gitURL) throws DAOException {
    DAOFactory.initializeJPAServices();
    odProgramReportEntity = getOdProgramReport(odProgramReportId);
    GitRepositoryDAO gitRepositoryDAO = daoFactory.newGitRepositoryDAO();
    List<GitRepositoryEntity> repoList = gitRepositoryDAO.findByRepositoryUrl(gitURL);
    if (repoList.isEmpty()) {
      throw new DAOException("Error while retrieving Repository Details for provide OD Program ID");
    }
    for (GitRepositoryEntity repositoryDetail : repoList) {
      gitBranch = repositoryDetail.getBranch();
      projectKey = repositoryDetail.getProjectKey();
      gitRepoName = repositoryDetail.getRepositoryName();
      getGitRepoDetails(gitRepoName, gitURL, gitBranch);
      getSonarIndex(gitCommitTime, projectKey);
      getSonarMetrics(projectKey, sonarScanDate, repositoryDetail);
    }
    DAOFactory.shutdownJPAServices();
    return Response.status(Status.OK)
        .entity("The Sonar Data is uploaded for the provided Git repository").build();
  }

  public OdProgramReportEntity getOdProgramReport(long odProgramReportId) {
    try {
      OdProgramReportDAO odProgramReportDAO = daoFactory.newOdProgramReportDAO();
      odProgramReportEntity = odProgramReportDAO.get(odProgramReportId);
    } catch (DAOException e) {
      LOGGER.error("Error while trying to get the OdProgramReport details in getOdProgramReport",
          e);
      throw new WebApplicationException(
          "Error while trying to get the OdProgramReport details in getOdProgramReport", e, 500);
    }
    return odProgramReportEntity;
  }


  public Date getGitRepoDetails(String gitRepoName, String gitURL, String gitBranch) {
    try {
      File localPath = File.createTempFile(gitRepoName, "");
      if (!localPath.delete()) {
        throw new IOException("Could not delete temporary file " + localPath);
      }
      Git git =
          Git.cloneRepository().setURI(gitURL).setDirectory(localPath).setBranch(gitBranch).call();
      Iterable<RevCommit> commitList = git.log().setMaxCount(1).call();
      for (RevCommit commit : commitList) {
        SimpleDateFormat originalFormat = new SimpleDateFormat(AuditServiceConstants.TIME_FORMAT);
        originalFormat.setTimeZone(TimeZone.getTimeZone(AuditServiceConstants.TIME_ZONE));
        String commitTime = originalFormat.format(new Date((commit.getCommitTime()) * 1000L));
        gitCommitTime = new SimpleDateFormat(AuditServiceConstants.TIME_FORMAT, Locale.ENGLISH)
            .parse(commitTime);
      }
      git.getRepository().close();
      FileUtils.deleteDirectory(localPath);

    } catch (IOException | GitAPIException | ParseException e) {
      LOGGER.error("Error while trying to get the Git details in getGitRepoDetails", e);
      throw new WebApplicationException(
          "Error while trying to get the Git details in getGitRepoDetails", e, 500);
    }
    return gitCommitTime;
  }

  public void getSonarIndex(Date gitCommitTime, String projectKey) {
    StringBuilder sonarIndexURL = new StringBuilder().append(AuditServiceConstants.HTTP_PROTOCOL)
        .append(System.getenv(AuditServiceConstants.SONAR_URL))
        .append(AuditServiceConstants.SONAR_API_RSC_INDEX).append(projectKey)
        .append(AuditServiceConstants.SONAR_API_RESPONSE_FORMAT);
    StringBuilder sonarGenericURL = new StringBuilder().append(AuditServiceConstants.HTTP_PROTOCOL)
        .append(System.getenv(AuditServiceConstants.SONAR_URL))
        .append(AuditServiceConstants.SONAR_PROJECT_OVERVIEW_FORMAT).append(projectKey);
    sonarProjectURL = sonarGenericURL.toString();
    System.out.println(sonarIndexURL.toString());
    WebTarget webTarget = client.target(sonarIndexURL.toString());
    Response response = webTarget.request().accept(MediaType.APPLICATION_JSON).get();
    String responseAsString = response.readEntity(String.class);
    List<SonarIndexResponse> sonarIndexResponse;
    try {
      sonarIndexResponse =
          mapper.readValue(responseAsString, new TypeReference<List<SonarIndexResponse>>() {});
      String scanTime = sonarIndexResponse.get(0).getDate();
      sonarScanDate =
          new SimpleDateFormat(AuditServiceConstants.TIME_FORMAT, Locale.ENGLISH).parse(scanTime);
      int scanDiff = sonarScanDate.compareTo(gitCommitTime);
      if (AuditServiceConstants.LAST_SCAN_DAYS_LIMIT > scanDiff) {
        LOGGER.debug("The scan is a week older than current commit");
        // Run Scan
      }
    } catch (IOException | ParseException e) {
      LOGGER.error("Error while trying to get Sonar Scan Date in getSonarIndex", e);
      throw new WebApplicationException(
          "Error while trying to get Sonar Scan Date in getSonarIndex", e, 500);
    }
  }

  public void getSonarMetrics(String projectKey, Date sonarScanDate,
      GitRepositoryEntity repositoryDetail) {
    StringBuilder sonarMetricsURL = new StringBuilder().append(AuditServiceConstants.HTTP_PROTOCOL)
        .append(System.getenv(AuditServiceConstants.SONAR_URL))
        .append(AuditServiceConstants.SONAR_API_COMP_MEASURES).append(projectKey)
        .append(AuditServiceConstants.SONAR_API_MEASURES_LIST)
        .append(AuditServiceConstants.SONAR_API_RESPONSE_FORMAT);
    WebTarget webTarget = client.target(sonarMetricsURL.toString());
    Response response = webTarget.request().accept(MediaType.APPLICATION_JSON).get();
    String responseAsString = response.readEntity(String.class);
    SonarMetricResponse sonarMetricResponse;
    SonarScanInfoEntity sonarScanInfoEntity = new SonarScanInfoEntity();
    try {
      sonarMetricResponse = mapper.readValue(responseAsString, SonarMetricResponse.class);
      List<Measure> sonarMeasures = sonarMetricResponse.getComponent().getMeasures();
      for (Measure sonarMeasure : sonarMeasures) {
        KPIType type = KPIType.getMetricFromString(sonarMeasure.getMetric());
        if (type != null) {
          setSonarMetrics(sonarMeasure, type, sonarScanInfoEntity);
        }
      }
      putSonarMetrics(sonarScanInfoEntity, repositoryDetail, odProgramReportEntity);
    } catch (IOException e) {
      LOGGER.error("Error while trying to load Sonar Metrics in getSonarMetrics", e);
      throw new WebApplicationException(
          "Error while trying to load Sonar Metrics in getSonarMetrics", e, 500);
    }
  }

  public void setSonarMetrics(Measure sonarMeasure, KPIType type,
      SonarScanInfoEntity sonarScanInfoEntity) {
    float measure = Float.parseFloat(sonarMeasure.getValue());
    switch (type) {
      case SONAR_CODE_COVERAGE:
        sonarScanInfoEntity.setCodeCoverage(measure);
        break;
      case SONAR_CODE_SMELLS:
        sonarScanInfoEntity.setCodeSmells(measure);
        break;
      case SONAR_BUGS:
        sonarScanInfoEntity.setBugs(measure);
        break;
      case SONAR_COMPLEXITY:
        sonarScanInfoEntity.setComplexity(measure);
        break;
      case SONAR_TECH_DEBT:
        sonarScanInfoEntity.setTechDebt(measure);
        break;
      case SONAR_VULNERABILITIES:
        sonarScanInfoEntity.setVulnerabilities(measure);
        break;
      case SONAR_LINES_OF_CODE:
        sonarScanInfoEntity.setLinesOfCode(Integer.valueOf(sonarMeasure.getValue()));
        break;
      default:
        break;
    }
  }



  public void putSonarMetrics(SonarScanInfoEntity sonarScanInfoEntity,
      GitRepositoryEntity repositoryDetail, OdProgramReportEntity odProgramReportEntity) {
    SonarScanInfoDAO sonarScanInfoDAO = daoFactory.newSonarScanInfoDAO();
    ODScanDAO odScanDAO = daoFactory.newODScanDAO();
    RepositoryReportDAO repositoryReportDAO = daoFactory.newRepositoryReportDAO();

    ODScanEntity odScan = new ODScanEntity();
    odScan.setGitRepository(repositoryDetail);
    odScan.setScanDate(Calendar.getInstance().getTime());
    odScan.setScanType(ScanType.SONAR);
    odScan.setSonarScanInfo(sonarScanInfoEntity);


    RepositoryReportEntity repositoryReportEntity = new RepositoryReportEntity();
    repositoryReportEntity.setOdScan(odScan);
    repositoryReportEntity.setSonarScanInfo(sonarScanInfoEntity);
    repositoryReportEntity.setOdProgramReport(odProgramReportEntity);
    repositoryReportEntity.setSonarQubeUrl(sonarProjectURL);
    repositoryReportEntity.setReportDate(Calendar.getInstance().getTime());

    try {
      daoFactory.beginTransaction();

      sonarScanInfoDAO.create(sonarScanInfoEntity);
      odScanDAO.create(odScan);
      repositoryReportDAO.create(repositoryReportEntity);

      daoFactory.commitTransaction();
    } catch (DAOException | ValidationException e) {
      LOGGER.error("Error while trying to push Sonar Metrics in putSonarMetrics", e);
      try {
        daoFactory.rollbackTransaction();
      } catch (DAOException ie) {
        LOGGER.error("Error while trying to rollback Sonar Metrics in putSonarMetrics", ie);
        throw new WebApplicationException(
            "Error while trying to push Sonar Metrics in putSonarMetrics", e, 500);
      }
    }
  }

}