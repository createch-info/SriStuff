/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.odaudit.service;

import java.util.Calendar;
import java.util.List;
import java.util.stream.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.travelport.otm.odaudit.dao.DAOException;
import com.travelport.otm.odaudit.dao.DAOFactory;
import com.travelport.otm.odaudit.dao.ODScanDAO;
import com.travelport.otm.odaudit.dao.OdProgramReportDAO;
import com.travelport.otm.odaudit.dao.OrganizationReportDAO;
import com.travelport.otm.odaudit.dao.ProjectTeamReportDAO;
import com.travelport.otm.odaudit.dao.SonarScanInfoDAO;
import com.travelport.otm.odaudit.model.GitRepositoryEntity;
import com.travelport.otm.odaudit.model.OdProgramReportEntity;
import com.travelport.otm.odaudit.model.OrganizationEntity;
import com.travelport.otm.odaudit.model.OrganizationReportEntity;
import com.travelport.otm.odaudit.model.PersistentEntity;
import com.travelport.otm.odaudit.model.ProjectTeamEntity;
import com.travelport.otm.odaudit.model.ProjectTeamReportEntity;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;
import com.travelport.otm.odaudit.validation.ValidationException;

public class SonarMetricsRollup {
  private static final Logger LOGGER = LoggerFactory.getLogger(SonarMetricsRollup.class);
  private DAOFactory daoFactory = new DAOFactory();
  private SonarScanInfoDAO sonarScanInfoDAO = daoFactory.newSonarScanInfoDAO();
  private OdProgramReportDAO odProgramReportDAO = daoFactory.newOdProgramReportDAO();
  private ODScanDAO odScanDao = daoFactory.newODScanDAO();

  public SonarScanInfoEntity calculateSonarScanMetricsAvg(
      List<GitRepositoryEntity> gitRepositoryList) {
    SonarScanInfoEntity sonarScanEntityAvg;
    sonarScanEntityAvg = gitRepositoryList.stream()
        .collect(Collector.of(SonarScanInfoEntity::new, (sonarScanInfoEntity, gitRepoEntity) -> {
          try {
            getSonarMetrics(sonarScanInfoEntity, gitRepoEntity);
          } catch (DAOException e) {
            LOGGER.error("Error while trying to get the SonarScanInfoEntity details", e);
          }
        }, (sonarScanInfoEntity1, sonarScanInfoEntity2) -> {
          if (sonarScanInfoEntity1 == null || sonarScanInfoEntity2 == null)
            throw new NullPointerException();
          else
            return setSonarMetrics(sonarScanInfoEntity1, sonarScanInfoEntity2);
        }, avgSonarScanInfoEntity -> getSonarMetricsAvg(avgSonarScanInfoEntity)));

    return sonarScanEntityAvg;

  }

  private SonarScanInfoEntity getSonarMetricsAvg(SonarScanInfoEntity avgSonarScanInfoEntity) {

    if (avgSonarScanInfoEntity == null)
      throw new NullPointerException();

    avgSonarScanInfoEntity
        .setBugs(avgSonarScanInfoEntity.getBugs() / avgSonarScanInfoEntity.getLinesOfCode());
    avgSonarScanInfoEntity.setVulnerabilities(
        avgSonarScanInfoEntity.getVulnerabilities() / avgSonarScanInfoEntity.getLinesOfCode());
    avgSonarScanInfoEntity.setTechDebt(
        avgSonarScanInfoEntity.getTechDebt() / avgSonarScanInfoEntity.getLinesOfCode());
    avgSonarScanInfoEntity.setCodeSmells(
        avgSonarScanInfoEntity.getCodeSmells() / avgSonarScanInfoEntity.getLinesOfCode());
    avgSonarScanInfoEntity.setCodeCoverage(
        avgSonarScanInfoEntity.getCodeCoverage() / avgSonarScanInfoEntity.getLinesOfCode());
    avgSonarScanInfoEntity.setComplexity(
        avgSonarScanInfoEntity.getComplexity() / avgSonarScanInfoEntity.getLinesOfCode());
    avgSonarScanInfoEntity.setLinesOfCode(avgSonarScanInfoEntity.getLinesOfCode());

    return avgSonarScanInfoEntity;
  }

  private SonarScanInfoEntity setSonarMetrics(SonarScanInfoEntity initialSonarScanInfoEntity,
      SonarScanInfoEntity nextSonarScanInfoEntity) {

    initialSonarScanInfoEntity
        .setBugs(initialSonarScanInfoEntity.getBugs() + nextSonarScanInfoEntity.getBugs());
    initialSonarScanInfoEntity.setLinesOfCode(
        initialSonarScanInfoEntity.getLinesOfCode() + nextSonarScanInfoEntity.getLinesOfCode());
    initialSonarScanInfoEntity.setVulnerabilities(initialSonarScanInfoEntity.getVulnerabilities()
        + nextSonarScanInfoEntity.getVulnerabilities());
    initialSonarScanInfoEntity.setTechDebt(
        initialSonarScanInfoEntity.getTechDebt() + nextSonarScanInfoEntity.getTechDebt());
    initialSonarScanInfoEntity.setCodeSmells(
        initialSonarScanInfoEntity.getCodeSmells() + nextSonarScanInfoEntity.getCodeSmells());
    initialSonarScanInfoEntity.setCodeCoverage(
        initialSonarScanInfoEntity.getCodeCoverage() + nextSonarScanInfoEntity.getCodeCoverage());
    initialSonarScanInfoEntity.setComplexity(
        initialSonarScanInfoEntity.getComplexity() + nextSonarScanInfoEntity.getComplexity());

    return initialSonarScanInfoEntity;
  }

  private void getSonarMetrics(SonarScanInfoEntity sonarScanInfoEntity,
      GitRepositoryEntity gitRepositoryEntity) throws DAOException {
    SonarScanInfoEntity initialSonarScanEntity =
        odScanDao.findLatestScanInfoForGitRepo(gitRepositoryEntity.getId());

    if (initialSonarScanEntity == null)
      throw new DAOException("SonarScan infor missing for provided Git Repo");

 // @formatter:off
    sonarScanInfoEntity
        .setBugs((initialSonarScanEntity.getBugs() != null ? initialSonarScanEntity.getBugs() : 0)
            + (sonarScanInfoEntity.getBugs() != null ? sonarScanInfoEntity.getBugs() : 0)
            + initialSonarScanEntity.getBugs() * initialSonarScanEntity.getLinesOfCode());
   
    sonarScanInfoEntity.setVulnerabilities((initialSonarScanEntity.getVulnerabilities() != null
        ? initialSonarScanEntity.getVulnerabilities() : 0)
        + (sonarScanInfoEntity.getVulnerabilities() != null
            ? sonarScanInfoEntity.getVulnerabilities() : 0)
        + initialSonarScanEntity.getVulnerabilities() * initialSonarScanEntity.getLinesOfCode());
    
    sonarScanInfoEntity.setTechDebt(
        (initialSonarScanEntity.getTechDebt() != null ? initialSonarScanEntity.getTechDebt() : 0)
            + (sonarScanInfoEntity.getTechDebt() != null ? sonarScanInfoEntity.getTechDebt() : 0)
            + initialSonarScanEntity.getTechDebt() * initialSonarScanEntity.getLinesOfCode());
    
    sonarScanInfoEntity.setCodeSmells((initialSonarScanEntity.getCodeSmells() != null
        ? initialSonarScanEntity.getCodeSmells() : 0)
        + (sonarScanInfoEntity.getCodeSmells() != null ? sonarScanInfoEntity.getCodeSmells() : 0)
        + initialSonarScanEntity.getCodeSmells() * initialSonarScanEntity.getLinesOfCode());

    sonarScanInfoEntity.setCodeCoverage((initialSonarScanEntity.getCodeCoverage() != null
        ? initialSonarScanEntity.getCodeCoverage() : 0)
        + (sonarScanInfoEntity.getCodeCoverage() != null ? sonarScanInfoEntity.getCodeCoverage()
            : 0) + initialSonarScanEntity.getCodeCoverage() * initialSonarScanEntity.getLinesOfCode());
    
    sonarScanInfoEntity.setComplexity((initialSonarScanEntity.getComplexity() != null
        ? initialSonarScanEntity.getComplexity() : 0)
        + (sonarScanInfoEntity.getComplexity() != null ? sonarScanInfoEntity.getComplexity() : 0)
        + initialSonarScanEntity.getComplexity() * initialSonarScanEntity.getLinesOfCode());
    
    sonarScanInfoEntity.setLinesOfCode(
        sonarScanInfoEntity.getLinesOfCode() + initialSonarScanEntity.getLinesOfCode());
    
 // @formatter:on 
  }

  public void putSonarMetrics(SonarScanInfoEntity sonarScanInfoEntity,
      PersistentEntity persistentEntity, long odProgramReportId) throws DAOException {

    if (persistentEntity == null)
      throw new DAOException("The entity provided is missing");

    OrganizationReportDAO orgReportDAO = daoFactory.newOrganizationReportDAO();
    ProjectTeamReportDAO projectTeamReportDAO = daoFactory.newProjectTeamReportDAO();
    OdProgramReportEntity odProgramReportEntity = odProgramReportDAO.get(odProgramReportId);


    if (persistentEntity instanceof ProjectTeamEntity) {
      ProjectTeamReportEntity ptReportEntity = new ProjectTeamReportEntity();
      ptReportEntity.setOdProgramReport(odProgramReportEntity);
      ptReportEntity.setProjectTeam((ProjectTeamEntity) persistentEntity);
      ptReportEntity.setSonarScanInfo(sonarScanInfoEntity);
      ptReportEntity.setPtReportDate(Calendar.getInstance().getTime());

      try {
        daoFactory.beginTransaction();
        sonarScanInfoDAO.create(sonarScanInfoEntity);
        projectTeamReportDAO.create(ptReportEntity);
        daoFactory.commitTransaction();
      } catch (DAOException | ValidationException e) {
        LOGGER.error("Error while trying to push Sonar Metrics in ProjectEntity", e);
      }
    }
    if (persistentEntity instanceof OrganizationEntity) {
      OrganizationReportEntity orgReportEntity = new OrganizationReportEntity();
      orgReportEntity.setOrganization((OrganizationEntity) persistentEntity);
      orgReportEntity.setSonarScanInfo(sonarScanInfoEntity);
      orgReportEntity.setOdProgramReport(odProgramReportEntity);
      orgReportEntity.setOrgReportDate(Calendar.getInstance().getTime());
      try {
        daoFactory.beginTransaction();
        sonarScanInfoDAO.create(sonarScanInfoEntity);
        orgReportDAO.create(orgReportEntity);
        daoFactory.commitTransaction();
      } catch (DAOException | ValidationException e) {
        LOGGER.error("Error while trying to push Sonar Metrics in OrganizationEntity", e);
      }
    }

  }

  public void putProgramSonarMetrics(OdProgramReportEntity odPrgmReportEntity,
      SonarScanInfoEntity sonarScanInfoEntity) {
    odPrgmReportEntity.setSonarScanInfo(sonarScanInfoEntity);
    odPrgmReportEntity.setOdReportDate(Calendar.getInstance().getTime());
    try {
      daoFactory.beginTransaction();
      sonarScanInfoDAO.create(sonarScanInfoEntity);
      odProgramReportDAO.update(odPrgmReportEntity);
      daoFactory.commitTransaction();
    } catch (DAOException | ValidationException e) {
      LOGGER.error("Error while trying to push Sonar Metrics in ProgramEntity", e);
    }
  }
}

