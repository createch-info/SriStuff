/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.odaudit.service;

public class AuditServiceConstants {

  public static final String GIT_REPO =
      "https://gitbucket.tvlport.com/git/sri.ponnapalli/albumdomain-sponnapalli102.git";
  public static final String GIT_REPO_BRANCH = "develop";

  public static final String HTTP_PROTOCOL = "http://";
  public static final String HTTPS_PROTOCOL = "https://";
  public static final String SONAR_URL = "SONAR_URL";
  public static final String SONAR_API_RSC_INDEX = "/api/resources/index?resource=";
  public static final String SONAR_API_COMP_MEASURES = "/api/measures/component?componentKey=";
  public static final String SONAR_API_MEASURES_LIST =
      "&metricKeys=bugs,vulnerabilities,code_smells,sqale_index,ncloc,coverage,complexity";
  public static final String SONAR_API_RESPONSE_FORMAT = "&format=json";
  public static final String SONAR_PROJECT_OVERVIEW_FORMAT = "/overview?id=";
  public static final String TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ssZ";
  public static final String TIME_ZONE = "UTC";
  public static final int LAST_SCAN_DAYS_LIMIT = -7;


  /*
   * Environment Variables to be added {SONAR_URL = vhldvssbs012.tvlport.net:9000}
   */

}