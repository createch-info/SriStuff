/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.odaudit.service.domain;

import java.util.List;

public class SonarMetrics {

  private String key;
  private String name;
  private String description;
  private List<SonarMeasure> measures;

  /**
   * Returns the component key
   *
   * @return String
   */
  public String getKey() {
    return key;
  }

  /**
   * Assigns the component key
   *
   * @param component key to assign
   */
  public void setKey(String key) {
    this.key = key;
  }

  /**
   * Returns the component name
   *
   * @return String
   */
  public String getName() {
    return name;
  }

  /**
   * Assigns the component name
   *
   * @param component name to assign
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Returns the component description
   *
   * @return String
   */
  public String getDescription() {
    return description;
  }

  /**
   * Assigns the component description
   *
   * @param component description to assign
   */
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * Returns the list of sonar measures for a scan
   *
   * @return String
   */
  public List<SonarMeasure> getMeasures() {
    return measures;
  }

  /**
   * Assigns the list of sonar measures for a scan
   *
   * @param list of sonar measures to assign
   */
  public void setMeasures(List<SonarMeasure> measures) {
    this.measures = measures;
  }

  @Override
  public String toString() {

    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("key : " + this.key + '\n');
    stringBuilder.append("name : " + this.name + '\n');
    stringBuilder.append("description : " + this.description + '\n');

    return stringBuilder.toString();
  }
}
