/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.odaudit.service.domain;

public class SonarMeasure {

  private String metric;
  private String value;

  /**
   * Returns the metric name
   *
   * @return long
   */
  public String getMetric() {
    return metric;
  }

  /**
   * Assigns sonar metric name
   *
   * @param # of bugs to assign
   */
  public void setMetric(String metric) {
    this.metric = metric;
  }

  /**
   * Returns the metric value
   *
   * @return long
   */
  public String getValue() {
    return value;
  }

  /**
   * Assigns sonar metric value
   *
   * @param metric value to assign
   */
  public void setValue(String value) {
    this.value = value;
  }

  @Override
  public String toString() {

    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("metric : " + this.metric + '\n');
    stringBuilder.append("value : " + this.value + '\n');

    return stringBuilder.toString();
  }
}
