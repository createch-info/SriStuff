/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.odaudit.service;

import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import com.travelport.otm.odaudit.dao.DAOException;
import com.travelport.otm.odaudit.dao.DAOFactory;
import com.travelport.otm.odaudit.dao.GitRepositoryDAO;
import com.travelport.otm.odaudit.dao.OrganizationDAO;
import com.travelport.otm.odaudit.dao.ProjectTeamDAO;
import com.travelport.otm.odaudit.model.GitRepositoryEntity;
import com.travelport.otm.odaudit.model.OrganizationEntity;
import com.travelport.otm.odaudit.model.ProjectTeamEntity;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;
import com.travelport.otm.odaudit.validation.ODAuditServiceException;

@Path("/od_audit")
@Consumes({MediaType.APPLICATION_JSON})
@Produces({MediaType.APPLICATION_JSON})
public class OrgRollup extends SonarMetricsRollup {

  private DAOFactory daoFactory = new DAOFactory();
  private OrganizationDAO orgDao = daoFactory.newOrganizationDAO();
  private ProjectTeamDAO projTeamDao = daoFactory.newProjectTeamDAO();
  private GitRepositoryDAO gitRepositoryDao = daoFactory.newGitRepositoryDAO();



  @POST
  @Path("/rollupAllOrgs/{odProgramReportId}")
  @Produces({MediaType.TEXT_PLAIN})
  public Response rollUpAllOrgs(@PathParam("odProgramReportId") long odProgramReportId)
      throws DAOException, ODAuditServiceException {
    DAOFactory.initializeJPAServices();
    if (odProgramReportId >= 0) {
      List<OrganizationEntity> orgList = orgDao.getAll();
      if (orgList.isEmpty()) {
        return Response.status(Status.NO_CONTENT).entity("OrganizationEntity cannot be null")
            .build();
      }
      for (OrganizationEntity orgEntity : orgList) {
        long orgId = orgEntity.getId();
        getProjectTeamDetails(orgId, orgEntity, odProgramReportId);
      }
    } else {
      throw new IllegalArgumentException("Provided odProgramId is Invalid" + odProgramReportId);
    }
    DAOFactory.shutdownJPAServices();

    return Response.status(Status.OK)
        .entity("The Sonar Data is uploaded for all Organization repositories").build();
  }

  @POST
  @Path("/rollupSingleOrgs/{odProgramReportId}/{organizationId}")
  @Produces({MediaType.TEXT_PLAIN})
  public Response rollUpSingleOrgs(@PathParam("odProgramReportId") long odProgramReportId,
      @PathParam("organizationId") long organizationId)
      throws ODAuditServiceException, DAOException {
    DAOFactory.initializeJPAServices();
    if (odProgramReportId >= 0 && organizationId >= 0) {
      OrganizationEntity organizationEntity = orgDao.findById(organizationId);
      List<OrganizationEntity> orgList = new ArrayList<>();
      orgList.add(organizationEntity);
      if (orgList.isEmpty()) {
        return Response.status(Status.NO_CONTENT).entity("OrganizationEntity cannot be null")
            .build();
      }
      for (OrganizationEntity orgEntity : orgList) {
        long orgId = orgEntity.getId();
        getProjectTeamDetails(orgId, orgEntity, odProgramReportId);
      }
    } else {
      throw new IllegalArgumentException("Provided odProgramReportId and OrgId is Invalid"
          + odProgramReportId + "," + organizationId);
    }
    DAOFactory.shutdownJPAServices();
    return Response.status(Status.OK)
        .entity("The Sonar Data is uploaded for the provided OrganizationID").build();
  }

  public void getProjectTeamDetails(long orgId, OrganizationEntity orgEntity,
      long odProgramReportId) throws ODAuditServiceException, DAOException {
    SonarScanInfoEntity sonarScanEntityAvg = null;
    List<ProjectTeamEntity> projTeamList;
    List<GitRepositoryEntity> gitRepositoryList;
    List<Long> errorPtList = new ArrayList<>();
    List<Long> errorGitRepoList = new ArrayList<>();
    projTeamList = projTeamDao.findByOrgId(orgId);
    if (projTeamList.isEmpty()) {
      errorPtList.add(orgId);
      throw new ODAuditServiceException("ProjectTeam details cannot be null" + errorPtList);
    }

    for (ProjectTeamEntity projTeamEntity : projTeamList) {
      long projectTeamId = projTeamEntity.getId();
      gitRepositoryList = gitRepositoryDao.findByPtId(projectTeamId);
      if (!gitRepositoryList.isEmpty()) {
        sonarScanEntityAvg = calculateSonarScanMetricsAvg(gitRepositoryList);
      } else {
        errorGitRepoList.add(projectTeamId);
        throw new ODAuditServiceException("gitRepositoryList cannot be null" + errorGitRepoList);

      }

    }
    putSonarMetrics(sonarScanEntityAvg, orgEntity, odProgramReportId);
  }

}
