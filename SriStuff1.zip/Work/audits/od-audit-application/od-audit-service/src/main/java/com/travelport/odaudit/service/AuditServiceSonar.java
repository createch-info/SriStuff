/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.odaudit.service;

import javax.ws.rs.core.Response;
import com.travelport.otm.odaudit.dao.DAOException;

public interface AuditServiceSonar {

  public Response getAllRepositoryDetails(long odProgramReportId) throws DAOException;

  public Response getRepositoryDetails(long odProgramReportId, String gitURL) throws DAOException;

}



