/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.odaudit.service;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import com.travelport.otm.odaudit.dao.DAOException;
import com.travelport.otm.odaudit.dao.DAOFactory;
import com.travelport.otm.odaudit.dao.GitRepositoryDAO;
import com.travelport.otm.odaudit.dao.ProjectTeamDAO;
import com.travelport.otm.odaudit.model.GitRepositoryEntity;
import com.travelport.otm.odaudit.model.ProjectTeamEntity;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;

@Path("/od_audit")
@Consumes({MediaType.APPLICATION_JSON})
@Produces({MediaType.APPLICATION_JSON})
public class ProjectTeamRollup extends SonarMetricsRollup {

  private DAOFactory daoFactory = new DAOFactory();
  private ProjectTeamDAO projTeamDao = daoFactory.newProjectTeamDAO();
  private GitRepositoryDAO gitRepositoryDao = daoFactory.newGitRepositoryDAO();
  private SonarScanInfoEntity sonarScanEntityAvg;

  @POST
  @Path("/rollupAllPts/{odProgramReportId}")
  @Produces({MediaType.TEXT_PLAIN})
  public Response rollUpAllPts(@PathParam("odProgramReportId") long odProgramReportId)
      throws DAOException {
    DAOFactory.initializeJPAServices();
    if (odProgramReportId >= 0) {
      List<ProjectTeamEntity> projTeamList = projTeamDao.findAll();
      List<GitRepositoryEntity> gitRepositoryList;
      if (projTeamList.isEmpty()) {
        return Response.status(Status.NO_CONTENT).entity("ProjectTeamList cannot be null").build();
      }
      for (ProjectTeamEntity projTeamEnity : projTeamList) {
        long projectTeamId = projTeamEnity.getId();
        gitRepositoryList = gitRepositoryDao.findByPtId(projectTeamId);
        if (!gitRepositoryList.isEmpty()) {
          sonarScanEntityAvg = calculateSonarScanMetricsAvg(gitRepositoryList);
        } else {
          return Response.status(Status.NO_CONTENT).entity("gitRepositoryList cannot be null")
              .build();
        }
        putSonarMetrics(sonarScanEntityAvg, projTeamEnity, odProgramReportId);
      }
    } else {
      throw new IllegalArgumentException("Provided odProgramId is Invalid" + odProgramReportId);
    }
    DAOFactory.shutdownJPAServices();
    return Response.status(Status.OK)
        .entity("The Sonar Data is uploaded for all ProjectTeam repositories").build();
  }


  @POST
  @Path("/rollupSinglePt/{odProgramReportId}/{projectTeamId}")
  @Produces({MediaType.TEXT_PLAIN})
  public Response rollUpSinglePt(@PathParam("odProgramReportId") long odProgramReportId,
      @PathParam("projectTeamId") long projectTeamId) throws DAOException {
    DAOFactory.initializeJPAServices();
    if (odProgramReportId >= 0 && projectTeamId >= 0) {
      List<GitRepositoryEntity> gitRepositoryList;
      ProjectTeamEntity projectTeamEntity = projTeamDao.findById(projectTeamId);
      gitRepositoryList = gitRepositoryDao.findByPtId(projectTeamId);
      if (gitRepositoryList != null && !gitRepositoryList.isEmpty()) {
        sonarScanEntityAvg = calculateSonarScanMetricsAvg(gitRepositoryList);
      } else {
        return Response.status(Status.NO_CONTENT).entity("gitRepositoryList cannot be null")
            .build();
      }
      putSonarMetrics(sonarScanEntityAvg, projectTeamEntity, odProgramReportId);
    } else {
      throw new IllegalArgumentException("Provided odProgramId and projectTeamId is Invalid"
          + odProgramReportId + "," + projectTeamId);
    }
    DAOFactory.shutdownJPAServices();
    return Response.status(Status.OK)
        .entity("The Sonar Data is uploaded for the provided ProgramId").build();
  }


}


