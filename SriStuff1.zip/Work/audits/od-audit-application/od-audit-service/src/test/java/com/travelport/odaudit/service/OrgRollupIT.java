/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.odaudit.service;

import static org.junit.Assert.assertEquals;
import java.util.List;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import org.junit.Before;
import org.junit.Test;
import com.travelport.otm.odaudit.dao.DAOException;
import com.travelport.otm.odaudit.dao.DAOFactory;
import com.travelport.otm.odaudit.dao.OdProgramReportDAO;
import com.travelport.otm.odaudit.model.OdProgramReportEntity;


public class OrgRollupIT {
  private OrgRollup auditOrg;
  List<OdProgramReportEntity> odProgramList;

  @Before
  public void setup() throws DAOException {

    auditOrg = new OrgRollup();

    DAOFactory.initializeJPAServices();
    DAOFactory daoFactory = new DAOFactory();
    OdProgramReportDAO odProgramReportDAO = daoFactory.newOdProgramReportDAO();
    odProgramList = odProgramReportDAO.getAll();
    DAOFactory.shutdownJPAServices();

  }

  @Test
  public void rollUpAllOrgsTest() throws Exception {
    Response response;

    for (OdProgramReportEntity odProgramID : odProgramList) {
      Long id = odProgramID.getId();
      response=auditOrg.rollUpAllOrgs(id);
      
      assertEquals(Status.OK.getStatusCode(), response.getStatus());
    }

  }

}