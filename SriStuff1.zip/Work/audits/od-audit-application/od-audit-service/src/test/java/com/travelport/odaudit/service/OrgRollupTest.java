/*******************************************************************************
 * Copyright (c) 2017 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.odaudit.service;

import static org.junit.Assert.assertEquals;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import com.travelport.otm.odaudit.dao.DAOFactory;
import com.travelport.otm.odaudit.dao.GitRepositoryDAO;
import com.travelport.otm.odaudit.dao.ODScanDAO;
import com.travelport.otm.odaudit.dao.OdProgramReportDAO;
import com.travelport.otm.odaudit.dao.OrganizationDAO;
import com.travelport.otm.odaudit.dao.ProjectTeamDAO;
import com.travelport.otm.odaudit.model.GitRepositoryEntity;
import com.travelport.otm.odaudit.model.OrganizationEntity;
import com.travelport.otm.odaudit.model.ProjectTeamEntity;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;
import com.travelport.otm.odaudit.validation.ODAuditServiceException;
import mockit.Expectations;
import mockit.Mocked;
import mockit.integration.junit4.JMockit;

@RunWith(JMockit.class)
public class OrgRollupTest {
  private static final int ORG_ID=1;
  private static final int ODPRGM_ID=2;
  private static final int INVALID_ID=-1;

  private OrgRollup auditOrg;
  private SonarScanInfoEntity sonarScanEntity;
  List<OrganizationEntity> orgEntityList = new ArrayList<>();
  List<ProjectTeamEntity> projTeamList = new ArrayList<>();
  List<GitRepositoryEntity> gitRepositoryList = new ArrayList<>();

  @Mocked
  private DAOFactory daoFactory;
  @Mocked
  private OrganizationDAO orgDao;
  @Mocked
  private ProjectTeamDAO projTeamDao;
  @Mocked
  private GitRepositoryDAO gitRepositoryDao;
  @Mocked
  private ODScanDAO odScanDao;
  @Mocked
  private OdProgramReportDAO odProgramReportDAO;
 
 



  @Before
  public void setup() {
    auditOrg = new OrgRollup();
    

    orgEntityList.add(MockTestDataUtil.createOrganizationEntity());
    projTeamList.add(MockTestDataUtil.createProjectTeamEntity());
    gitRepositoryList.add(MockTestDataUtil.createGitRepositoryEntity());
    sonarScanEntity=MockTestDataUtil.createSonarScanInfoEntity();
    
  }

  @Test
  public void rollUpAllOrgsTest() throws Exception {
    new Expectations() {
      {
        orgDao.getAll();
        returns(orgEntityList);
        
        projTeamDao.findByOrgId(anyLong);
        returns(projTeamList);

        gitRepositoryDao.findByPtId(anyLong);
        returns(gitRepositoryList);

        odScanDao.findLatestScanInfoForGitRepo(anyLong);
        returns(sonarScanEntity);

      }
    };
    Response response = auditOrg.rollUpAllOrgs(ODPRGM_ID);
    assertEquals(Status.OK.getStatusCode(), response.getStatus());
  }


  @Test
  public void rollUpSingleOrgsTest() throws Exception {
    new Expectations() {
      {

        orgDao.findById(anyLong);
        returns(orgEntityList);

        projTeamDao.findByOrgId(anyLong);
        returns(projTeamList);

        gitRepositoryDao.findByPtId(anyLong);
        returns(gitRepositoryList);

        odScanDao.findLatestScanInfoForGitRepo(anyLong);
        returns(sonarScanEntity);

      }
    };
    Response response = auditOrg.rollUpSingleOrgs(ODPRGM_ID, ORG_ID);
    assertEquals(Status.OK.getStatusCode(), response.getStatus());
  }

  @Test
  public void rollUpAllOrgsEmptyOrgsListTest() throws Exception {
    new Expectations() {
      {
        orgEntityList = new ArrayList<>();
        orgDao.getAll();
        returns(orgEntityList);
      }
    };
    Response response = auditOrg.rollUpAllOrgs(ODPRGM_ID);
    assertEquals(Status.NO_CONTENT.getStatusCode(), response.getStatus());
  }
 @Test(expected=NullPointerException.class)
  public void rollUpSingleOrgsNullOrgsListTest() throws Exception {
    new Expectations() {
      {
        orgEntityList =null;
        orgDao.findById(anyLong);
        returns(orgEntityList);
      }
    };
   auditOrg.rollUpSingleOrgs(ODPRGM_ID, ORG_ID);
   
  }

  @Test(expected = ODAuditServiceException.class)
  public void rollUpAllOrgsEmptyprojTeamListTest() throws Exception {
    new Expectations() {
      {

        orgDao.getAll();
        returns(orgEntityList);
        projTeamList = new ArrayList<>();
        projTeamDao.findByOrgId(anyLong);
        returns(projTeamList);
      }
    };
    Response response = auditOrg.rollUpAllOrgs(ODPRGM_ID);
    assertEquals(Status.NO_CONTENT.getStatusCode(), response.getStatus());
  }

  @Test(expected = ODAuditServiceException.class)
  public void rollUpAllOrgsEmptygitRepoListTest() throws Exception {
    new Expectations() {
      {

        orgDao.getAll();
        returns(orgEntityList);

        projTeamDao.findByOrgId(anyLong);
        returns(projTeamList);

        gitRepositoryList = new ArrayList<>();
        gitRepositoryDao.findByPtId(anyLong);
        returns(gitRepositoryList);
      }
    };
    Response response = auditOrg.rollUpAllOrgs(ODPRGM_ID);
    assertEquals(Status.NO_CONTENT.getStatusCode(), response.getStatus());
  }
  @Test(expected = IllegalArgumentException.class)
  public void rollUpAllOrgsNegativeOdPrgmIdTest() throws Exception {   
    auditOrg.rollUpAllOrgs(INVALID_ID);
  }
  @Test(expected = IllegalArgumentException.class)
  public void rollUpSingleOrgsNegativeOdPrgmOrgIdTest() throws Exception {   
    auditOrg.rollUpSingleOrgs(INVALID_ID, INVALID_ID);
  }

}
