/*******************************************************************************
 * Copyright (c) 2017 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.odaudit.service;

import static org.junit.Assert.assertEquals;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import com.travelport.otm.odaudit.dao.DAOFactory;
import com.travelport.otm.odaudit.dao.GitRepositoryDAO;
import com.travelport.otm.odaudit.dao.ODScanDAO;
import com.travelport.otm.odaudit.dao.OdProgramReportDAO;
import com.travelport.otm.odaudit.dao.OrganizationDAO;
import com.travelport.otm.odaudit.dao.OrganizationReportDAO;
import com.travelport.otm.odaudit.dao.ProjectTeamDAO;
import com.travelport.otm.odaudit.model.GitRepositoryEntity;
import com.travelport.otm.odaudit.model.OdProgramReportEntity;
import com.travelport.otm.odaudit.model.OrganizationEntity;
import com.travelport.otm.odaudit.model.OrganizationReportEntity;
import com.travelport.otm.odaudit.model.ProjectTeamEntity;
import com.travelport.otm.odaudit.validation.ODAuditServiceException;
import mockit.Expectations;
import mockit.Mocked;
import mockit.Tested;
import mockit.integration.junit4.JMockit;

@RunWith(JMockit.class)
public class ProgramRollupTest {

  List<OrganizationEntity> orgEntityList = new ArrayList<>();
  List<ProjectTeamEntity> projTeamList = new ArrayList<>();
  List<GitRepositoryEntity> gitRepositoryList = new ArrayList<>();
  List<OdProgramReportEntity> odProgramList = new ArrayList<>();
  List<OrganizationReportEntity> orgReportEntityList = new ArrayList<>();


  @Tested
  private ProgramRollup auditProgram;
  @Mocked
  private DAOFactory daoFactory;
  @Mocked
  private OrganizationDAO orgDao;
  @Mocked
  private ProjectTeamDAO projTeamDao;
  @Mocked
  private GitRepositoryDAO gitRepositoryDao;
  @Mocked
  private ODScanDAO odScanDao;
  @Mocked
  private OdProgramReportDAO odProgramReportDAO;
  @Mocked
  private OrganizationReportDAO orgReportDao;

 
  @Before
  public void setup() {
    auditProgram = new ProgramRollup();
   

    odProgramList.add(MockTestDataUtil.createOdProgramReportEntity());
    orgReportEntityList.add(MockTestDataUtil.createOrganizationReportEntity());
    projTeamList.add(MockTestDataUtil.createProjectTeamEntity());
    gitRepositoryList.add(MockTestDataUtil.createGitRepositoryEntity());

  }



  @Test
  public void rollUpAllProgmsTest() throws Exception {

    new Expectations() {
      {
        odProgramReportDAO.getAll();
        returns(odProgramList);

        orgReportDao.findByOdPrgmId(anyLong);
        returns(orgReportEntityList);


        projTeamDao.findByOrgId(anyLong);
        returns(projTeamList);

        gitRepositoryDao.findByPtId(anyLong);
        returns(gitRepositoryList);

        odScanDao.findLatestScanInfoForGitRepo(anyLong);
        returns(MockTestDataUtil.createSonarScanInfoEntity());

      }
    };
    Response response = auditProgram.rollUpAllPrgs();
    assertEquals((Status.OK.getStatusCode()), response.getStatus());
  }



  @Test
  public void rollUpAllPrgsEmptyOdPrgmListTest() throws Exception {
    new Expectations() {
      {
        odProgramList = new ArrayList<>();
        odProgramReportDAO.getAll();
        returns(odProgramList);
      }
    };
    Response response = auditProgram.rollUpAllPrgs();
    assertEquals(Status.NO_CONTENT.getStatusCode(), response.getStatus());
  }

  @Test(expected = NullPointerException.class)
  public void rollUpAllPrgsNullOdPrgmListTest() throws Exception {
    new Expectations() {
      {
        odProgramList = null;
        odProgramReportDAO.getAll();
        returns(odProgramList);
      }
    };
    auditProgram.rollUpAllPrgs();

  }


  @Test(expected = NullPointerException.class)
  public void rollUpAllPrgsNullPtListTest() throws Exception {
    new Expectations() {
      {

        odProgramReportDAO.getAll();
        returns(odProgramList);

        orgReportDao.findByOdPrgmId(anyLong);
        returns(orgReportEntityList);


        projTeamList = null;
        projTeamDao.findByOrgId(anyLong);
        returns(projTeamList);


      }
    };
    auditProgram.rollUpAllPrgs();

  }
  @Test(expected = ODAuditServiceException.class)
  public void rollUpAllPrgsEmptyPtListTest() throws Exception {
    new Expectations() {
      {

        odProgramReportDAO.getAll();
        returns(odProgramList);

        orgReportDao.findByOdPrgmId(anyLong);
        returns(orgReportEntityList);


        projTeamList = new ArrayList<>();
        projTeamDao.findByOrgId(anyLong);
        returns(projTeamList);


      }
    };
    auditProgram.rollUpAllPrgs();

  }
  @Test
  public void rollUpAllPrgsEmptyOrgListTest() throws Exception {
    new Expectations() {
      {

        odProgramReportDAO.getAll();
        returns(odProgramList);
        
        orgReportEntityList=new ArrayList<>();
        orgReportDao.findByOdPrgmId(anyLong);
        returns(orgReportEntityList);

      }
    };
    Response response=auditProgram.rollUpAllPrgs();
    assertEquals(Status.NO_CONTENT.getStatusCode(),response.getStatus());

  }

  @Test(expected = NullPointerException.class)
  public void rollUpAllPrgsNullOrgListTest() throws Exception {
    new Expectations() {
      {

        odProgramReportDAO.getAll();
        returns(odProgramList);

        orgReportEntityList = null;
        orgReportDao.findByOdPrgmId(anyLong);
        returns(orgReportEntityList);



      }
    };
    auditProgram.rollUpAllPrgs();


  }

  


  @Test(expected = NullPointerException.class)
  public void rollUpAllPrgsNullGitRepoListTest() throws Exception {
    new Expectations() {
      {

        odProgramReportDAO.getAll();
        returns(odProgramList);

        orgReportDao.findByOdPrgmId(anyLong);
        returns(orgReportEntityList);

        projTeamDao.findByOrgId(anyLong);
        returns(projTeamList);

        gitRepositoryList = null;
        gitRepositoryDao.findByPtId(anyLong);
        returns(gitRepositoryList);

      }
    };
    auditProgram.rollUpAllPrgs();

  }
  @Test(expected = ODAuditServiceException.class)
  public void rollUpAllPrgsEmptyGitRepoListTest() throws Exception {
    new Expectations() {
      {

        odProgramReportDAO.getAll();
        returns(odProgramList);

        orgReportDao.findByOdPrgmId(anyLong);
        returns(orgReportEntityList);

        projTeamDao.findByOrgId(anyLong);
        returns(projTeamList);

        gitRepositoryList = new ArrayList<>();
        gitRepositoryDao.findByPtId(anyLong);
        returns(gitRepositoryList);

      }
    };
    auditProgram.rollUpAllPrgs();

  }



}
