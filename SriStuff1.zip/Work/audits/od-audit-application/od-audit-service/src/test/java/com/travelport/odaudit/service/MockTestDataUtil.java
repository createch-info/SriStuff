/*******************************************************************************
 * Copyright (c) 2017 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.odaudit.service;

import java.util.Calendar;
import com.travelport.otm.odaudit.model.GitRepositoryEntity;
import com.travelport.otm.odaudit.model.OdProgramReportEntity;
import com.travelport.otm.odaudit.model.OrganizationEntity;
import com.travelport.otm.odaudit.model.OrganizationReportEntity;
import com.travelport.otm.odaudit.model.ProjectTeamEntity;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;
import com.travelport.otm.odaudit.type.RepositoryType;

public final class MockTestDataUtil {

private static final int ID = 1;

// Default values for sonar scans
private static final float TEST_BUGS = 10;
private static final float TEST_VULNERABILITIES = 20;
private static final float TEST_TECH_DEBT = 180;
private static final float TEST_CODE_COVERAGE = 60;
private static final float TEST_COMPLEXITY = 15;
private static final float TEST_CODE_SMELLS = 20;
private static final int TEST_LINES_OF_CODE = 2000;


  public static OrganizationReportEntity createOrganizationReportEntity() {  
    OrganizationReportEntity orgReportEntity=new OrganizationReportEntity();
    orgReportEntity.setOrganization(createOrganizationEntity());
    orgReportEntity.setOdProgramReport(createOdProgramReportEntity());
    orgReportEntity.setSonarScanInfo(createSonarScanInfoEntity());
    return orgReportEntity;
  }

  public static OdProgramReportEntity createOdProgramReportEntity() {
    OdProgramReportEntity odProgramReportEntity=new OdProgramReportEntity();
    odProgramReportEntity.setId(ID);
    odProgramReportEntity.setOdReportDate(Calendar.getInstance().getTime());
    odProgramReportEntity.setSonarScanInfo(createSonarScanInfoEntity());
    return odProgramReportEntity;
  }

  public static SonarScanInfoEntity createSonarScanInfoEntity() {
    SonarScanInfoEntity sonarScanEntity=new SonarScanInfoEntity();
    sonarScanEntity.setId(ID);
    sonarScanEntity.setBugs(TEST_BUGS);
    sonarScanEntity.setCodeCoverage(TEST_CODE_COVERAGE);
    sonarScanEntity.setCodeSmells(TEST_CODE_SMELLS);
    sonarScanEntity.setComplexity(TEST_COMPLEXITY);
    sonarScanEntity.setVulnerabilities(TEST_VULNERABILITIES);
    sonarScanEntity.setTechDebt(TEST_TECH_DEBT);
    sonarScanEntity.setLinesOfCode(TEST_LINES_OF_CODE);
    return sonarScanEntity;
  }

  public static GitRepositoryEntity createGitRepositoryEntity() {
    GitRepositoryEntity gitRepoEntity=new GitRepositoryEntity();
    gitRepoEntity.setId(ID);
    gitRepoEntity.setBranch("develop");
    gitRepoEntity.setDeleted(false);
    gitRepoEntity.setProjectKey("projectKey");
    gitRepoEntity.setProjectName("projectName");
    gitRepoEntity.setRepositoryUrl("repositoryURL");
    gitRepoEntity.setType(RepositoryType.TEST);
    gitRepoEntity.setRepositoryName("repositoryName");
    return gitRepoEntity;
  }

  public static ProjectTeamEntity createProjectTeamEntity() {
    ProjectTeamEntity projectTeamEntity=new ProjectTeamEntity();
    projectTeamEntity.setId(ID);
    projectTeamEntity.setOrganization(createOrganizationEntity());
    projectTeamEntity.setName("projectTeamName");
    projectTeamEntity.setDeleted(false);
    return projectTeamEntity;
  }

  public static OrganizationEntity createOrganizationEntity() {
    OrganizationEntity organisationEntity=new OrganizationEntity();
    organisationEntity.setId(ID);
    organisationEntity.setName("ODT");
    organisationEntity.setDeleted(false);
    return organisationEntity;
  }

}
