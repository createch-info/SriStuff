/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.odaudit.service;

import static org.junit.Assert.assertNotNull;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;
import org.eclipse.jgit.api.CloneCommand;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.LogCommand;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.revwalk.RevCommit;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import com.travelport.otm.odaudit.dao.DAOException;
import com.travelport.otm.odaudit.dao.DAOFactory;
import com.travelport.otm.odaudit.dao.GitRepositoryDAO;
import com.travelport.otm.odaudit.model.GitRepositoryEntity;
import com.travelport.otm.odaudit.type.RepositoryType;
import mockit.Expectations;
import mockit.Mocked;
import mockit.integration.junit4.JMockit;

@RunWith(JMockit.class)
public class AuditServiceImplTest {

  private AuditServiceSonarImpl auditServiceSonarImpl;
  List<GitRepositoryEntity> repolist = new ArrayList();

  @Mocked
  private DAOFactory daoFactory;
  @Mocked
  private GitRepositoryDAO gitRepositoryDAO;
  @Mocked
  private Git git;
  @Mocked
  private CloneCommand cloneCommand;
  @Mocked
  private LogCommand logCommand;
  @Mocked
  private RevCommit revCommit;
  @Mocked
  private Client client;
  @Mocked
  private ClientBuilder clientBuilder;
  @Mocked
  private WebTarget webTarget;
  @Mocked
  private Response response;


  @Before
  public void setup() {
    auditServiceSonarImpl = new AuditServiceSonarImpl();
    GitRepositoryEntity gitRepositoryEntity = new GitRepositoryEntity();
    gitRepositoryEntity.setBranch("develop");
    gitRepositoryEntity.setDeleted(false);
    gitRepositoryEntity.setId(1);
    gitRepositoryEntity.setProjectKey("testKey");
    gitRepositoryEntity.setProjectName("testName");
    gitRepositoryEntity.setRepositoryName("testName");
    gitRepositoryEntity.setRepositoryUrl("testrepo");
    gitRepositoryEntity.setType(RepositoryType.TEST);
    repolist.add(gitRepositoryEntity);
    EnvironmentVariableTestUtil.setenv(AuditServiceConstants.SONAR_URL,
        "vhldvssbs012.tvlport.net:9000");
  }

  @Test(expected = NullPointerException.class)
  public void getAllRepositoryDetailsNullValueTest() throws DAOException {
    new Expectations() {
      {
        List<GitRepositoryEntity> repoList1 = null;
        gitRepositoryDAO.findAll();
        returns(repoList1);
      }
    };
    auditServiceSonarImpl.getAllRepositoryDetails(4);
  }

  @Test
  public void getAllRepositoryDetailsTest() throws GitAPIException, DAOException {
    new Expectations() {
      {
        gitRepositoryDAO.findAll();
        returns(repolist);

        List<RevCommit> commitList = new ArrayList();
        commitList.add(revCommit);

        git.log().setMaxCount(1).call();
        returns(commitList);

        int commitTime = 1516902307; // In your local time zone: 2018-01-25T23:15:07+00:00
        revCommit.getCommitTime();
        returns(commitTime);

        String indexResponse = "/indexResponse.json";
        InputStream indexRes = AuditServiceImplTest.class.getResourceAsStream(indexResponse);
        String indexResult = new BufferedReader(new InputStreamReader(indexRes)).lines()
            .collect(Collectors.joining("\n"));

        String metricResponse = "/metricResponse.json";
        InputStream metricRes = AuditServiceImplTest.class.getResourceAsStream(metricResponse);
        String metricResult = new BufferedReader(new InputStreamReader(metricRes)).lines()
            .collect(Collectors.joining("\n"));

        response.readEntity(String.class);
        returns(indexResult, metricResult);
      }
    };
    Response response = auditServiceSonarImpl.getAllRepositoryDetails(4);
    assertNotNull(response);
  }

  @Test
  public void getRepositoryDetailsTest() throws GitAPIException, DAOException {
    new Expectations() {
      {

        gitRepositoryDAO.findByRepositoryUrl(anyString);
        returns(repolist);

        List<RevCommit> commitList = new ArrayList();
        commitList.add(revCommit);

        git.log().setMaxCount(1).call();
        returns(commitList);

        int commitTime = 1516902307; // In your local time zone: 2018-01-25T23:15:07+00:00
        revCommit.getCommitTime();
        returns(commitTime);

        String indexResponse = "/indexResponse.json";
        InputStream indexRes = AuditServiceImplTest.class.getResourceAsStream(indexResponse);
        String indexResult = new BufferedReader(new InputStreamReader(indexRes)).lines()
            .collect(Collectors.joining("\n"));

        String metricResponse = "/metricResponse.json";
        InputStream metricRes = AuditServiceImplTest.class.getResourceAsStream(metricResponse);
        String metricResult = new BufferedReader(new InputStreamReader(metricRes)).lines()
            .collect(Collectors.joining("\n"));

        response.readEntity(String.class);
        returns(indexResult, metricResult);
      }
    };
    Response response = auditServiceSonarImpl.getRepositoryDetails(4, "testURL");
    assertNotNull(response);
  }


  @Test(expected = WebApplicationException.class)
  public void sonarRollUpGitFailedTest() throws GitAPIException, DAOException {
    new Expectations() {
      {
        gitRepositoryDAO.findAll();
        returns(repolist);

        git.cloneRepository();
        result = new GitAPIException("") {};
      }
    };
    Response response = auditServiceSonarImpl.getAllRepositoryDetails(4);
    assertNotNull(response);
  }

  @Test(expected = WebApplicationException.class)
  public void sonarRollUpDAOFailCommitTest() throws GitAPIException, DAOException {
    new Expectations() {
      {

        gitRepositoryDAO.findByRepositoryUrl(anyString);
        returns(repolist);

        List<RevCommit> commitList = new ArrayList();
        commitList.add(revCommit);

        git.log().setMaxCount(1).call();
        returns(commitList);

        int commitTime = 1516902307; // In your local time zone: 2018-01-25T23:15:07+00:00
        revCommit.getCommitTime();
        returns(commitTime);

        String indexResponse = "/indexResponse.json";
        InputStream indexRes = AuditServiceImplTest.class.getResourceAsStream(indexResponse);
        String indexResult = new BufferedReader(new InputStreamReader(indexRes)).lines()
            .collect(Collectors.joining("\n"));

        String metricResponse = "/metricResponse.json";
        InputStream metricRes = AuditServiceImplTest.class.getResourceAsStream(metricResponse);
        String metricResult = new BufferedReader(new InputStreamReader(metricRes)).lines()
            .collect(Collectors.joining("\n"));

        response.readEntity(String.class);
        returns(indexResult, metricResult);

        daoFactory.commitTransaction();
        result = new DAOException();

        daoFactory.rollbackTransaction();
        result = new DAOException();
      }
    };
    Response response = auditServiceSonarImpl.getRepositoryDetails(4, "testURL");
    assertNotNull(response);
  }


}