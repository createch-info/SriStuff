/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.odaudit.service;

import static org.junit.Assert.assertEquals;
import java.util.List;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import org.junit.Before;
import org.junit.Test;
import com.travelport.otm.odaudit.dao.DAOException;
import com.travelport.otm.odaudit.dao.DAOFactory;
import com.travelport.otm.odaudit.dao.OdProgramReportDAO;
import com.travelport.otm.odaudit.model.OdProgramReportEntity;


public class ProjectTeamRollupIT {
  
  private ProjectTeamRollup auditPt;
  Response response;
  List<OdProgramReportEntity> odProgramList;

  @Before
  public void setup() throws DAOException {
    auditPt = new ProjectTeamRollup();
    DAOFactory.initializeJPAServices();
    DAOFactory daoFactory = new DAOFactory();
    OdProgramReportDAO odProgramReportDAO = daoFactory.newOdProgramReportDAO();
    odProgramList = odProgramReportDAO.getAll();
    DAOFactory.shutdownJPAServices();
  }

  @Test
  public void rollUpAllPtsTest() throws Exception {

    for (OdProgramReportEntity odProgramID : odProgramList) {
      Long id = odProgramID.getId();
      response =auditPt.rollUpAllPts(id);
    }
    
   
    assertEquals(Status.OK.getStatusCode(), response.getStatus());
  }

}
