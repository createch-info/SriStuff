/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.odaudit.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import com.travelport.otm.odaudit.dao.DAOFactory;
import com.travelport.otm.odaudit.dao.GitRepositoryDAO;
import com.travelport.otm.odaudit.dao.ODScanDAO;
import com.travelport.otm.odaudit.dao.OdProgramReportDAO;
import com.travelport.otm.odaudit.dao.ProjectTeamDAO;
import com.travelport.otm.odaudit.model.GitRepositoryEntity;
import com.travelport.otm.odaudit.model.ProjectTeamEntity;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;
import mockit.Expectations;
import mockit.Mocked;
import mockit.integration.junit4.JMockit;

@RunWith(JMockit.class)
public class ProjectTeamRollupTest {
  private static final int PT_ID = 3;
  private static final int ODPRGM_ID = 1;
  private static final int INVALID_ID = -1;

  private ProjectTeamRollup auditPt;
  private SonarScanInfoEntity sonarScanEntity;
  List<ProjectTeamEntity> projTeamList = new ArrayList<>();
  List<GitRepositoryEntity> gitRepositoryList = new ArrayList<>();

  @Mocked
  private DAOFactory daoFactory;
  @Mocked
  private ProjectTeamDAO projTeamDao;
  @Mocked
  private GitRepositoryDAO gitRepositoryDao;
  @Mocked
  private ODScanDAO odScanDao;
  @Mocked
  private OdProgramReportDAO odProgramReportDAO;


  @Before
  public void setup() {
    auditPt = new ProjectTeamRollup();

    projTeamList.add(MockTestDataUtil.createProjectTeamEntity());
    gitRepositoryList.add(MockTestDataUtil.createGitRepositoryEntity());
    sonarScanEntity = MockTestDataUtil.createSonarScanInfoEntity();
  }

  @Test
  public void rollUpAllPtsTest() throws Exception {

    new Expectations() {
      {
        projTeamDao.findAll();
        returns(projTeamList);

        gitRepositoryDao.findByPtId(anyLong);
        returns(gitRepositoryList);

        odScanDao.findLatestScanInfoForGitRepo(anyLong);
        returns(sonarScanEntity);
      }
    };
    Response response = auditPt.rollUpAllPts(ODPRGM_ID);
    assertNotNull(response);
    assertEquals((Status.OK.getStatusCode()), response.getStatus());

  }

  @Test
  public void rollUpSinglePtTest() throws Exception {

    new Expectations() {
      {

        projTeamDao.findById(anyLong);
        returns(projTeamList);

        gitRepositoryDao.findByPtId(anyLong);
        returns(gitRepositoryList);

        odScanDao.findLatestScanInfoForGitRepo(anyLong);
        returns(sonarScanEntity);

      }
    };
    Response response = auditPt.rollUpSinglePt(ODPRGM_ID, PT_ID);
    assertNotNull(response);
    assertEquals((Status.OK.getStatusCode()), response.getStatus());

  }

  @Test(expected = NullPointerException.class)
  public void rollUpAllPtsNullPrjListTest() throws Exception {
    new Expectations() {
      {
        projTeamList = null;
        projTeamDao.findAll();
        returns(projTeamList);
      }
    };
    auditPt.rollUpAllPts(ODPRGM_ID);
  }

  @Test
  public void rollUpAllPtsEmptyPrjListTest() throws Exception {
    new Expectations() {
      {
        projTeamList = new ArrayList<>();
        projTeamDao.findAll();
        returns(projTeamList);
      }
    };
    Response response = auditPt.rollUpAllPts(ODPRGM_ID);
    assertEquals((Status.NO_CONTENT.getStatusCode()), response.getStatus());
  }


  @Test
  public void rollUpAllPtsEmptyGitRepoEntityTest() throws Exception {

    new Expectations() {
      {
        projTeamDao.findAll();
        returns(projTeamList);

        gitRepositoryList = new ArrayList<>();
        gitRepositoryDao.findByPtId(anyLong);
        returns(gitRepositoryList);
      }
    };
    Response response = auditPt.rollUpAllPts(ODPRGM_ID);
    assertEquals((Status.NO_CONTENT.getStatusCode()), response.getStatus());
  }

  @Test(expected = IllegalArgumentException.class)
  public void rollUpAllPtsNegativeOrgIdTest() throws Exception {
    auditPt.rollUpAllPts(INVALID_ID);
  }

  @Test(expected = IllegalArgumentException.class)
  public void rollUpSinglePtNegativeOrgIdTest() throws Exception {
    auditPt.rollUpSinglePt(INVALID_ID, PT_ID);
  }

  @Test(expected = IllegalArgumentException.class)
  public void rollUpSinglePtNegativePrjIdTest() throws Exception {
    auditPt.rollUpSinglePt(ODPRGM_ID, INVALID_ID);
  }

  @Test
  public void rollUpSinglePtNullGitRepoEntityTest() throws Exception {

    new Expectations() {
      {
        projTeamDao.findById(anyLong);
        returns(projTeamList);

        gitRepositoryList = null;
        gitRepositoryDao.findByPtId(anyLong);
        returns(gitRepositoryList);
      }
    };
    Response response = auditPt.rollUpSinglePt(ODPRGM_ID, PT_ID);
    assertEquals((Status.NO_CONTENT.getStatusCode()), response.getStatus());
  }

  @Test
  public void rollUpSinglePtEmptyGitRepoEntityTest() throws Exception {

    new Expectations() {
      {
        projTeamDao.findById(anyLong);
        returns(projTeamList);

        gitRepositoryList = new ArrayList<>();
        gitRepositoryDao.findByPtId(anyLong);
        returns(gitRepositoryList);
      }
    };
    Response response = auditPt.rollUpSinglePt(ODPRGM_ID, PT_ID);
    assertEquals((Status.NO_CONTENT.getStatusCode()), response.getStatus());
  }
}
