/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.odaudit.service;

import static org.junit.Assert.assertEquals;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import org.junit.Before;
import org.junit.Test;

public class ProgramRollupIT {
 
  ProgramRollup auditPrgrm;

  @Before
  public void setup() {
    auditPrgrm = new ProgramRollup();
  }

  @Test
  public void rollUpAllPrgmsTest() throws Exception {
    Response response = auditPrgrm.rollUpAllPrgs();
    assertEquals(Status.OK.getStatusCode(), response.getStatus());

  }
}


