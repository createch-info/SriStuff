#
# Copyright (c) 2017, Travelport.
#

#
# As the 'root' MySQL user, run the following commands:
#
create database odaudit;
create user 'odaudit'@'localhost' identified by 'odaudit';
grant all privileges on odaudit . * to 'odaudit'@'localhost';
