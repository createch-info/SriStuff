#
# Copyright (c) 2017, Travelport.
#

#
# Table representing organization
#
CREATE TABLE IF NOT EXISTS organization (
	id BIGINT NOT NULL AUTO_INCREMENT,
	name VARCHAR(200) NOT NULL,
	is_deleted BOOLEAN NOT NULL,
	PRIMARY KEY (id)
);

#
# Table representing project team
#
CREATE TABLE IF NOT EXISTS project_team (
	id BIGINT NOT NULL AUTO_INCREMENT,
	organization_id BIGINT NOT NULL,
	name VARCHAR(200) NOT NULL,
	is_deleted BOOLEAN NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (organization_id) REFERENCES organization(id)
);

#
# Table representing gitbucket group
#
CREATE TABLE IF NOT EXISTS gb_group (
	id BIGINT NOT NULL AUTO_INCREMENT,
	project_team_id BIGINT NOT NULL,
	group_name VARCHAR(100) NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (project_team_id) REFERENCES project_team(id)
);

#
# Table representing git repository
#
CREATE TABLE IF NOT EXISTS git_repository (
	id BIGINT NOT NULL AUTO_INCREMENT,
	project_team_id BIGINT NOT NULL,
	project_key VARCHAR(100) NOT NULL,
	project_name VARCHAR(100),
	branch VARCHAR(100),
	repository_url VARCHAR(500) NOT NULL,
	repository_name VARCHAR(200) NOT NULL,
	repository_type VARCHAR(50) NOT NULL,
	is_deleted BOOLEAN NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (project_team_id) REFERENCES project_team(id)
);

#
# Reference table representing sonar thresholds
# This table should have only one record at any time
#
CREATE TABLE IF NOT EXISTS sonar_thresholds (
	id BIGINT NOT NULL AUTO_INCREMENT,
	is_active BOOLEAN NOT NULL,
	bugs_low FLOAT,
	bugs_high FLOAT,
	vulnerabilities_low FLOAT,
	vulnerabilities_high FLOAT,
	code_smells_low FLOAT,
	code_smells_high FLOAT,
	tech_debt_low FLOAT,
	tech_debt_high FLOAT,
	complexity_low FLOAT,
	complexity_high FLOAT,
	code_coverage_low FLOAT,
	code_coverage_high FLOAT,
	effective_date DATE,
	PRIMARY KEY (id)
);

INSERT INTO sonar_thresholds VALUES (1, true, 10, 20, 10, 20, 180, 480, 15, 50, 60, 80, CURDATE());

#
# Table representing common info for sonar scans
# Change to FLOAT
#
CREATE TABLE IF NOT EXISTS sonar_scan_info (
	id BIGINT NOT NULL AUTO_INCREMENT,
	bugs FLOAT,
	vulnerabilities FLOAT,
	tech_debt FLOAT,
	code_smells FLOAT,
	code_coverage FLOAT,
	complexity FLOAT,
	lines_of_code INT,
	PRIMARY KEY (id)
);

#
# Table representing common info for individual scan of any type
#
CREATE TABLE IF NOT EXISTS od_scan (
	id BIGINT NOT NULL AUTO_INCREMENT,
	git_repository_id BIGINT NOT NULL,
	scan_date TIMESTAMP NOT NULL,
	scan_type VARCHAR(50) NOT NULL,
	sonar_scan_info_id BIGINT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (git_repository_id) REFERENCES git_repository(id),
	FOREIGN KEY (sonar_scan_info_id) REFERENCES sonar_scan_info(id)
);

#
# Table representing sonar scan info rolled up to OD program level
#
CREATE TABLE IF NOT EXISTS od_program_report (
	id BIGINT NOT NULL AUTO_INCREMENT,
	sonar_scan_info_id BIGINT NOT NULL,
	od_report_date TIMESTAMP NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (sonar_scan_info_id) REFERENCES sonar_scan_info(id)
);

#
# Table representing a specific sonar scan against a git repository
#
CREATE TABLE IF NOT EXISTS repository_report (
	id BIGINT NOT NULL AUTO_INCREMENT,
	od_scan_id BIGINT NOT NULL,
	sonar_scan_info_id BIGINT NOT NULL,
	od_program_report_id BIGINT NOT NULL,
	sonar_qube_url VARCHAR(500),
	report_date TIMESTAMP NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (od_scan_id) REFERENCES od_scan(id),
	FOREIGN KEY (sonar_scan_info_id) REFERENCES sonar_scan_info(id),
	FOREIGN KEY (od_program_report_id) REFERENCES od_program_report(id)
);

#
# Table representing sonar scan info rolled up to project team level
#
CREATE TABLE IF NOT EXISTS project_team_report (
	id BIGINT NOT NULL AUTO_INCREMENT,
	project_team_id BIGINT NOT NULL,
	sonar_scan_info_id BIGINT NOT NULL,
	od_program_report_id BIGINT NOT NULL,
	pt_report_date TIMESTAMP NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (project_team_id) REFERENCES project_team(id),
	FOREIGN KEY (sonar_scan_info_id) REFERENCES sonar_scan_info(id),
	FOREIGN KEY (od_program_report_id) REFERENCES od_program_report(id)
);

#
# Table representing sonar scan info rolled up to org level
#
CREATE TABLE IF NOT EXISTS organization_report (
	id BIGINT NOT NULL AUTO_INCREMENT,
	organization_id BIGINT NOT NULL,
	sonar_scan_info_id BIGINT NOT NULL,
	od_program_report_id BIGINT NOT NULL,
	org_report_date TIMESTAMP NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (organization_id) REFERENCES organization(id),
	FOREIGN KEY (sonar_scan_info_id) REFERENCES sonar_scan_info(id),
	FOREIGN KEY (od_program_report_id) REFERENCES od_program_report(id)
);


CREATE TABLE IF NOT EXISTS hibernate_sequence (
	next_val BIGINT
);
INSERT INTO hibernate_sequence VALUES ( 1000 );

SOURCE create_views_odaudit.sql
