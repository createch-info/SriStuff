#
# Copyright (c) 2017, Travelport.
#

SOURCE drop_views_odaudit.sql
USE odaudit;
DROP TABLE repository_report;
DROP TABLE project_team_report;
DROP TABLE organization_report;
DROP TABLE od_program_report;
DROP TABLE od_scan;
DROP TABLE sonar_scan_info;
DROP TABLE sonar_thresholds;
DROP TABLE git_repository;
DROP TABLE gb_group;
DROP TABLE project_team;
DROP TABLE organization;
DROP TABLE hibernate_sequence;
