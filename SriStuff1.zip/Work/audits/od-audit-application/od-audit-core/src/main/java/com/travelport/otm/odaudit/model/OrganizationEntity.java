/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.Where;

/**
 * Represents a top-level organization for which OD Audit reports will be run.
 */
@NamedQueries({
    @NamedQuery(name = "organizationFindAll",
        query = "SELECT o FROM OrganizationEntity o WHERE o.deleted = FALSE ORDER BY o.name ASC"),
    @NamedQuery(name = "organizationFindByName",
        query = "SELECT o FROM OrganizationEntity o WHERE (o.deleted = FALSE) AND (o.name = :oName) ORDER BY o.name ASC"),
    @NamedQuery(name = "organizationFindById",
        query = "SELECT o FROM OrganizationEntity o WHERE (o.deleted = FALSE) AND (o.id = :oId)")})
@Entity
@Table(name = "organization")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "daoCache")
public class OrganizationEntity implements PersistentEntity {

  private static final long serialVersionUID = -2000255402701740938L;

  @Id
  @Column(name = "id", nullable = false)
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id = -1L;

  @NotNull
  @Size(min = 1, max = 200)
  @Column(name = "name", nullable = false, length = 200)
  private String name;

  @OneToMany(mappedBy = "organization", fetch = FetchType.LAZY, cascade = {CascadeType.REMOVE})
  @Where(clause = "is_deleted = false")
  @OrderBy("name ASC")
  @Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "collectionCache")
  private List<ProjectTeamEntity> projectTeams;

  @OneToMany(mappedBy = "organization", fetch = FetchType.LAZY, cascade = {CascadeType.REMOVE})
  @OrderBy("orgReportDate DESC")
  @Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "collectionCache")
  private List<OrganizationReportEntity> reports;

  @Column(name = "is_deleted")
  @Type(type = "org.hibernate.type.NumericBooleanType")
  private boolean deleted;

  /**
   * Returns the unique ID of this persistent entity.
   *
   * @return long
   */
  public long getId() {
    return id;
  }

  /**
   * Assigns the unique ID of this persistent entity.
   *
   * @param id the unique ID value to assign
   */
  public void setId(long id) {
    this.id = id;
  }

  /**
   * Returns the name of the organization.
   *
   * @return String
   */
  public String getName() {
    return name;
  }

  /**
   * Assigns the name of the organization.
   *
   * @param name the name value to assign
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Returns the list of project teams that are assigned to this organization.
   *
   * @return List<ProjectTeam>
   */
  public List<ProjectTeamEntity> getProjectTeams() {
    return projectTeams;
  }

  /**
   * Assigns the list of project teams that are assigned to this organization.
   *
   * @param projectTeams the field value to assign
   */
  public void setProjectTeams(List<ProjectTeamEntity> projectTeams) {
    this.projectTeams = projectTeams;
  }

  /**
   * Returns the list of reports for this organization.
   *
   * @return List<OrganizationReport>
   */
  public List<OrganizationReportEntity> getReports() {
    return reports;
  }

  /**
   * Assigns the list of reports for this organization.
   *
   * @param reports the list of reports to assign
   */
  public void setReports(List<OrganizationReportEntity> reports) {
    this.reports = reports;
  }

  /**
   * Returns the flag value indicating whether this organization has been deleted.
   *
   * @return boolean
   */
  public boolean isDeleted() {
    return deleted;
  }

  /**
   * Assigns the flag value indicating whether this organization has been deleted.
   *
   * @param deleted the boolean flag value to assign
   */
  public void setDeleted(boolean deleted) {
    this.deleted = deleted;
  }

}
