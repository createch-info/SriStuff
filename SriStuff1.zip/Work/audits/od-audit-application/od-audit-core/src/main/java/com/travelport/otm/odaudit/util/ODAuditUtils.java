/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.util;

import com.travelport.otm.odaudit.dao.DAOException;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;
import com.travelport.otm.odaudit.model.SonarThresholdsEntity;
import com.travelport.otm.odaudit.type.KPIType;
import com.travelport.otm.odaudit.type.SonarRating;

/**
 * Utility class that contains common audits core logic used across multiple DAOs
 */
public final class ODAuditUtils {

  /**
   * Private constructor to disable instantiation
   */
  private ODAuditUtils() {
    // hiding default constructor
  }

  /**
   * Returns Sonar KPI rating for a given KPI's scan value based on thresholds
   * 
   * @param KPIType: KPI type
   * @param SonarThresholdsEntity: Sonar threshold values
   * @param SonarScanInfoEntity: Sonar scan info values
   * @return SonarKPIRating
   * @throws DAOException
   * @throws None
   */
  public static SonarRating getKPIRating(KPIType kpi, SonarThresholdsEntity sonarThresholds,
      SonarScanInfoEntity scanInfo) {
    SonarRating rating = null;
    switch (kpi) {
      case SONAR_BUGS:
        rating = computeRating(kpi.isLowerIsBetter(), sonarThresholds.getBugsLow(),
            sonarThresholds.getBugsHigh(), scanInfo.getBugs());
        break;
      case SONAR_VULNERABILITIES:
        rating = computeRating(kpi.isLowerIsBetter(), sonarThresholds.getVulnerabilitiesLow(),
            sonarThresholds.getVulnerabilitiesHigh(), scanInfo.getVulnerabilities());
        break;
      case SONAR_TECH_DEBT:
        rating = computeRating(kpi.isLowerIsBetter(), sonarThresholds.getTechDebtLow(),
            sonarThresholds.getTechDebtHigh(), scanInfo.getTechDebt());
        break;
      case SONAR_CODE_SMELLS:
        rating = computeRating(kpi.isLowerIsBetter(), sonarThresholds.getCodeSmellsLow(),
            sonarThresholds.getCodeSmellsHigh(), scanInfo.getCodeSmells());
        break;
      case SONAR_COMPLEXITY:
        rating = computeRating(kpi.isLowerIsBetter(), sonarThresholds.getComplexityLow(),
            sonarThresholds.getComplexityHigh(), scanInfo.getComplexity());
        break;
      case SONAR_CODE_COVERAGE:
        rating = computeRating(kpi.isLowerIsBetter(), sonarThresholds.getCodeCoverageLow(),
            sonarThresholds.getCodeCoverageHigh(), scanInfo.getCodeCoverage());
        break;
      default:
        break;
    }
    return rating;
  }

  /**
   * Returns Sonar KPI rating for a given KPI's scan value based on thresholds
   * 
   * @param boolean: lowerIsBetter
   * @param Float: low - low limit for the KPI
   * @param Float: high - high limit for the KPI
   * @param Float: value - value of the KPI from scan
   * @return SonarRating
   * @throws DAOException
   * @throws None
   */
  public static SonarRating computeRating(boolean lowerIsBetter, float low, float high,
      Float value) {

    SonarRating rating = null;
    if (null == value) {
      rating = SonarRating.RED;
      return rating;
    }

    int compareLow = value.compareTo(low);
    int compareHigh = value.compareTo(high);
    if (lowerIsBetter) {
      if (compareLow < 0) {
        rating = SonarRating.GREEN;
      } else if (compareLow >= 0 && compareHigh <= 0) {
        rating = SonarRating.YELLOW;
      } else if (compareHigh > 0) {
        rating = SonarRating.RED;
      }
    } else {
      if (compareLow < 0) {
        rating = SonarRating.RED;
      } else if (compareLow >= 0 && compareHigh <= 0) {
        rating = SonarRating.YELLOW;
      } else if (compareHigh > 0) {
        rating = SonarRating.GREEN;
      }
    }

    return rating;
  }
}
