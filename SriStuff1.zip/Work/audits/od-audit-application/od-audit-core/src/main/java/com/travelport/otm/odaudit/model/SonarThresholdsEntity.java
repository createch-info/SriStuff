/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Type;

/**
 * Reference table for storing sonar thresholds This table should have only one record at any time
 */
@NamedQueries({
    @NamedQuery(name = "fetchActiveSonarThresholds",
        query = "SELECT st FROM SonarThresholdsEntity st WHERE (st.isActive = TRUE)"),
    @NamedQuery(name = "fetchAllSonarThresholds",
        query = "SELECT st FROM SonarThresholdsEntity st ORDER BY st.effectiveDate DESC"),
    @NamedQuery(name = "fetchSonarThresholdsForDate",
        query = "SELECT st FROM SonarThresholdsEntity st WHERE st.effectiveDate <= :effDate ORDER BY st.effectiveDate DESC")})
@Entity
@Table(name = "sonar_thresholds")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "daoCache")
public class SonarThresholdsEntity implements PersistentEntity {

  private static final long serialVersionUID = 201711141127L;

  @Id
  @Column(name = "id", nullable = false)
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id = -1L;

  @NotNull
  @Column(name = "is_active", nullable = false)
  @Type(type = "org.hibernate.type.NumericBooleanType")
  private boolean isActive;

  @Column(name = "bugs_low")
  private float bugsLow;

  @Column(name = "bugs_high")
  private float bugsHigh;

  @Column(name = "vulnerabilities_low")
  private float vulnerabilitiesLow;

  @Column(name = "vulnerabilities_high")
  private float vulnerabilitiesHigh;

  @Column(name = "code_smells_low")
  private float codeSmellsLow;

  @Column(name = "code_smells_high")
  private float codeSmellsHigh;

  @Column(name = "tech_debt_low")
  private float techDebtLow;

  @Column(name = "tech_debt_high")
  private float techDebtHigh;

  @Column(name = "complexity_low")
  private float complexityLow;

  @Column(name = "complexity_high")
  private float complexityHigh;

  @Column(name = "code_coverage_low")
  private float codeCoverageLow;

  @Column(name = "code_coverage_high")
  private float codeCoverageHigh;

  @NotNull
  @Column(name = "effective_date", nullable = false)
  private Date effectiveDate;

  /**
   * Returns the unique ID of this persistent entity.
   *
   * @return long
   */
  @Override
  public long getId() {
    return id;
  }

  /**
   * Returns active flag for sonar thresholds
   *
   * @return boolean
   */
  public boolean isActive() {
    return isActive;
  }

  /**
   * Assigns active flag for sonar thresholds
   *
   * @param flag value to assign (true/false)
   */
  public void setActive(boolean isActive) {
    this.isActive = isActive;
  }

  /**
   * Returns low threshold value for bugs
   *
   * @return float
   */
  public float getBugsLow() {
    return bugsLow;
  }

  /**
   * Assigns low threshold value for bugs
   *
   * @param low threshold value to assign
   */
  public void setBugsLow(float bugsLow) {
    this.bugsLow = bugsLow;
  }

  /**
   * Returns high threshold value for bugs
   *
   * @return float
   */
  public float getBugsHigh() {
    return bugsHigh;
  }

  /**
   * Assigns high threshold value for bugs
   *
   * @param high threshold value to assign
   */
  public void setBugsHigh(float bugsHigh) {
    this.bugsHigh = bugsHigh;
  }

  /**
   * Returns low threshold for vulnerabilities
   *
   * @return float
   */
  public float getVulnerabilitiesLow() {
    return vulnerabilitiesLow;
  }

  /**
   * Assigns low threshold for vulnerabilities
   *
   * @param low threshold value to assign
   */
  public void setVulnerabilitiesLow(float vulnerabilitiesLow) {
    this.vulnerabilitiesLow = vulnerabilitiesLow;
  }

  /**
   * Returns high threshold for vulnerabilities
   *
   * @return float
   */
  public float getVulnerabilitiesHigh() {
    return vulnerabilitiesHigh;
  }

  /**
   * Assigns high threshold for vulnerabilities
   *
   * @param high threshold value to assign
   */
  public void setVulnerabilitiesHigh(float vulnerabilitiesHigh) {
    this.vulnerabilitiesHigh = vulnerabilitiesHigh;
  }

  /**
   * Returns low threshold for code smells
   *
   * @return float
   */
  public float getCodeSmellsLow() {
    return codeSmellsLow;
  }

  /**
   * Assigns low threshold for code smells
   *
   * @param low threshold value to assign
   */
  public void setCodeSmellsLow(float codeSmellsLow) {
    this.codeSmellsLow = codeSmellsLow;
  }

  /**
   * Returns high threshold for code smells
   *
   * @return float
   */
  public float getCodeSmellsHigh() {
    return codeSmellsHigh;
  }

  /**
   * Assigns high threshold for code smells
   *
   * @param high threshold value to assign
   */
  public void setCodeSmellsHigh(float codeSmellsHigh) {
    this.codeSmellsHigh = codeSmellsHigh;
  }

  /**
   * Returns low threshold for technical debt in mins
   *
   * @return float
   */
  public float getTechDebtLow() {
    return techDebtLow;
  }

  /**
   * Assigns low threshold for technical debt in mins
   *
   * @param low threshold value to assign
   */
  public void setTechDebtLow(float techDebtLow) {
    this.techDebtLow = techDebtLow;
  }

  /**
   * Returns high threshold for technical debt in mins
   *
   * @return float
   */
  public float getTechDebtHigh() {
    return techDebtHigh;
  }

  /**
   * Assigns high threshold for technical debt in mins
   *
   * @param high threshold value to assign
   */
  public void setTechDebtHigh(float techDebtHigh) {
    this.techDebtHigh = techDebtHigh;
  }

  /**
   * Returns low threshold for complexity
   *
   * @return float
   */
  public float getComplexityLow() {
    return complexityLow;
  }

  /**
   * Assigns low threshold for complexity
   *
   * @param low threshold value to assign
   */
  public void setComplexityLow(float complexityLow) {
    this.complexityLow = complexityLow;
  }

  /**
   * Returns high threshold for complexity
   *
   * @return float
   */
  public float getComplexityHigh() {
    return complexityHigh;
  }

  /**
   * Assigns high threshold for complexity
   *
   * @param high threshold value to assign
   */
  public void setComplexityHigh(float complexityHigh) {
    this.complexityHigh = complexityHigh;
  }

  /**
   * Returns low threshold for code coverage %
   *
   * @return float
   */
  public float getCodeCoverageLow() {
    return codeCoverageLow;
  }

  /**
   * Assigns low threshold for code coverage %
   *
   * @param low threshold value to assign
   */
  public void setCodeCoverageLow(float codeCoverageLow) {
    this.codeCoverageLow = codeCoverageLow;
  }

  /**
   * Returns high threshold for code coverage %
   *
   * @return float
   */
  public float getCodeCoverageHigh() {
    return codeCoverageHigh;
  }

  /**
   * Assigns high threshold for code coverage %
   *
   * @param high threshold value to assign
   */
  public void setCodeCoverageHigh(float codeCoverageHigh) {
    this.codeCoverageHigh = codeCoverageHigh;
  }

  /**
   * Returns effective date for sonar thresholds
   *
   * @return java.time.LocalDate
   */
  public Date getEffectiveDate() {
    return effectiveDate;
  }

  /**
   * Assigns effective date for thresholds
   *
   * @param effective date to assign
   */
  public void setEffectiveDate(Date effectiveDate) {
    this.effectiveDate = effectiveDate;
  }
}
