/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.type;

/**
 * Indicates the type of a Git repository for reporting purposes.
 */
public enum RepositoryType {

  /** A repository that contains production-deployable code. */
  PRODUCTION,

  /** An OTM model-jar production code repository. */
  MODEL_JAR,

  /** A repository that contains only test code. */
  TEST,

  /** A repository that should be ignored during OD Audit reporting. */
  IGNORE;

}
