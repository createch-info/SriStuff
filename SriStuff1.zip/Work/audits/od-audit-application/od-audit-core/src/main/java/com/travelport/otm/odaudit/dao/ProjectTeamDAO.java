/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import java.util.List;
import javax.persistence.TypedQuery;
import com.travelport.otm.odaudit.model.ProjectTeamEntity;

/**
 * DAO that provides operations related to the creation, retrieval, and management of
 * <code>ProjectTeam</code> entities.
 */
public class ProjectTeamDAO extends AbstractDAO<ProjectTeamEntity> {

  /**
   * Constructor that supplies the factory which created this DAO instance.
   * 
   * @param factory the factory that created this DAO
   */
  ProjectTeamDAO(DAOFactory factory) {
    super(factory);
  }

  /**
   * @see com.travelport.otm.odaudit.dao.AbstractDAO#getEntityType()
   */
  @Override
  protected Class<ProjectTeamEntity> getEntityType() {
    return ProjectTeamEntity.class;
  }

  /**
   * Returns all project teams or null if no team exists.
   * 
   * @param None
   * @return List<ProjectTeam>
   * @throws DAOException thrown if an error occurs while retrieving the project team
   */
  public List<ProjectTeamEntity> findAll() {

    TypedQuery<ProjectTeamEntity> query =
        getEntityManager().createNamedQuery("projectTeamFindAll", ProjectTeamEntity.class);
    return query.getResultList();
  }

  /**
   * Returns the project team with the specified name and owner or null if no such team exists.
   * 
   * @param orgId the ID of the organization to which the team belongs
   * @param teamName the name of the project team to retrieve
   * @return ProjectTeam
   * @throws None
   */
  public ProjectTeamEntity findByName(long orgId, String teamName) {
    TypedQuery<ProjectTeamEntity> query =
        getEntityManager().createNamedQuery("projectTeamFindByName", ProjectTeamEntity.class);
    List<ProjectTeamEntity> teamList;
    ProjectTeamEntity team = null;

    query.setParameter("tOrgId", orgId);
    query.setParameter("tName", teamName);
    teamList = query.getResultList();

    if (!teamList.isEmpty()) {
      team = teamList.get(0);
    }
    return team;
  }


  /**
   * Returns the project team with the specified name and owner or null if no such team exists.
   * 
   * @param orgId the ID of the organization to which the team belongs
   * @return List<ProjectTeam>
   * @throws None
   */
  public List<ProjectTeamEntity> findByOrgId(long orgId) {
    TypedQuery<ProjectTeamEntity> query =
        getEntityManager().createNamedQuery("projectTeamFindByOrgId", ProjectTeamEntity.class);
    List<ProjectTeamEntity> teamList;
    query.setParameter("tOrgId", orgId);
    teamList = query.getResultList();

    return teamList;
  }



  /**
   * Returns the project team with the specified id
   * 
   * @param ptId: Id of the project team to retrieve
   * @return ProjectTeam>
   * @throws None
   */
  public ProjectTeamEntity findById(long ptId) {
    TypedQuery<ProjectTeamEntity> query =
        getEntityManager().createNamedQuery("projectTeamFindById", ProjectTeamEntity.class);

    query.setParameter("tId", ptId);
    return query.getSingleResult();
  }

  /**
   * @see com.travelport.otm.odaudit.dao.AbstractDAO#delete(com.travelport.otm.odaudit.model.PersistentEntity)
   */
  @Override
  public void delete(ProjectTeamEntity entity) {
    entity.setDeleted(true);
    getEntityManager().merge(entity);
    DAOFactory.invalidateCollectionCache();
  }

  /**
   * @see com.travelport.otm.odaudit.dao.AbstractDAO#checkForDuplicate(com.travelport.otm.odaudit.model.PersistentEntity)
   */
  @Override
  protected void checkForDuplicate(ProjectTeamEntity team) throws DAOException {
    if ((team != null) && (team.getOrganization() != null)) {
      ProjectTeamEntity otherTeam = findByName(team.getOrganization().getId(), team.getName());
      boolean isDuplicate;

      if (team.getId() < 0) { // create
        isDuplicate = (otherTeam != null);

      } else { // update
        isDuplicate = (otherTeam != null) && (team.getId() != otherTeam.getId());
      }
      if (isDuplicate) {
        throw new DAOException("A project team with the name '" + team.getName()
            + "' already exists in this organization.");
      }
    }
  }

}
