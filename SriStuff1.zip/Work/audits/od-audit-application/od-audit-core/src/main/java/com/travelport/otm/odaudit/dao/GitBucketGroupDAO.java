/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import com.travelport.otm.odaudit.model.GitBucketGroupEntity;

/**
 * DAO that provides operations related to the creation, retrieval, and management of
 * <code>GitBucketGroup</code> entities.
 */
public class GitBucketGroupDAO extends AbstractDAO<GitBucketGroupEntity> {

  /**
   * Constructor that supplies the factory which created this DAO instance.
   * 
   * @param factory the factory that created this DAO
   */
  GitBucketGroupDAO(DAOFactory factory) {
    super(factory);
  }

  /**
   * @see com.travelport.otm.odaudit.dao.AbstractDAO#getEntityType()
   */
  @Override
  protected Class<GitBucketGroupEntity> getEntityType() {
    return GitBucketGroupEntity.class;
  }

  /**
   * Returns the GitBucket group with the specified name and owner or null if no such group exists.
   * 
   * @param teamId the ID of the group to which the team belongs
   * @param groupName the name of the group to retrieve
   * @return List<GitBucketGroup>
   * @throws DAOException thrown if an error occurs while retrieving the group
   */
  public GitBucketGroupEntity findByGroupName(long teamId, String groupName) {
    TypedQuery<GitBucketGroupEntity> query =
        getEntityManager().createNamedQuery("gitBucketGroupFindByName", GitBucketGroupEntity.class);
    List<GitBucketGroupEntity> groupList;
    GitBucketGroupEntity group = null;

    query.setParameter("gTeamId", teamId);
    query.setParameter("gName", groupName);
    groupList = query.getResultList();

    if (!groupList.isEmpty()) {
      group = groupList.get(0);
    }
    return group;
  }

  /**
   * @see com.travelport.otm.odaudit.dao.AbstractDAO#checkForDuplicate(com.travelport.otm.odaudit.model.PersistentEntity)
   */
  @Override
  protected void checkForDuplicate(GitBucketGroupEntity group) throws DAOException {
    if ((group != null) && (group.getProjectTeam() != null)) {
      GitBucketGroupEntity otherGroup =
          findByGroupName(group.getProjectTeam().getId(), group.getGroupName());
      boolean isDuplicate;

      if (group.getId() < 0) { // create
        isDuplicate = (otherGroup != null);

      } else { // update
        isDuplicate = (otherGroup != null) && (group.getId() != otherGroup.getId());
      }
      if (isDuplicate) {
        throw new DAOException("A GitBucket group with the name '" + group.getGroupName()
            + "' already exists in this project team.");
      }
    }
  }

}
