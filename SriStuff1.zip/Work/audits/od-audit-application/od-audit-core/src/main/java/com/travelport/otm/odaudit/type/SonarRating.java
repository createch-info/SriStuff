/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.type;

public enum SonarRating {
	GREEN("Green"), YELLOW("Yellow"), RED("Red");

	private String rating;

	private SonarRating(String rating) {
		this.rating = rating;
	}

	public String getRating() {
		return rating;
	}
}
