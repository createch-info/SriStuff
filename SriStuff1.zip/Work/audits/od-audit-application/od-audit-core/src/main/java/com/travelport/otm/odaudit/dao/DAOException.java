/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

/**
 * Exception thrown when an error occurs during DAO processing.
 */
public class DAOException extends Exception {

	private static final long serialVersionUID = -5851709057378908824L;

	/**
	 * Default constructor.
	 */
	public DAOException() {
	}

	/**
	 * Constructs an exception with the specified message.
	 * 
	 * @param message
	 *            the exception message
	 */
	public DAOException(String message) {
		super(message);
	}

	/**
	 * Constructs an exception with the specified underlying cause.
	 * 
	 * @param cause
	 *            the underlying exception that caused this one
	 */
	public DAOException(Throwable cause) {
		super(cause);
	}

	/**
	 * Constructs an exception with the specified message and underlying cause.
	 * 
	 * @param message
	 *            the exception message
	 * @param cause
	 *            the underlying exception that caused this one
	 */
	public DAOException(String message, Throwable cause) {
		super(message, cause);
	}

}
