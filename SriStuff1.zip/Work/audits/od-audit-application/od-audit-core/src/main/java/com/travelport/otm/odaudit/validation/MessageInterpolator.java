/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.validation;

import java.util.Locale;
import java.util.ResourceBundle;

import org.hibernate.validator.messageinterpolation.ResourceBundleMessageInterpolator;
import org.hibernate.validator.spi.resourceloading.ResourceBundleLocator;

/**
 * Custom interpolator used for the formatting of bean validation messages.
 */
public class MessageInterpolator extends ResourceBundleMessageInterpolator {

  public static final String MESSAGE_BUNDLE_LOCATION =
      "com.travelport.otm.odaudit.odaudit-messages";

  /**
   * Default constructor.
   */
  public MessageInterpolator() {
    super(new ResourceBundleLocator() {
      public ResourceBundle getResourceBundle(Locale locale) {
        return ResourceBundle.getBundle(MESSAGE_BUNDLE_LOCATION, locale);
      }
    });
  }

}
