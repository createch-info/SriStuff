/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.util;

import java.sql.Date;

import com.travelport.otm.odaudit.dao.DAOException;
import com.travelport.otm.odaudit.dao.DAOFactory;
import com.travelport.otm.odaudit.dao.SonarScanInfoDAO;
import com.travelport.otm.odaudit.dao.SonarThresholdsDAO;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;
import com.travelport.otm.odaudit.model.SonarThresholdsEntity;

public final class RatingsUtils {
  private RatingsUtils() {}


  public static SonarThresholdsEntity getSonarThresholdsEntity(Date reportDate)
      throws DAOException {
    // Fetch the effective SONAR_THRESHOLDS record for report_date
    DAOFactory daoFactory = new DAOFactory();
    SonarThresholdsDAO sonarThrDao = daoFactory.newSonarThresholdsDAO();
    SonarThresholdsEntity sonarThresholds = sonarThrDao.fetchSonarThresholdsForEffDate(reportDate);
    if (sonarThresholds == null) {
      throw new DAOException("No SONAR_THRESHOLDS record found for date: " + reportDate);
    } else {
      return sonarThresholds;
    }
  }


  public static SonarScanInfoEntity getSonarScanInfoEntity(long sonarScanInfoId)
      throws DAOException {
    // Fetch Sonar KPIs for repository report from SONAR_SCAN_INFO
    DAOFactory daoFactory = new DAOFactory();
    SonarScanInfoDAO scanDao = daoFactory.newSonarScanInfoDAO();
    SonarScanInfoEntity scanInfo = scanDao.get(sonarScanInfoId);
    if (scanInfo == null) {
      throw new DAOException("Sonar_Scan_Info record not found for id: " + sonarScanInfoId);
    } else {
      return scanInfo;
    }
  }

}
