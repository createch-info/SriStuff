/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import java.sql.Date;
import java.util.EnumSet;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.TypedQuery;

import com.travelport.otm.odaudit.model.KPIRating;
import com.travelport.otm.odaudit.model.ProjectTeamReportEntity;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;
import com.travelport.otm.odaudit.model.SonarThresholdsEntity;
import com.travelport.otm.odaudit.type.KPIType;
import com.travelport.otm.odaudit.util.ODAuditUtils;
import com.travelport.otm.odaudit.util.RatingsUtils;

/**
 * DAO that provides operations related to the creation, retrieval, and management of
 * <code>ProjectTeamReport</code> entities.
 */
public class ProjectTeamReportDAO extends AbstractDAO<ProjectTeamReportEntity> {

  /**
   * Constructor that supplies the factory which created this DAO instance.
   * 
   * @param factory that created this DAO
   */
  ProjectTeamReportDAO(DAOFactory factory) {
    super(factory);
  }

  /**
   * @see com.travelport.otm.odaudit.dao.AbstractDAO#getEntityType()
   */
  @Override
  protected Class<ProjectTeamReportEntity> getEntityType() {
    return ProjectTeamReportEntity.class;
  }

  /**
   * Returns a list of project team reports for a given project team name
   * 
   * @param ptName project team name to match
   * @return List<ProjectTeamReport>
   * @throws DAOException thrown if an error occurs
   */
  public List<ProjectTeamReportEntity> findByPtName(String ptName) {
    TypedQuery<ProjectTeamReportEntity> query =
        getEntityManager().createNamedQuery("ptReportFindByName", ProjectTeamReportEntity.class);

    query.setParameter("ptName", ptName);
    return query.getResultList();
  }

  /**
   * Returns project team report record for a given project_team_report_id with ratings computed
   * 
   * @param projectTeamReportId: the ID of the project_team report
   * @return ProjectTeamReportEntity
   * @throws DAOException
   */
  public ProjectTeamReportEntity getProjectTeamRatings(long projectTeamReportId)
      throws DAOException {

    // Fetch repository_report record for the id passed in
    ProjectTeamReportEntity projectTeamReport = get(projectTeamReportId);
    if (projectTeamReport == null) {
      throw new DAOException("Repository report not found for id passed: " + projectTeamReportId);
    }

    long sonarScanInfoId = projectTeamReport.getSonarScanInfo().getId();
    Date reportDate = new Date(projectTeamReport.getPtReportDate().getTime());

    SonarThresholdsEntity sonarThresholds = RatingsUtils.getSonarThresholdsEntity(reportDate);
    SonarScanInfoEntity scanInfo = RatingsUtils.getSonarScanInfoEntity(sonarScanInfoId);

    // Compute ratings
    List<KPIRating> kpiRatings =
        EnumSet.allOf(KPIType.class).stream().filter(e -> e.isLowerIsBetter() != null)
            .map(e -> new KPIRating(e, ODAuditUtils.getKPIRating(e, sonarThresholds, scanInfo)))
            .collect(Collectors.toList());

    projectTeamReport.setKpiRatings(kpiRatings);
    return projectTeamReport;
  }

  /**
   * Delete operation is not supported for project_team_report
   * 
   * @param entity: the entity to be deleted
   * @throws none
   */
  @Override
  public void delete(ProjectTeamReportEntity report) {
    throw new UnsupportedOperationException("delete");
  }
}
