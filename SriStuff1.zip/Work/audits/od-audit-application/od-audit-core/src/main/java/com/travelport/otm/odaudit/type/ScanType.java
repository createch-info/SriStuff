/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.type;

/**
 * Represents scan types for OD audits
 */
public enum ScanType {

  /** SonarQube scan */
  SONAR,

  /** Fortify scan */
  FORTIFY;
}
