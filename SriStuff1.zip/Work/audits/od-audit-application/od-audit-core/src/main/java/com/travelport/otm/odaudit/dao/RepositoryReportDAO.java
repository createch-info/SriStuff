/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import java.sql.Date;
import java.util.EnumSet;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.TypedQuery;

import com.travelport.otm.odaudit.model.KPIRating;
import com.travelport.otm.odaudit.model.RepositoryReportEntity;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;
import com.travelport.otm.odaudit.model.SonarThresholdsEntity;
import com.travelport.otm.odaudit.type.KPIType;
import com.travelport.otm.odaudit.util.ODAuditUtils;
import com.travelport.otm.odaudit.util.RatingsUtils;

/**
 * DAO that provides operations related to the creation, retrieval, and management of
 * <code>RepositoryReport</code> entities.
 */
public class RepositoryReportDAO extends AbstractDAO<RepositoryReportEntity> {

  /**
   * Constructor that supplies the factory which created this DAO instance.
   * 
   * @param factory that created this DAO
   */
  RepositoryReportDAO(DAOFactory factory) {
    super(factory);
  }

  /**
   * @see com.travelport.otm.odaudit.dao.AbstractDAO#getEntityType()
   */
  @Override
  protected Class<RepositoryReportEntity> getEntityType() {
    return RepositoryReportEntity.class;
  }

  /**
   * Returns a list of repository reports for a given git URL and branch name
   * 
   * @param gitUrl: git URL
   * @param branch: branch name
   * @return List<RepositoryReport>
   * @throws None
   */
  public List<RepositoryReportEntity> findByGitUrlAndBranch(String gitUrl, String branch) {
    TypedQuery<RepositoryReportEntity> query =
        getEntityManager().createNamedQuery("findByGitUrlAndBranch", RepositoryReportEntity.class);

    query.setParameter("gitUrl", gitUrl);
    query.setParameter("branch", branch);

    return query.getResultList();
  }

  /**
   * Returns repository report record for a given repository_report_id with ratings computed
   * 
   * @param repoReportId: the ID of the repository report
   * @return RepositoryReportEntity
   * @throws DAOException
   */
  public RepositoryReportEntity getRepoRatings(long repoReportId) throws DAOException {

    // Fetch repository_report record for the id passed in
    RepositoryReportEntity repoReport = get(repoReportId);
    if (repoReport == null) {
      throw new DAOException("Repository report not found for id passed: " + repoReportId);
    }

    long sonarScanInfoId = repoReport.getSonarScanInfo().getId();
    Date reportDate = new Date(repoReport.getReportDate().getTime());

    SonarThresholdsEntity sonarThresholds = RatingsUtils.getSonarThresholdsEntity(reportDate);
    SonarScanInfoEntity scanInfo = RatingsUtils.getSonarScanInfoEntity(sonarScanInfoId);

    // Compute ratings
    List<KPIRating> kpiRatings =
        EnumSet.allOf(KPIType.class).stream().filter(e -> e.isLowerIsBetter() != null)
            .map(e -> new KPIRating(e, ODAuditUtils.getKPIRating(e, sonarThresholds, scanInfo)))
            .collect(Collectors.toList());

    repoReport.setKpiRatings(kpiRatings);
    return repoReport;
  }

  /**
   * Delete operation is not supported for repository_report
   * 
   * @param entity: the entity to be deleted
   * @throws none
   */
  @Override
  public void delete(RepositoryReportEntity report) {
    throw new UnsupportedOperationException("delete");
  }
}
