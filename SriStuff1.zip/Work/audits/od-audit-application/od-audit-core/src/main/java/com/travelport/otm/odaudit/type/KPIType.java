/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.type;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import com.travelport.otm.odaudit.KPIConstants;
import com.travelport.otm.odaudit.model.OdProgramReportEntity;
import com.travelport.otm.odaudit.model.OrganizationReportEntity;
import com.travelport.otm.odaudit.model.ProjectTeamReportEntity;
import com.travelport.otm.odaudit.model.RepositoryReportEntity;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;

/**
 * Enumeration of the supported KPI types, as well as supporting methods that can be used to
 * retrieve the corresponding values from the OD report entities.
 */
public enum KPIType {


// @formatter:off
  SONAR_BUGS("bugs", KPIConstants.DEAFULT_FORMAT, true), 
  SONAR_VULNERABILITIES("vulnerabilities", KPIConstants.DEAFULT_FORMAT, true), 
  SONAR_TECH_DEBT("sqale_index", KPIConstants.DEAFULT_FORMAT, true), 
  SONAR_CODE_COVERAGE("coverage", KPIConstants.PERCENT_FINAL, false), 
  SONAR_COMPLEXITY("complexity", KPIConstants.DEAFULT_FORMAT, true), 
  SONAR_CODE_SMELLS("code_smells", KPIConstants.DEAFULT_FORMAT, true), 
  SONAR_LINES_OF_CODE("ncloc", KPIConstants.INT_FORMAT, null);
// @formatter:on 

  private String metric;
  private DecimalFormat format;
  private Boolean lowerIsBetter;

  /**
   * Constructor that specifies the decimal format to use for display output.
   * 
   * @param format the display format of the KPI value
   */
  private KPIType(String metric, DecimalFormat format, Boolean lowerIsBetter) {
    this.metric = metric;
    this.format = format;
    this.lowerIsBetter = lowerIsBetter;
  }

  /**
   * Returns the list of KPI's that are currently supported. Depending upon the state of the code,
   * this may be less than the total number of KPI types that are defined in this enumeration.
   * 
   * @return
   */
  public static KPIType[] getSupportedKpis() {
    return KPIType.values();
  }

  /**
   * Returns a displayable value for a KPI from the given report object instance.
   * 
   * @param reportObj the report object from which to extract the KPI
   * @return String
   */
  public String getProgramDisplayValue(OdProgramReportEntity reportObj) {
    return getDisplayValue(reportObj);
  }

  /**
   * Returns a displayable value for a KPI from the given report object instance.
   * 
   * @param reportObj the report object from which to extract the KPI
   * @return String
   */
  public String getOrganizationDisplayValue(OrganizationReportEntity reportObj) {
    return getDisplayValue(reportObj);
  }

  /**
   * Returns a displayable value for a KPI from the given report object instance.
   * 
   * @param reportObj the report object from which to extract the KPI
   * @return String
   */
  public String getProjectTeamDisplayValue(ProjectTeamReportEntity reportObj) {
    return getDisplayValue(reportObj);
  }

  /**
   * Returns a displayable value for a KPI from the given report object instance.
   * 
   * @param reportObj the report object from which to extract the KPI
   * @return String
   */
  public String getRepositoryDisplayValue(RepositoryReportEntity reportObj) {
    return getDisplayValue(reportObj);
  }

  /**
   * Returns metric
   * 
   * @param N/A
   * @return String
   */
  public String getMetric() {
    return metric;
  }

  /**
   * Returns LowerIsBetter
   * 
   * @param N/A
   * @return boolean
   */
  public Boolean isLowerIsBetter() {
    return lowerIsBetter;
  }

  /**
   * Returns the value for a given metric string
   * 
   * @param metricStr Metric string
   * @return KPIType
   */
  public static KPIType getMetricFromString(String metricStr) {
    for (KPIType m : KPIType.values()) {
      if (m.metric.equalsIgnoreCase(metricStr)) {
        return m;
      }
    }
    return null;
  }

  /**
   * Returns a comma-separated list of metric strings
   * 
   * @param metricStr Metric string
   * @return KPIType
   */
  public static String getStringFromMetrics() {

    List<String> metricList = new ArrayList<>();
    for (KPIType m : KPIType.values()) {
      metricList.add(m.getMetric());
    }
    return String.join(",", metricList);
  }

  /**
   * Returns a displayable value for a KPI from the given report object instance.
   * 
   * @param reportObj the report object from which to extract the KPI
   * @return String
   */
  private String getDisplayValue(Object reportObj) {
    Object kpiContainer = getKPIContainer(reportObj);
    Float kpiValue = null;

    if (kpiContainer != null) {
      switch (this) {
        case SONAR_BUGS:
          kpiValue = ((SonarScanInfoEntity) kpiContainer).getBugs();
          break;
        case SONAR_CODE_COVERAGE:
          kpiValue = ((SonarScanInfoEntity) kpiContainer).getCodeCoverage();
          break;
        case SONAR_CODE_SMELLS:
          kpiValue = ((SonarScanInfoEntity) kpiContainer).getCodeSmells();
          break;
        case SONAR_COMPLEXITY:
          kpiValue = ((SonarScanInfoEntity) kpiContainer).getComplexity();
          break;
        case SONAR_LINES_OF_CODE:
          kpiValue = (float) ((SonarScanInfoEntity) kpiContainer).getLinesOfCode();
          break;
        case SONAR_TECH_DEBT:
          kpiValue = ((SonarScanInfoEntity) kpiContainer).getTechDebt();
          break;
        case SONAR_VULNERABILITIES:
          kpiValue = ((SonarScanInfoEntity) kpiContainer).getVulnerabilities();
          break;
      }
    }
    return (kpiValue == null) ? null : format.format(kpiValue);
  }

  /**
   * Returns the constituent object of the given report from which the KPI value can be extracted.
   * 
   * @param reportObj the report object from which the KPI value can be extracted
   * @return Object
   */
  private Object getKPIContainer(Object reportObj) {
    Object kpiContainer = null;

    switch (this) {
      case SONAR_BUGS:
      case SONAR_CODE_COVERAGE:
      case SONAR_CODE_SMELLS:
      case SONAR_COMPLEXITY:
      case SONAR_LINES_OF_CODE:
      case SONAR_TECH_DEBT:
      case SONAR_VULNERABILITIES:
        if (reportObj instanceof OdProgramReportEntity) {
          kpiContainer = ((OdProgramReportEntity) reportObj).getSonarScanInfo();

        } else if (reportObj instanceof OrganizationReportEntity) {
          kpiContainer = ((OrganizationReportEntity) reportObj).getSonarScanInfo();

        } else if (reportObj instanceof ProjectTeamReportEntity) {
          kpiContainer = ((ProjectTeamReportEntity) reportObj).getSonarScanInfo();

        } else if (reportObj instanceof RepositoryReportEntity) {
          kpiContainer = ((RepositoryReportEntity) reportObj).getSonarScanInfo();
        }
        break;
    }
    return kpiContainer;
  }

}
