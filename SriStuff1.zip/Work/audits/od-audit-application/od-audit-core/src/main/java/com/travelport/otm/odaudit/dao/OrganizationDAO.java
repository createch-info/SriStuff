/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import com.travelport.otm.odaudit.model.OrganizationEntity;

/**
 * DAO that provides operations related to the creation, retrieval, and management of
 * <code>Organization</code> entities.
 */
public class OrganizationDAO extends AbstractDAO<OrganizationEntity> {

  /**
   * Constructor that supplies the factory which created this DAO instance.
   * 
   * @param factory that created this DAO
   */
  OrganizationDAO(DAOFactory factory) {
    super(factory);
  }

  /**
   * @see com.travelport.otm.odaudit.dao.AbstractDAO#getEntityType()
   */
  @Override
  protected Class<OrganizationEntity> getEntityType() {
    return OrganizationEntity.class;
  }

  /**
   * Returns a list of all organizations.
   * 
   * @return List<Organization>
   * @throws DAOException thrown if an error occurs while retrieving the organizations
   */
  public List<OrganizationEntity> getAll() throws DAOException {
    TypedQuery<OrganizationEntity> query =
        getEntityManager().createNamedQuery("organizationFindAll", OrganizationEntity.class);

    return query.getResultList();
  }

  /**
   * Returns the organization with the specified name or null if no such organization exists.
   * 
   * @param orgName the name of the organization to retrieve
   * @return Organization
   * @throws DAOException thrown if an error occurs while retrieving the organization
   */
  public OrganizationEntity findByName(String orgName) throws DAOException {
    TypedQuery<OrganizationEntity> query =
        getEntityManager().createNamedQuery("organizationFindByName", OrganizationEntity.class);
    List<OrganizationEntity> orgList;
    OrganizationEntity org = null;

    query.setParameter("oName", orgName);
    orgList = query.getResultList();

    if (!orgList.isEmpty()) {
      org = orgList.get(0);
    }
    return org;
  }

  /**
   * Returns the organization with the specified id or null if no such organization exists.
   * 
   * @param orgId: id of the organization to retrieve
   * @return Organization
   * @throws None
   */
  public OrganizationEntity findById(Long orgId) {
    TypedQuery<OrganizationEntity> query =
        getEntityManager().createNamedQuery("organizationFindById", OrganizationEntity.class);

    query.setParameter("oId", orgId);
    return query.getSingleResult();
  }

  /**
   * @see com.travelport.otm.odaudit.dao.AbstractDAO#delete(com.travelport.otm.odaudit.model.PersistentEntity)
   */
  @Override
  public void delete(OrganizationEntity entity) {
    entity.setDeleted(true);
    getEntityManager().merge(entity);
  }

  /**
   * @see com.travelport.otm.odaudit.dao.AbstractDAO#checkForDuplicate(com.travelport.otm.odaudit.model.PersistentEntity)
   */
  @Override
  protected void checkForDuplicate(OrganizationEntity org) throws DAOException {
    if (org != null) {
      OrganizationEntity otherOrg = findByName(org.getName());
      boolean isDuplicate;

      if (org.getId() < 0) { // create
        isDuplicate = (otherOrg != null);

      } else { // update
        isDuplicate = (otherOrg != null) && (org.getId() != otherOrg.getId());
      }
      if (isDuplicate) {
        throw new DAOException(
            "An organization with the name '" + org.getName() + "' already exists.");
      }
    }
  }

}
