/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import com.travelport.otm.odaudit.model.ODScanEntity;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;

/**
 * DAO that provides operations related to the creation, retrieval, and management of
 * <code>OdScan</code> entities.
 */
public class ODScanDAO extends AbstractDAO<ODScanEntity> {

  /**
   * Constructor that supplies the factory which created this DAO instance.
   * 
   * @param factory the factory that created this DAO
   */
  ODScanDAO(DAOFactory factory) {
    super(factory);
  }

  /**
   * Returns KPI values for the latest OD_SCAN record for a given git_repository_id or null if no
   * records found
   * 
   * @param gitRepoId: git_repository_id
   * @return List<GitRepository>
   * @throws None
   */
  public SonarScanInfoEntity findLatestScanInfoForGitRepo(long gitRepoId) {
    List<ODScanEntity> odScans = null;
    SonarScanInfoEntity scanInfo = null;

    TypedQuery<ODScanEntity> query =
        getEntityManager().createNamedQuery("findOdScansForGitRepo", ODScanEntity.class);

    query.setParameter("gitRepoId", gitRepoId);
    odScans = query.getResultList();

    if (odScans != null & !odScans.isEmpty()) {
      // Get the latest od_scan record
      ODScanEntity scan = odScans.get(0);
      if (scan != null) {
        scanInfo = scan.getSonarScanInfo();
      }
    }

    return scanInfo;
  }

  /**
   * @see com.travelport.otm.odaudit.dao.AbstractDAO#getEntityType()
   */
  @Override
  protected Class<ODScanEntity> getEntityType() {
    return ODScanEntity.class;
  }

  /**
   * Delete operation is not supported for od_scan
   * 
   * @param entity: the entity to be deleted
   * @throws none
   */
  @Override
  public void delete(ODScanEntity entity) {
    throw new UnsupportedOperationException("delete");
  }
}
