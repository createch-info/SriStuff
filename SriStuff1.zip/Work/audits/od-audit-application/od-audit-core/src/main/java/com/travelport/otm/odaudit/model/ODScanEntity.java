/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.travelport.otm.odaudit.type.ScanType;

/**
 * Represents common attributes for OD audit scans
 */
@NamedQueries({@NamedQuery(name = "findOdScansForGitRepo",
    query = "SELECT ods FROM ODScanEntity ods WHERE (ods.gitRepository.id = :gitRepoId) ORDER BY ods.scanDate DESC")})
@Entity
@Table(name = "od_scan")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "daoCache")
public class ODScanEntity implements PersistentEntity {

  private static final long serialVersionUID = 201711151100L;

  @Id
  @Column(name = "id", nullable = false)
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id = -1L;

  @OneToMany(mappedBy = "odScan", fetch = FetchType.LAZY, cascade = {CascadeType.REMOVE})
  @Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "collectionCache")
  private List<RepositoryReportEntity> repositoryReports;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "git_repository_id")
  private GitRepositoryEntity gitRepository;

  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "sonar_scan_info_id")
  private SonarScanInfoEntity sonarScanInfo;

  @NotNull
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "scan_date")
  private Date scanDate;

  @NotNull
  @Column(name = "scan_type", length = 50)
  private ScanType scanType;

  /**
   * Returns the unique ID of this persistent entity.
   *
   * @return long
   */
  public long getId() {
    return id;
  }

  /**
   * Assigns the unique ID of this persistent entity.
   *
   * @param id the unique ID value to assign
   */
  public void setId(long id) {
    this.id = id;
  }

  /**
   * Returns Git repository the scan is associated to
   *
   * @return GitRepository
   */
  public GitRepositoryEntity getGitRepository() {
    return gitRepository;
  }

  /**
   * Assigns Git repository
   *
   * @param GitRepositoryEntity to assign
   */
  public void setGitRepository(GitRepositoryEntity gitRepository) {
    this.gitRepository = gitRepository;
  }

  /**
   * Returns the scan date
   *
   * @return java.sql.Date
   */
  public Date getScanDate() {
    return scanDate;
  }

  /**
   * Assigns scan date
   *
   * @param date to assign
   */
  public void setScanDate(Date scanDate) {
    this.scanDate = scanDate;
  }

  /**
   * Returns scan type
   *
   * @return ScanType
   */
  public ScanType getScanType() {
    return scanType;
  }

  /**
   * Assigns scan type
   *
   * @param ScanType to assign
   */
  public void setScanType(ScanType scanType) {
    this.scanType = scanType;
  }

  /**
   * Returns the list of repository reports.
   *
   * @return List<RepositoryReport>
   */
  public List<RepositoryReportEntity> getRepositoryReports() {
    return repositoryReports;
  }

  /**
   * Assigns the list of repository reports.
   *
   * @param repositoryReports to assign
   */
  public void setRepositoryReports(List<RepositoryReportEntity> repositoryReports) {
    this.repositoryReports = repositoryReports;
  }

  /**
   * Returns the SonarScanInfoEntity object
   *
   * @return SonarScanInfoEntity
   */
  public SonarScanInfoEntity getSonarScanInfo() {
    return sonarScanInfo;
  }

  /**
   * Assigns the SonarScanInfoEntity object
   *
   * @param SonarScanInfoEntity to assign
   */
  public void setSonarScanInfo(SonarScanInfoEntity sonarScanInfo) {
    this.sonarScanInfo = sonarScanInfo;
  }
}
