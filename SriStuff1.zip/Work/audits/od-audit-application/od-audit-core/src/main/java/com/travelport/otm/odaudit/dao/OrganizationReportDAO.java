/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import java.sql.Date;
import java.util.EnumSet;
import java.util.List;
import java.util.stream.Collectors;
import javax.persistence.TypedQuery;
import com.travelport.otm.odaudit.model.KPIRating;
import com.travelport.otm.odaudit.model.OrganizationReportEntity;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;
import com.travelport.otm.odaudit.model.SonarThresholdsEntity;
import com.travelport.otm.odaudit.type.KPIType;
import com.travelport.otm.odaudit.util.ODAuditUtils;
import com.travelport.otm.odaudit.util.RatingsUtils;

/**
 * DAO that provides operations related to the creation, retrieval, and management of
 * <code>OrganizationReport</code> entities.
 */
public class OrganizationReportDAO extends AbstractDAO<OrganizationReportEntity> {

  /**
   * Constructor that supplies the factory which created this DAO instance.
   * 
   * @param factory that created this DAO
   */
  public OrganizationReportDAO(DAOFactory factory) {
    super(factory);
  }

  /**
   * @see com.travelport.otm.odaudit.dao.AbstractDAO#getEntityType()
   */
  @Override
  protected Class<OrganizationReportEntity> getEntityType() {
    return OrganizationReportEntity.class;
  }

  /**
   * Returns a list of organization reports for a given org name
   * 
   * @param orgName org name to match
   * @return List<OrganizationReport>
   * @throws DAOException thrown if an error occurs
   */
  public List<OrganizationReportEntity> findByOrgName(String orgName) throws DAOException {
    TypedQuery<OrganizationReportEntity> query =
        getEntityManager().createNamedQuery("orgReportFindByName", OrganizationReportEntity.class);

    query.setParameter("orgName", orgName);
    return query.getResultList();
  }

  /**
   * Returns organization report record for a given organization_report_id with ratings computed
   * 
   * @param orgRepoReportId: the ID of the organization report
   * @return OrganizationReportEntity
   * @throws DAOException
   */
  public OrganizationReportEntity getOrgReportRatings(long orgRepoReportId) throws DAOException {

    // Fetch organization_report record for the id passed in
    OrganizationReportEntity orgRepoReport = get(orgRepoReportId);
    if (orgRepoReport == null) {
      throw new DAOException("Repository report not found for id passed: " + orgRepoReportId);
    }

    long sonarScanInfoId = orgRepoReport.getSonarScanInfo().getId();
    Date reportDate = new Date(orgRepoReport.getOrgReportDate().getTime());

    SonarThresholdsEntity sonarThresholds = RatingsUtils.getSonarThresholdsEntity(reportDate);
    SonarScanInfoEntity scanInfo = RatingsUtils.getSonarScanInfoEntity(sonarScanInfoId);

    // Compute ratings
    List<KPIRating> kpiRatings =
        EnumSet.allOf(KPIType.class).stream().filter(e -> e.isLowerIsBetter() != null)
            .map(e -> new KPIRating(e, ODAuditUtils.getKPIRating(e, sonarThresholds, scanInfo)))
            .collect(Collectors.toList());

    orgRepoReport.setKpiRatings(kpiRatings);
    return orgRepoReport;
  }
  
  /**
   * Returns a list of organization reports for a given programReportId
   * 
   * @param odPrgrmId to match
   * @return List<OrganizationReport>
   * @throws DAOException thrown if an error occurs
   */
  public List<OrganizationReportEntity> findByOdPrgmId(Long odPrgmId) {
    TypedQuery<OrganizationReportEntity> query = getEntityManager()
        .createNamedQuery("orgReportFindByOdPrgmReportId", OrganizationReportEntity.class);
       query.setParameter("odPrgmId", odPrgmId);
    return query.getResultList();
  }

  /**
   * Delete operation is not supported for organization_report
   * 
   * @param entity: the entity to be deleted
   * @throws none
   */
  @Override
  public void delete(OrganizationReportEntity report) {
    throw new UnsupportedOperationException("delete");
  }
}