/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import javax.persistence.EntityManager;

import com.travelport.otm.odaudit.model.PersistentEntity;
import com.travelport.otm.odaudit.validation.ModelValidator;
import com.travelport.otm.odaudit.validation.ValidationException;
import com.travelport.otm.odaudit.validation.ValidationResults;

/**
 * Base class for all DAO's that provides basic CRUD operations.
 */
public abstract class AbstractDAO<T extends PersistentEntity> {

  private DAOFactory factory;

  /**
   * Constructor that supplies the factory which created this DAO instance.
   * 
   * @param factory the factory that created this DAO
   */
  AbstractDAO(DAOFactory factory) {
    this.factory = factory;
  }

  /**
   * Returns the factory that created this DAO instance.
   * 
   * @return DAOFactory
   */
  protected DAOFactory getFactory() {
    return factory;
  }

  /**
   * Returns the JPS entity manager associated with the factory that created this DAO.
   * 
   * @return EntityManager
   */
  protected EntityManager getEntityManager() {
    return factory.getEntityManager();
  }

  /**
   * Returns the entity type for this DAO.
   * 
   * @return Class<T>
   */
  protected abstract Class<T> getEntityType();

  /**
   * Returns the persistent entity with the specified ID.
   * 
   * @param id the ID of the persistent entity to retrieve
   * @return T
   * @throws DAOException thrown if an error occurs while retrieving the persistent entity
   */
  public T get(long id) throws DAOException {
    return getEntityManager().find(getEntityType(), id);
  }

  /**
   * Saves the given entity to persistent storage for the first time.
   * 
   * @param entity the entity to be saved
   * @throws DAOException thrown if an error occurs while saving the persistent entity
   * @throws ValidationException thrown if one or more validation errors exist in the entity
   */
  public long create(T entity) throws DAOException, ValidationException {
    ValidationResults vResults = ModelValidator.validate(entity);

    if (vResults.hasViolations()) {
      throw new ValidationException(vResults);
    }
    checkForDuplicate(entity);
    getEntityManager().persist(entity);
    DAOFactory.invalidateCollectionCache();
    return entity.getId();
  }

  /**
   * Updates the given entity in persistent storage.
   * 
   * @param entity the entity to be updated
   * @throws DAOException thrown if an error occurs while updating the persistent entity
   * @throws ValidationException thrown if one or more validation errors exist in the entity
   */
  public void update(T entity) throws DAOException, ValidationException {
    ValidationResults vResults = ModelValidator.validate(entity);

    if (vResults.hasViolations()) {
      throw new ValidationException(vResults);
    }
    checkForDuplicate(entity);
    getEntityManager().merge(entity);
  }

  /**
   * Deletes the given entity to persistent storage for the first time.
   * 
   * @param entity the entity to be deleted
   * @throws DAOException thrown if an error occurs while deleting the persistent entity
   */
  public void delete(T entity) throws DAOException {
    getEntityManager().remove(entity);
    DAOFactory.invalidateCollectionCache();
  }

  /**
   * Checks to see if another entity already exists with the same unique characteristics as the
   * given one. By default, this method takes no action (meaning duplicates are allowed by default).
   * Sub-classes may override to perform type-specific checks.
   * 
   * @param group the entity to check for duplicates
   */
  protected void checkForDuplicate(T entity) throws DAOException {
    // default behavior is no action (duplicates allowed)
  }

}
