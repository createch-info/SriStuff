/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.model;

import com.travelport.otm.odaudit.type.KPIType;
import com.travelport.otm.odaudit.type.SonarRating;

/**
 * POJO for KPI type along with rating. Can be re-used for ratings at multiple levels
 */
public class KPIRating {

  public KPIRating(KPIType kpiType, SonarRating rating) {
    this.kpiType = kpiType;
    this.rating = rating;
  }

  private KPIType kpiType;

  private SonarRating rating;

  /**
   * Returns KPI type
   *
   * @return KPIType
   */
  public KPIType getKpiType() {
    return kpiType;
  }

  /**
   * Assigns KPI type
   *
   * @param KPIType
   *
   */
  public void setKpiType(KPIType kpiType) {
    this.kpiType = kpiType;
  }

  /**
   * Returns Sonar rating for a KPI
   *
   * @return SonarMetricRating
   */
  public SonarRating getRating() {
    return rating;
  }

  /**
   * Assigns Sonar rating for a KPI
   *
   * @param SonarRating
   *
   */
  public void setRating(SonarRating rating) {
    this.rating = rating;
  }
}
