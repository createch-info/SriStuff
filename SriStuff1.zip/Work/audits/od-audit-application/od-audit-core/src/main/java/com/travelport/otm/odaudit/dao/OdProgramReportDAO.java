/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import java.sql.Date;
import java.util.EnumSet;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.TypedQuery;

import com.travelport.otm.odaudit.model.KPIRating;
import com.travelport.otm.odaudit.model.OdProgramReportEntity;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;
import com.travelport.otm.odaudit.model.SonarThresholdsEntity;
import com.travelport.otm.odaudit.type.KPIType;
import com.travelport.otm.odaudit.util.ODAuditUtils;
import com.travelport.otm.odaudit.util.RatingsUtils;

/**
 * DAO that provides operations related to the creation, retrieval, and management of
 * <code>OdProgramReport</code> entities.
 */
public class OdProgramReportDAO extends AbstractDAO<OdProgramReportEntity> {

  /**
   * Constructor that supplies the factory which created this DAO instance.
   * 
   * @param factory that created this DAO
   */
  OdProgramReportDAO(DAOFactory factory) {
    super(factory);
  }

  /**
   * @see com.travelport.otm.odaudit.dao.AbstractDAO#getEntityType()
   */
  @Override
  protected Class<OdProgramReportEntity> getEntityType() {
    return OdProgramReportEntity.class;
  }

  /**
   * Returns a list of all OD program reports
   * 
   * @return List<OdProgramReport>
   * @throws DAOException thrown if an error occurs while retrieving the organizations
   */
  public List<OdProgramReportEntity> getAll() throws DAOException {
    TypedQuery<OdProgramReportEntity> query =
        getEntityManager().createNamedQuery("odPgmReportFindAll", OdProgramReportEntity.class);

    return query.getResultList();
  }

  /**
   * Returns od_program report record for a given od_program_report_id with ratings computed
   * 
   * @param odProgramReportId: the ID of the od_program report
   * @return OdProgramReportEntity
   * @throws DAOException
   */
  public OdProgramReportEntity getOdPrgRepoRatings(long odProgramReportId) throws DAOException {

    // Fetch od_program_report_id record for the id passed in
    OdProgramReportEntity odProgramReport = get(odProgramReportId);
    if (odProgramReport == null) {
      throw new DAOException("Repository report not found for id passed: " + odProgramReportId);
    }
    long sonarScanInfoId = odProgramReport.getSonarScanInfo().getId();
    Date reportDate = new Date(odProgramReport.getOdReportDate().getTime());

    SonarThresholdsEntity sonarThresholds = RatingsUtils.getSonarThresholdsEntity(reportDate);
    SonarScanInfoEntity scanInfo = RatingsUtils.getSonarScanInfoEntity(sonarScanInfoId);

    // Compute ratings
    List<KPIRating> kpiRatings =
        EnumSet.allOf(KPIType.class).stream().filter(e -> e.isLowerIsBetter() != null)
            .map(e -> new KPIRating(e, ODAuditUtils.getKPIRating(e, sonarThresholds, scanInfo)))
            .collect(Collectors.toList());

    odProgramReport.setKpiRatings(kpiRatings);
    return odProgramReport;
  }

  /**
   * Delete operation is not supported for od_program_report
   * 
   * @param entity: the entity to be deleted
   * @throws none
   */
  @Override
  public void delete(OdProgramReportEntity report) {
    throw new UnsupportedOperationException("delete");
  }
}
