/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.validation;

import javax.validation.Validation;
import javax.validation.Validator;

/**
 * Performs the validation of persistent model objects and and reports the findings as
 * <code>ValidationResults</code>.
 */
public class ModelValidator {

  private static Validator validator;

  private ModelValidator() {}

  /**
   * Validates the given model object and returns the collection of <code>ValidationResults</code>.
   * 
   * @param obj the model object to be validated
   * @return ValidationResults
   */
  public static ValidationResults validate(Object obj) {
    return new ValidationResults(validator.validate(obj));
  }

  static {
    try {
      validator = Validation.buildDefaultValidatorFactory().getValidator();

    } catch (Exception t) {
      throw new ExceptionInInitializerError(t);
    }
  }

}
