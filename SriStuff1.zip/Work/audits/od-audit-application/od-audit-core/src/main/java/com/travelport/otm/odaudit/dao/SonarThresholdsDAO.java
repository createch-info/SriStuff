/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.TypedQuery;

import com.travelport.otm.odaudit.model.SonarThresholdsEntity;
import com.travelport.otm.odaudit.validation.ModelValidator;
import com.travelport.otm.odaudit.validation.ValidationException;
import com.travelport.otm.odaudit.validation.ValidationResults;

/**
 * DAO that provides operations related to the creation, retrieval, and management of
 * <code>GitRepository</code> entities.
 */
public class SonarThresholdsDAO extends AbstractDAO<SonarThresholdsEntity> {

  /**
   * Constructor that supplies the factory which created this DAO instance.
   * 
   * @param factory the factory that created this DAO
   */
  SonarThresholdsDAO(DAOFactory factory) {
    super(factory);
  }

  /**
   * @see com.travelport.otm.odaudit.dao.AbstractDAO#getEntityType()
   */
  @Override
  protected Class<SonarThresholdsEntity> getEntityType() {
    return SonarThresholdsEntity.class;
  }

  /**
   * Returns active sonar thresholds record
   * 
   * @param None
   * @return SonarThresholds object
   * @throws DAOException thrown in case of error
   */
  public SonarThresholdsEntity fetchActiveSonarThresholds() {
    TypedQuery<SonarThresholdsEntity> query = getEntityManager()
        .createNamedQuery("fetchActiveSonarThresholds", SonarThresholdsEntity.class);
    SonarThresholdsEntity threshold = null;

    List<SonarThresholdsEntity> thrList = query.getResultList();

    if (!thrList.isEmpty()) {
      threshold = thrList.get(0);
    }

    return threshold;
  }

  /**
   * Fetch all sonar thresholds records (active & inactive)
   * 
   * @param None
   * @return List<SonarThresholds>
   * @throws None
   */
  public List<SonarThresholdsEntity> fetchAllSonarThresholds() {
    TypedQuery<SonarThresholdsEntity> query =
        getEntityManager().createNamedQuery("fetchAllSonarThresholds", SonarThresholdsEntity.class);

    return query.getResultList();
  }

  /**
   * Fetch sonar thresholds record effective on a given date which is the latest record with
   * effective_date <= the provided date
   * 
   * @param effDate java.util.Date
   * @return SonarThresholds
   * @throws SQLException
   * @throws DAOException
   * @throws None
   */
  public SonarThresholdsEntity fetchSonarThresholdsForEffDate(Date effDate) throws DAOException {
    TypedQuery<SonarThresholdsEntity> query = getEntityManager()
        .createNamedQuery("fetchSonarThresholdsForDate", SonarThresholdsEntity.class);
    query.setParameter("effDate", effDate);
    List<SonarThresholdsEntity> thresholds = query.getResultList();

    if (thresholds == null || thresholds.isEmpty()) {
      throw new DAOException("No data found in SonarThresholdsDAO.fetchSonarThresholdsForEffDate");
    }

    return thresholds.get(0);
  }

  /**
   * Delete an active threshold (soft delete)
   * 
   * @param entity: the entity to be deleted
   * @throws None
   */
  @Override
  public void delete(SonarThresholdsEntity entity) {
    entity.setActive(false);
    getEntityManager().merge(entity);
  }

  /**
   * Delete the previously active threshold record and create new one
   * 
   * @param entity: the entity to be saved
   * @throws ValidationException thrown if one or more validation errors exist in the entity
   * @throws DAOException
   */
  @Override
  public long create(SonarThresholdsEntity entity) throws DAOException, ValidationException {
    ValidationResults vResults = ModelValidator.validate(entity);

    if (vResults.hasViolations()) {
      throw new ValidationException(vResults);
    }

    // Start transaction
    // getFactory().beginTransaction();

    // Fetch the current active record and delete
    SonarThresholdsEntity curThreshold = fetchActiveSonarThresholds();
    if (curThreshold != null) {
      delete(curThreshold);
    }

    getEntityManager().persist(entity);

    // End transaction
    // getFactory().commitTransaction();

    DAOFactory.invalidateCollectionCache();
    return entity.getId();
  }
}
