/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * A GitBucket group that is owned and managed by a project team.
 */
@NamedQueries({@NamedQuery(name = "gitBucketGroupFindByName",
    query = "SELECT g FROM GitBucketGroupEntity g WHERE (g.groupName = :gName) AND (g.projectTeam.id = :gTeamId) ORDER BY g.groupName ASC"),})
@Entity
@Table(name = "gb_group")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "daoCache")
public class GitBucketGroupEntity implements PersistentEntity {

  private static final long serialVersionUID = 5941799628732926512L;

  @Id
  @Column(name = "id", nullable = false)
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id = -1L;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "project_team_id")
  private ProjectTeamEntity projectTeam;

  @NotNull
  @Size(min = 1, max = 200)
  @Column(name = "group_name", nullable = false, length = 100)
  private String groupName;

  /**
   * Returns the unique ID of this persistent entity.
   *
   * @return long
   */
  public long getId() {
    return id;
  }

  /**
   * Assigns the unique ID of this persistent entity.
   *
   * @param id the unique ID value to assign
   */
  public void setId(long id) {
    this.id = id;
  }

  /**
   * Returns the project team to which this group belongs.
   *
   * @return ProjectTeam
   */
  public ProjectTeamEntity getProjectTeam() {
    return projectTeam;
  }

  /**
   * Assigns the project team to which this group belongs.
   *
   * @param projectTeam the owning project team to assign
   */
  public void setProjectTeam(ProjectTeamEntity projectTeam) {
    this.projectTeam = projectTeam;
  }

  /**
   * Returns the name of the GitBucket group.
   *
   * @return String
   */
  public String getGroupName() {
    return groupName;
  }

  /**
   * Assigns the name of the GitBucket group.
   *
   * @param groupName the name value to assign
   */
  public void setGroupName(String groupName) {
    this.groupName = groupName;
  }

}
