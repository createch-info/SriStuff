/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * Represents an individual sonar scan run against a gitbucket repository and branch
 */
@NamedQueries({@NamedQuery(name = "findByGitUrlAndBranch",
    query = "SELECT rr FROM RepositoryReportEntity rr WHERE (rr.odScan.gitRepository.repositoryUrl = :gitUrl) AND (rr.odScan.gitRepository.branch = :branch)"),})
@Entity
@Table(name = "repository_report")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "daoCache")
public class RepositoryReportEntity implements PersistentEntity {

  private static final long serialVersionUID = 201711141443L;

  @Id
  @Column(name = "id", nullable = false)
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id = -1L;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "od_program_report_id")
  private OdProgramReportEntity odProgramReport;

  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "od_scan_id")
  private ODScanEntity odScan;

  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "sonar_scan_info_id")
  private SonarScanInfoEntity sonarScanInfo;

  @Column(name = "sonar_qube_url", length = 500)
  private String sonarQubeUrl;

  @NotNull
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "report_date")
  private Date reportDate;

  @Transient
  private List<KPIRating> kpiRatings;

  /**
   * Returns the unique ID of this persistent entity.
   *
   * @return long
   */
  public long getId() {
    return id;
  }

  /**
   * Assigns the unique ID of this persistent entity.
   *
   * @param id the unique ID value to assign
   */
  public void setId(long id) {
    this.id = id;
  }

  /**
   * Returns the associated OdProgramReport
   *
   * @return long
   */
  public OdProgramReportEntity getOdProgramReport() {
    return odProgramReport;
  }

  /**
   * Assigns the associated OdProgramReport
   *
   * @param OdProgramReportEntity object to assign
   */
  public void setOdProgramReport(OdProgramReportEntity odProgramReport) {
    this.odProgramReport = odProgramReport;
  }

  /**
   * Returns OdScan the sonar scan is associated to
   *
   * @return OdScan
   */
  public ODScanEntity getOdScan() {
    return odScan;
  }

  /**
   * Assigns OdScan the sonar scan is associated to
   *
   * @param ODScanEntity to assign
   */
  public void setOdScan(ODScanEntity odScan) {
    this.odScan = odScan;
  }

  /**
   * Returns SonarScanInfo object associated with the scan
   *
   * @return String
   */
  public SonarScanInfoEntity getSonarScanInfo() {
    return sonarScanInfo;
  }

  /**
   * Assigns SonarScanInfo object associated with the scan
   *
   * @param SonarScanInfoEntity object to assign
   */
  public void setSonarScanInfo(SonarScanInfoEntity sonarScanInfo) {
    this.sonarScanInfo = sonarScanInfo;
  }

  /**
   * Returns sonarQube URL for the scan
   *
   * @return String
   */
  public String getSonarQubeUrl() {
    return sonarQubeUrl;
  }

  /**
   * Assigns sonarQube URL for a sonar scan
   *
   * @param sonarQube URL to assign
   */
  public void setSonarQubeUrl(String sonarQubeUrl) {
    this.sonarQubeUrl = sonarQubeUrl;
  }

  /**
   * Returns the date & time when this report was created
   *
   * @return Date
   */
  public Date getReportDate() {
    return reportDate;
  }

  /**
   * Assigns the date & time when this report was created
   *
   * @param Date to assign
   */
  public void setReportDate(Date reportDate) {
    this.reportDate = reportDate;
  }

  /**
   * Returns list of computed KPI ratings for the repository
   *
   * @return List<KPIRating>
   */
  public List<KPIRating> getKpiRatings() {
    return kpiRatings;
  }

  /**
   * Assigns list of computed KPI ratings for the repository
   *
   * @param List<KPIRating>
   */
  public void setKpiRatings(List<KPIRating> kpiRatings) {
    this.kpiRatings = kpiRatings;
  }
}
