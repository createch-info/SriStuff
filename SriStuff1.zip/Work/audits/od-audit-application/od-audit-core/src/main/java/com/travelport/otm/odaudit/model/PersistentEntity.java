/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.model;

import java.io.Serializable;

/**
 * Base class for all persistent entity types.
 */
public interface PersistentEntity extends Serializable {

  /**
   * Returns the ID of this persistent entity.
   *
   * @return long
   */
  public long getId();
}
