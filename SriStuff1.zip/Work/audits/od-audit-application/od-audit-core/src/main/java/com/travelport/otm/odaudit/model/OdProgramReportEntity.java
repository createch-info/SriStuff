/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * Represents a top-level organization for which OD Audit reports will be run.
 */
@NamedQueries({@NamedQuery(name = "odPgmReportFindAll",
    query = "SELECT pr FROM OdProgramReportEntity pr ORDER BY pr.odReportDate DESC"),})
@Entity
@Table(name = "od_program_report")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "daoCache")
public class OdProgramReportEntity implements PersistentEntity {

  private static final long serialVersionUID = 201711211206L;

  @Id
  @Column(name = "id", nullable = false)
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id = -1L;

  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "sonar_scan_info_id")
  private SonarScanInfoEntity sonarScanInfo;

  @OneToMany(mappedBy = "odProgramReport", fetch = FetchType.LAZY, cascade = {CascadeType.REMOVE})
  @Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "collectionCache")
  private List<RepositoryReportEntity> repositoryReports;

  @OneToMany(mappedBy = "odProgramReport", fetch = FetchType.LAZY, cascade = {CascadeType.REMOVE})
  @Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "collectionCache")
  private List<ProjectTeamReportEntity> projectTeamReports;

  @OneToMany(mappedBy = "odProgramReport", fetch = FetchType.LAZY, cascade = {CascadeType.REMOVE})
  @Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "collectionCache")
  private List<OrganizationReportEntity> organizationReports;

  @NotNull
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "od_report_date")
  private Date odReportDate;

  @Transient
  private List<KPIRating> kpiRatings;

  /**
   * Returns the unique ID of this persistent entity.
   *
   * @return long
   */
  public long getId() {
    return id;
  }

  /**
   * Assigns the unique ID of this persistent entity.
   *
   * @param id the unique ID value to assign
   */
  public void setId(long id) {
    this.id = id;
  }

  /**
   * Returns SonarScanInfo object associated with the scan
   *
   * @return String
   */
  public SonarScanInfoEntity getSonarScanInfo() {
    return sonarScanInfo;
  }

  /**
   * Assigns SonarScanInfo object associated with the scan
   *
   * @param SonarScanInfoEntity object to assign
   */
  public void setSonarScanInfo(SonarScanInfoEntity sonarScanInfo) {
    this.sonarScanInfo = sonarScanInfo;
  }

  /**
   * Returns the list of repository reports that are assigned to this OD program report.
   *
   * @return List<RepositoryReport>
   */
  public List<RepositoryReportEntity> getRepositoryReports() {
    return repositoryReports;
  }

  /**
   * Assigns the list of repository reports that are assigned to this OD program report
   *
   * @param List<RepositoryReport> to assign
   */
  public void setRepositoryReports(List<RepositoryReportEntity> repositoryReports) {
    this.repositoryReports = repositoryReports;
  }

  /**
   * Returns the list of project team reports that are assigned to this OD program report.
   *
   * @return List<ProjectTeamReport>
   */
  public List<ProjectTeamReportEntity> getProjectTeamReports() {
    return projectTeamReports;
  }

  /**
   * Assigns the list of project team reports that are assigned to this OD program report
   *
   * @param List<ProjectTeamReport> to assign
   */
  public void setProjectTeamReports(List<ProjectTeamReportEntity> projectTeamReports) {
    this.projectTeamReports = projectTeamReports;
  }

  /**
   * Returns the list of organization reports that are assigned to this OD program report
   *
   * @return List<OrganizationReport>
   */
  public List<OrganizationReportEntity> getOrganizationReports() {
    return organizationReports;
  }

  /**
   * Assigns the list of organization reports that are assigned to this OD program report
   *
   * @param List<OrganizationReport> to assign
   */
  public void setOrganizationReports(List<OrganizationReportEntity> organizationReports) {
    this.organizationReports = organizationReports;
  }

  /**
   * Returns the date & time when this report was created
   *
   * @return Date
   */
  public Date getOdReportDate() {
    return odReportDate;
  }

  /**
   * Assigns the date & time when this report was created
   *
   * @param Date to assign
   */
  public void setOdReportDate(Date odReportDate) {
    this.odReportDate = odReportDate;
  }

  /**
   * Returns list of computed KPI ratings for the repository
   *
   * @return List<KPIRating>
   */
  public List<KPIRating> getKpiRatings() {
    return kpiRatings;
  }

  /**
   * Assigns list of computed KPI ratings for the repository
   *
   * @param List<KPIRating>
   */
  public void setKpiRatings(List<KPIRating> kpiRatings) {
    this.kpiRatings = kpiRatings;
  }
}
