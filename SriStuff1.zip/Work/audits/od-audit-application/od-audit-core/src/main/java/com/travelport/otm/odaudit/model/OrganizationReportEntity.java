/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.model;

import java.util.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * Represents sonar scan roll-up at organization-level
 */
@NamedQueries({@NamedQuery(name = "orgReportFindByName",
query = "SELECT orp FROM OrganizationReportEntity orp WHERE (orp.organization.name = :orgName) AND (orp.organization.deleted = FALSE)"),
@NamedQuery(name = "orgReportFindByOdPrgmReportId",
query = "SELECT orp FROM OrganizationReportEntity orp WHERE (orp.odProgramReport.id = :odPrgmId) AND (orp.organization.deleted = FALSE)"),})
@Entity
@Table(name = "organization_report")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "daoCache")
public class OrganizationReportEntity implements PersistentEntity {

  private static final long serialVersionUID = 201711211325L;

  @Id
  @Column(name = "id", nullable = false)
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id = -1L;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "organization_id")
  private OrganizationEntity organization;

  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "sonar_scan_info_id")
  private SonarScanInfoEntity sonarScanInfo;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "od_program_report_id")
  private OdProgramReportEntity odProgramReport;

  @NotNull
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "org_report_date")
  private Date orgReportDate;

  @Transient
  private List<KPIRating> kpiRatings;

  /**
   * Returns the unique ID of this persistent entity.
   *
   * @return long
   */
  public long getId() {
    return id;
  }

  /**
   * Assigns the unique ID of this persistent entity.
   *
   * @param id the unique ID value to assign
   */
  public void setId(long id) {
    this.id = id;
  }

  /**
   * Returns associated organization
   *
   * @return Organization
   */
  public OrganizationEntity getOrganization() {
    return organization;
  }

  /**
   * Assigns the associated organization
   *
   * @param OrganizationEntity object to assign
   */
  public void setOrganization(OrganizationEntity organization) {
    this.organization = organization;
  }

  /**
   * Returns associated SonarScanInfo
   *
   * @return SonarScanInfo object
   */
  public SonarScanInfoEntity getSonarScanInfo() {
    return sonarScanInfo;
  }

  /**
   * Assigns associated SonarScanInfo
   *
   * @param SonarScanInfoEntity object to assign
   */
  public void setSonarScanInfo(SonarScanInfoEntity sonarScanInfo) {
    this.sonarScanInfo = sonarScanInfo;
  }

  /**
   * Returns associated OdProgramReport
   *
   * @return OdProgramReport object
   */
  public OdProgramReportEntity getOdProgramReport() {
    return odProgramReport;
  }

  /**
   * Assigns associated OdProgramReport
   *
   * @param OdProgramReportEntity object to assign
   */
  public void setOdProgramReport(OdProgramReportEntity odProgramReport) {
    this.odProgramReport = odProgramReport;
  }

  /**
   * Returns the date & time when this report was created
   *
   * @return Date
   */
  public Date getOrgReportDate() {
    return orgReportDate;
  }

  /**
   * Assigns the date & time when this report was created
   *
   * @param Date to assign
   */
  public void setOrgReportDate(Date orgReportDate) {
    this.orgReportDate = orgReportDate;
  }

  /**
   * Returns list of computed KPI ratings for the repository
   *
   * @return List<KPIRating>
   */
  public List<KPIRating> getKpiRatings() {
    return kpiRatings;
  }

  /**
   * Assigns list of computed KPI ratings for the repository
   *
   * @param List<KPIRating>
   */
  public void setKpiRatings(List<KPIRating> kpiRatings) {
    this.kpiRatings = kpiRatings;
  }

}



