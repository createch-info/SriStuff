/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * Represents sonar scan roll-up at project team-level
 */
@NamedQueries({@NamedQuery(name = "ptReportFindByName",
    query = "SELECT ptr FROM ProjectTeamReportEntity ptr WHERE (ptr.projectTeam.name = :ptName) AND (ptr.projectTeam.deleted = FALSE)"),})
@Entity
@Table(name = "project_team_report")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "daoCache")
public class ProjectTeamReportEntity implements PersistentEntity {

  private static final long serialVersionUID = 201711211302L;

  @Id
  @Column(name = "id", nullable = false)
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id = -1L;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "project_team_id")
  private ProjectTeamEntity projectTeam;

  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "sonar_scan_info_id")
  private SonarScanInfoEntity sonarScanInfo;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "od_program_report_id")
  private OdProgramReportEntity odProgramReport;

  @NotNull
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "pt_report_date")
  private Date ptReportDate;

  @Transient
  private List<KPIRating> kpiRatings;

  /**
   * Returns the unique ID of this persistent entity.
   *
   * @return long
   */
  public long getId() {
    return id;
  }

  /**
   * Assigns the unique ID of this persistent entity.
   *
   * @param id the unique ID value to assign
   */
  public void setId(long id) {
    this.id = id;
  }

  /**
   * Returns the associated project team
   *
   * @return ProjectTeam
   */
  public ProjectTeamEntity getProjectTeam() {
    return projectTeam;
  }

  /**
   * Assigns the associated project team
   *
   * @param ProjectTeamEntity object to assign
   */
  public void setProjectTeam(ProjectTeamEntity projectTeam) {
    this.projectTeam = projectTeam;
  }

  /**
   * Returns the associated SonarScanInfo
   *
   * @return SonarScanInfo object
   */
  public SonarScanInfoEntity getSonarScanInfo() {
    return sonarScanInfo;
  }

  /**
   * Assigns the associated SonarScanInfo
   *
   * @param SonarScanInfoEntity object to assign
   */
  public void setSonarScanInfo(SonarScanInfoEntity sonarScanInfo) {
    this.sonarScanInfo = sonarScanInfo;
  }

  /**
   * Returns the associated OdProgramReport
   *
   * @return OdProgramReport object
   */
  public OdProgramReportEntity getOdProgramReport() {
    return odProgramReport;
  }

  /**
   * Assigns the associated OdProgramReport
   *
   * @param OdProgramReportEntity object to assign
   */
  public void setOdProgramReport(OdProgramReportEntity odProgramReport) {
    this.odProgramReport = odProgramReport;
  }

  /**
   * Returns the date & time when this report was created
   *
   * @return Date
   */
  public Date getPtReportDate() {
    return ptReportDate;
  }

  /**
   * Assigns the date & time when this report was created
   *
   * @param Date to assign
   */
  public void setPtReportDate(Date ptReportDate) {
    this.ptReportDate = ptReportDate;
  }

  /**
   * Returns list of computed KPI ratings for the repository
   *
   * @return List<KPIRating>
   */
  public List<KPIRating> getKpiRatings() {
    return kpiRatings;
  }

  /**
   * Assigns list of computed KPI ratings for the repository
   *
   * @param List<KPIRating>
   */
  public void setKpiRatings(List<KPIRating> kpiRatings) {
    this.kpiRatings = kpiRatings;
  }
}
