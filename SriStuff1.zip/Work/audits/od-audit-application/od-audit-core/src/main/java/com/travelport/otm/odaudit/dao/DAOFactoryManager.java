/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Manages the lifecycle of a thread local <code>DAOFactory</code> instance.
 */
public class DAOFactoryManager {

  private static final Logger log = LoggerFactory.getLogger(DAOFactoryManager.class);

  private static ThreadLocal<DAOFactory> factoryInstance = new ThreadLocal<>();
  private static ThreadLocal<Boolean> markedForRollback = new ThreadLocal<Boolean>() {
    @Override
    protected Boolean initialValue() {
      return Boolean.FALSE;
    }
  };

  /**
   * Private constructor.
   */
  private DAOFactoryManager() {}

  /**
   * Initializes a thread local factory instance if one does not already exist.
   */
  public static void initFactory() {
    if (factoryInstance.get() == null) {
      DAOFactory factory = new DAOFactory();

      factory.beginTransaction();
      factoryInstance.set(factory);
      markedForRollback.set(Boolean.FALSE);
    }
  }

  /**
   * Commits or rolls back the transaction before closing the factory instance associated with the
   * current thread.
   * 
   * @throws IllegalStateException thrown if no factory instance has been initialized for the
   *         current thread
   */
  public static void closeFactory() {
    try {
      DAOFactory factory = factoryInstance.get();

      if (factory == null) {
        throw new IllegalStateException(
            "No factory instance has been initialized for the current thread.");
      }

      if (!markedForRollback.get()) {
        factory.commitTransaction();

      } else {
        factory.rollbackTransaction();
      }

    } catch (Exception t) {
      log.error("Error during transaction commit or rollback.", t);

    } finally {
      factoryInstance.set(null);
      markedForRollback.set(Boolean.FALSE);
    }
  }

  /**
   * Returns the factory instance or null if the factory has not yet been initialized.
   * 
   * @return DAOFactory
   */
  public static DAOFactory getFactory() {
    return factoryInstance.get();
  }

  /**
   * Returns true if the current thread has been marked for rollback upon factory close.
   * 
   * @return boolean
   */
  public static boolean isMarkedForRollback() {
    return markedForRollback.get();
  }

  /**
   * Marks the current thread for rollback upon factory close.
   */
  public static void markForRollback() {
    markedForRollback.set(Boolean.TRUE);
  }

}
