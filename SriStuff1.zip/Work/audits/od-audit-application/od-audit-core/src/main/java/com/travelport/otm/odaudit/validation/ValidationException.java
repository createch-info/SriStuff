/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.validation;

/**
 * Thrown when a validation exception occurs.
 */
public class ValidationException extends Exception {

  private static final long serialVersionUID = 2855719347879649053L;

  private final ValidationResults validationResults;

  /**
   * Constructor that supplies the validation results.
   * 
   * @param validationResults the validation results
   */
  public ValidationException(ValidationResults validationResults) {
    super();
    this.validationResults = validationResults;
  }

  /**
   * Constructs an exception with the specified message.
   * 
   * @param message the exception message
   * @param validationResults the validation results
   */
  public ValidationException(String message, ValidationResults validationResults) {
    super(message);
    this.validationResults = validationResults;
  }

  /**
   * Constructs an exception with the specified underlying cause.
   * 
   * @param cause the underlying exception that caused this one
   * @param validationResults the validation results
   */
  public ValidationException(Throwable cause, ValidationResults validationResults) {
    super(cause);
    this.validationResults = validationResults;
  }

  /**
   * Constructs an exception with the specified message and underlying cause.
   * 
   * @param message the exception message
   * @param cause the underlying exception that caused this one
   * @param validationResults the validation results
   */
  public ValidationException(String message, Throwable cause, ValidationResults validationResults) {
    super(message, cause);
    this.validationResults = validationResults;
  }

  /**
   * Returns the validation results that were detected.
   * 
   * @return ValidationResults
   */
  public ValidationResults getValidationResults() {
    return validationResults;
  }

}
