/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.validation;

/**
 * Thrown when a NullPointer exception occurs.
 */
public class ODAuditServiceException extends Exception {

  private static final long serialVersionUID = 1L;

  public ODAuditServiceException(String message) {
    super(message);
  }

}
