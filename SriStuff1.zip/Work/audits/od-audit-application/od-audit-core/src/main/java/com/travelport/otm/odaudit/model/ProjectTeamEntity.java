/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.model;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.Where;

/**
 * Represents a single project team within an organization.
 */
@NamedQueries({
    @NamedQuery(name = "projectTeamFindByName",
        query = "SELECT t FROM ProjectTeamEntity t WHERE (t.deleted = FALSE) AND (t.name = :tName) AND (t.organization.id = :tOrgId) ORDER BY t.name ASC"),
    @NamedQuery(name = "projectTeamFindById",
        query = "SELECT t FROM ProjectTeamEntity t WHERE (t.deleted = FALSE) AND (t.id = :tId)"),
    @NamedQuery(name = "projectTeamFindByOrgId",
        query = "SELECT t FROM ProjectTeamEntity t WHERE (t.deleted = FALSE) AND (t.organization.id = :tOrgId) ORDER BY t.name ASC"),
    @NamedQuery(name = "projectTeamFindAll",
        query = "SELECT t FROM ProjectTeamEntity t WHERE (t.deleted = FALSE)")})

@Entity
@Table(name = "project_team")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "daoCache")
public class ProjectTeamEntity implements PersistentEntity {

  private static final long serialVersionUID = 2845672414260613108L;

  @Id
  @Column(name = "id", nullable = false)
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id = -1L;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "organization_id")
  private OrganizationEntity organization;

  @NotNull
  @Size(min = 1, max = 200)
  @Column(name = "name", nullable = false, length = 200)
  private String name;

  @OneToMany(mappedBy = "projectTeam", fetch = FetchType.LAZY, cascade = {CascadeType.REMOVE})
  @OrderBy("groupName ASC")
  @Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "collectionCache")
  private List<GitBucketGroupEntity> gitBucketGroups;

  @OneToMany(mappedBy = "projectTeam", fetch = FetchType.LAZY, cascade = {CascadeType.REMOVE})
  @Where(clause = "is_deleted = false")
  @OrderBy("repositoryName ASC")
  @Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "collectionCache")
  private List<GitRepositoryEntity> gitRepositories;

  @OneToMany(mappedBy = "projectTeam", fetch = FetchType.LAZY, cascade = {CascadeType.REMOVE})
  @OrderBy("ptReportDate DESC")
  @Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "collectionCache")
  private List<ProjectTeamReportEntity> reports;

  @Column(name = "is_deleted")
  @Type(type = "org.hibernate.type.NumericBooleanType")
  private boolean deleted;

  /**
   * Returns the unique ID of this persistent entity.
   *
   * @return long
   */
  public long getId() {
    return id;
  }

  /**
   * Assigns the unique ID of this persistent entity.
   *
   * @param id the unique ID value to assign
   */
  public void setId(long id) {
    this.id = id;
  }

  /**
   * Returns the organization to which this team belongs.
   *
   * @return Organization
   */
  public OrganizationEntity getOrganization() {
    return organization;
  }

  /**
   * Assigns the organization to which this team belongs.
   *
   * @param organization the owning organization to assign
   */
  public void setOrganization(OrganizationEntity organization) {
    this.organization = organization;
  }

  /**
   * Returns the name of this project team.
   *
   * @return String
   */
  public String getName() {
    return name;
  }

  /**
   * Assigns the name of this project team.
   *
   * @param name the name value to assign
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Returns the list of GitBucket groups for this project team.
   *
   * @return List<GitBucketGroup>
   */
  public List<GitBucketGroupEntity> getGitBucketGroups() {
    return gitBucketGroups;
  }

  /**
   * Assigns the list of GitBucket groups for this project team.
   *
   * @param gitBucketGroups the list of groups to assign
   */
  public void setGitBucketGroups(List<GitBucketGroupEntity> gitBucketGroups) {
    this.gitBucketGroups = gitBucketGroups;
  }

  /**
   * Returns the Git repositories for this project team.
   *
   * @return List<GitRepository>
   */
  public List<GitRepositoryEntity> getGitRepositories() {
    return gitRepositories;
  }

  /**
   * Assigns the Git repositories for this project team.
   *
   * @param gitRepositories the list of repositories to assign
   */
  public void setGitRepositories(List<GitRepositoryEntity> gitRepositories) {
    this.gitRepositories = gitRepositories;
  }

  /**
   * Returns the list of reports for this project team.
   *
   * @return List<ProjectTeamReport>
   */
  public List<ProjectTeamReportEntity> getReports() {
    return reports;
  }

  /**
   * Assigns the list of reports for this project team.
   *
   * @param reports the list of reports to assign
   */
  public void setReports(List<ProjectTeamReportEntity> reports) {
    this.reports = reports;
  }

  /**
   * Returns the flag value indicating whether this project team has been deleted.
   *
   * @return boolean
   */
  public boolean isDeleted() {
    return deleted;
  }

  /**
   * Assigns the flag value indicating whether this project team has been deleted.
   *
   * @param deleted the boolean flag value to assign
   */
  public void setDeleted(boolean deleted) {
    this.deleted = deleted;
  }

}
