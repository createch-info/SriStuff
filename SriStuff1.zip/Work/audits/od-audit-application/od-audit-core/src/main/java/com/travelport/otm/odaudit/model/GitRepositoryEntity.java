/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Type;

import com.travelport.otm.odaudit.type.RepositoryType;

/**
 * A Git repository that is owned and managed by a project team.
 */
@NamedQueries({
    @NamedQuery(name = "gitRepositoryFindByUrl",
        query = "SELECT r FROM GitRepositoryEntity r WHERE (r.deleted = FALSE) AND (r.repositoryUrl = :rUrl) ORDER BY r.repositoryUrl ASC"),
    @NamedQuery(name = "gitRepositoryFindByUrlPtId",
        query = "SELECT r FROM GitRepositoryEntity r WHERE (r.deleted = FALSE) AND (r.repositoryUrl = :rUrl) AND (r.projectTeam.id = :ptId) ORDER BY r.repositoryUrl ASC"),
    @NamedQuery(name = "findAllRepositories",
        query = "SELECT r FROM GitRepositoryEntity r WHERE (r.deleted = FALSE) ORDER BY r.repositoryUrl ASC"),
    @NamedQuery(name = "findRepositoriesForPt",
        query = "SELECT r FROM GitRepositoryEntity r WHERE (r.deleted = FALSE) AND (r.projectTeam.id = :ptId) ORDER BY r.repositoryUrl ASC")})
@Entity
@Table(name = "git_repository")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "daoCache")
public class GitRepositoryEntity implements PersistentEntity {

  private static final long serialVersionUID = -7854419210527832173L;

  @Id
  @Column(name = "id", nullable = false)
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id = -1L;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "project_team_id")
  private ProjectTeamEntity projectTeam;

  @OneToMany(mappedBy = "gitRepository", fetch = FetchType.LAZY, cascade = {CascadeType.REMOVE})
  @Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "collectionCache")
  private List<ODScanEntity> odScans;

  @NotNull
  @Size(min = 1, max = 100)
  @Column(name = "project_key", nullable = false, length = 100)
  private String projectKey;

  @Column(name = "project_name", length = 100)
  private String projectName;

  @Column(name = "branch", length = 100)
  private String branch;

  @NotNull
  @Size(min = 1, max = 500)
  @Column(name = "repository_url", nullable = false, length = 500)
  private String repositoryUrl;

  @NotNull
  @Size(min = 1, max = 200)
  @Column(name = "repository_name", nullable = false, length = 200)
  private String repositoryName;

  @NotNull
  @Column(name = "repository_type", nullable = false, length = 50)
  private RepositoryType type;

  @OneToMany(mappedBy = "gitRepository", fetch = FetchType.LAZY, cascade = {CascadeType.REMOVE})
  @OrderBy("scanDate DESC")
  @Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "collectionCache")
  private List<ODScanEntity> reports;

  @Column(name = "is_deleted")
  @Type(type = "org.hibernate.type.NumericBooleanType")
  private boolean deleted;

  /**
   * Returns the unique ID of this persistent entity.
   *
   * @return long
   */
  public long getId() {
    return id;
  }

  /**
   * Assigns the unique ID of this persistent entity.
   *
   * @param id the unique ID value to assign
   */
  public void setId(long id) {
    this.id = id;
  }

  /**
   * Returns the project team to which this repository belongs.
   *
   * @return ProjectTeam
   */
  public ProjectTeamEntity getProjectTeam() {
    return projectTeam;
  }

  /**
   * Assigns the project team to which this repository belongs.
   *
   * @param projectTeam the owning project team to assign
   */
  public void setProjectTeam(ProjectTeamEntity projectTeam) {
    this.projectTeam = projectTeam;
  }

  /**
   * Returns the name of the Git repository.
   *
   * @return String
   */
  public String getRepositoryName() {
    return repositoryName;
  }

  /**
   * Assigns the name of the Git repository.
   *
   * @param repositoryName the repository name to assign
   */
  public void setRepositoryName(String repositoryName) {
    this.repositoryName = repositoryName;
  }

  /**
   * Returns the project key for the project associated with Git repository
   *
   * @return String
   */
  public String getProjectKey() {
    return projectKey;
  }

  /**
   * Assigns project key for the project associated with Git repository
   *
   * @param projectKey to assign
   */
  public void setProjectKey(String projectKey) {
    this.projectKey = projectKey;
  }

  /**
   * Returns the URL of the Git repository.
   *
   * @return String
   */
  public String getRepositoryUrl() {
    return repositoryUrl;
  }

  /**
   * Assigns the URL of the Git repository.
   *
   * @param repositoryUrl the repository URL to assign
   */
  public void setRepositoryUrl(String repositoryUrl) {
    this.repositoryUrl = repositoryUrl;
  }

  /**
   * Returns the type of the Git repository.
   *
   * @return RepositoryType
   */
  public RepositoryType getType() {
    return type;
  }

  /**
   * Assigns the type of the Git repository.
   *
   * @param type the repository type to assign
   */
  public void setType(RepositoryType type) {
    this.type = type;
  }

  /**
   * Returns the flag value indicating whether this Git repository has been deleted.
   *
   * @return boolean
   */
  public boolean isDeleted() {
    return deleted;
  }

  /**
   * Assigns the flag value indicating whether this Git repository has been deleted.
   *
   * @param deleted the boolean flag value to assign
   */
  public void setDeleted(boolean deleted) {
    this.deleted = deleted;
  }

  /**
   * Returns branch name for the repository
   *
   * @return String
   */
  public String getBranch() {
    return branch;
  }

  /**
   * Assigns branch name for the repository
   *
   * @param branch name to assign
   */
  public void setBranch(String branch) {
    this.branch = branch;
  }

  /**
   * Returns project name for the repository
   *
   * @return String
   */
  public String getProjectName() {
    return projectName;
  }

  /**
   * Assigns project name for the repository
   *
   * @param project name to assign
   */
  public void setProjectName(String projectName) {
    this.projectName = projectName;
  }

  /**
   * Returns the list of reports for this repository.
   *
   * @return List<OdScan>
   */
  public List<ODScanEntity> getReports() {
    return reports;
  }

  /**
   * Assigns the list of reports for this organization.
   *
   * @param reports the list of reports to assign
   */
  public void setReports(List<ODScanEntity> reports) {
    this.reports = reports;
  }

}
