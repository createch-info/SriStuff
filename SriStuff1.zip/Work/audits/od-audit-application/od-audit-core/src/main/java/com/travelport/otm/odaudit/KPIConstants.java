/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit;

import java.text.DecimalFormat;

/**
 * Constants definitions used for KPI formatting.
 */
public final class KPIConstants {
  private KPIConstants() {}

  public static final DecimalFormat DEAFULT_FORMAT = new DecimalFormat("#,##0.0");
  public static final DecimalFormat PERCENT_FINAL = new DecimalFormat("0.0'%'");
  public static final DecimalFormat INT_FORMAT = new DecimalFormat("#,##0");

}
