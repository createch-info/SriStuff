/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import com.travelport.otm.odaudit.model.SonarScanInfoEntity;

/**
 * DAO that provides operations related to the creation, retrieval, and management of
 * <code>SonarScanInfo</code> entities.
 */
public class SonarScanInfoDAO extends AbstractDAO<SonarScanInfoEntity> {

  /**
   * Constructor that supplies the factory which created this DAO instance.
   * 
   * @param factory that created this DAO
   */
  SonarScanInfoDAO(DAOFactory factory) {
    super(factory);
  }

  /**
   * @see com.travelport.otm.odaudit.dao.AbstractDAO#getEntityType()
   */
  @Override
  protected Class<SonarScanInfoEntity> getEntityType() {
    return SonarScanInfoEntity.class;
  }

  /**
   * Delete operation is not supported for sonar_scan_info
   * 
   * @param entity: the entity to be deleted
   * @throws none
   */
  @Override
  public void delete(SonarScanInfoEntity scan) {
    throw new UnsupportedOperationException("delete");
  }
}
