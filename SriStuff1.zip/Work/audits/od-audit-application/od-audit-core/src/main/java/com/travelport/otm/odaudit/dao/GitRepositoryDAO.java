/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import com.travelport.otm.odaudit.model.GitRepositoryEntity;

/**
 * DAO that provides operations related to the creation, retrieval, and management of
 * <code>GitRepository</code> entities.
 */
public class GitRepositoryDAO extends AbstractDAO<GitRepositoryEntity> {

  /**
   * Constructor that supplies the factory which created this DAO instance.
   * 
   * @param factory the factory that created this DAO
   */
  GitRepositoryDAO(DAOFactory factory) {
    super(factory);
  }

  /**
   * @see com.travelport.otm.odaudit.dao.AbstractDAO#getEntityType()
   */
  @Override
  protected Class<GitRepositoryEntity> getEntityType() {
    return GitRepositoryEntity.class;
  }

  /**
   * Returns the Git repository with the specified URL and team id or null if no such group exists.
   * 
   * @param ptId: the ID of the project team
   * @param repositoryUrl the name of the repository to retrieve
   * @return List<GitRepository>
   * @throws None
   */
  public GitRepositoryEntity findByRepositoryUrlPtId(long ptId, String repositoryUrl) {
    TypedQuery<GitRepositoryEntity> query = getEntityManager()
        .createNamedQuery("gitRepositoryFindByUrlPtId", GitRepositoryEntity.class);
    List<GitRepositoryEntity> repoList;
    GitRepositoryEntity repository = null;

    query.setParameter("rUrl", repositoryUrl);
    query.setParameter("ptId", ptId);
    repoList = query.getResultList();

    if (!repoList.isEmpty()) {
      repository = repoList.get(0);
    }
    return repository;
  }

  /**
   * Returns list of Git repository objects with the specified URL or null if no such group exists.
   * 
   * @param repositoryUrl the name of the repository to retrieve
   * @return List<GitRepository>
   * @throws None
   */
  public List<GitRepositoryEntity> findByRepositoryUrl(String repositoryUrl) {
    TypedQuery<GitRepositoryEntity> query =
        getEntityManager().createNamedQuery("gitRepositoryFindByUrl", GitRepositoryEntity.class);

    query.setParameter("rUrl", repositoryUrl);
    return query.getResultList();
  }

  /**
   * Returns list of all Git repositories, and null if none exists.
   * 
   * @param None
   * @return List<GitRepository>
   * @throws None
   */
  public List<GitRepositoryEntity> findAll() {
    TypedQuery<GitRepositoryEntity> query =
        getEntityManager().createNamedQuery("findAllRepositories", GitRepositoryEntity.class);

    return query.getResultList();
  }

  /**
   * Returns all Git repository records for a given project team id or null if no records found
   * 
   * @param ptId: the ID of the project team
   * @return List<GitRepository>
   * @throws None
   */
  public List<GitRepositoryEntity> findByPtId(long ptId) {
    TypedQuery<GitRepositoryEntity> query =
        getEntityManager().createNamedQuery("findRepositoriesForPt", GitRepositoryEntity.class);

    query.setParameter("ptId", ptId);
    return query.getResultList();
  }

  /**
   * @see com.travelport.otm.odaudit.dao.AbstractDAO#delete(com.travelport.otm.odaudit.model.PersistentEntity)
   */
  @Override
  public void delete(GitRepositoryEntity entity) {
    entity.setDeleted(true);
    getEntityManager().merge(entity);
    DAOFactory.invalidateCollectionCache();
  }

  /**
   * @see com.travelport.otm.odaudit.dao.AbstractDAO#checkForDuplicate(com.travelport.otm.odaudit.model.PersistentEntity)
   */
  @Override
  protected void checkForDuplicate(GitRepositoryEntity repository) throws DAOException {
    if ((repository != null) && (repository.getProjectTeam() != null)) {
      GitRepositoryEntity otherRepository = findByRepositoryUrlPtId(
          repository.getProjectTeam().getId(), repository.getRepositoryUrl());
      boolean isDuplicate;

      if (repository.getId() < 0) { // create
        isDuplicate = (otherRepository != null);

      } else { // update
        isDuplicate = (otherRepository != null) && (repository.getId() != otherRepository.getId());
      }
      if (isDuplicate) {
        throw new DAOException("A Git repository with the same URL as '"
            + repository.getRepositoryName() + "' already exists in this project team.");
      }
    }
  }

}
