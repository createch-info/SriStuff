/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * Represents common information for sonar scans
 */
@Entity
@Table(name = "sonar_scan_info")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "daoCache")
public class SonarScanInfoEntity implements PersistentEntity {

  private static final long serialVersionUID = 201711201433L;

  @Id
  @Column(name = "id", nullable = false)
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id = -1L;

  @Column(name = "bugs")
  private Float bugs;

  @Column(name = "vulnerabilities")
  private Float vulnerabilities;

  @Column(name = "tech_debt")
  private Float techDebt;

  @Column(name = "code_coverage")
  private Float codeCoverage;

  @Column(name = "complexity")
  private Float complexity;

  @Column(name = "code_smells")
  private Float codeSmells;

  @Column(name = "lines_of_code")
  private int linesOfCode;

  /**
   * Returns the unique ID of this persistent entity.
   *
   * @return long
   */
  public long getId() {
    return id;
  }

  /**
   * Assigns the unique ID of this persistent entity.
   *
   * @param id the unique ID value to assign
   */
  public void setId(long id) {
    this.id = id;
  }

  /**
   * Returns # of bugs from a sonar scan
   *
   * @return Float
   */
  public Float getBugs() {
    return bugs;
  }

  /**
   * Assigns # of bugs for a sonar scan
   *
   * @param # of bugs to assign
   */
  public void setBugs(Float bugs) {
    this.bugs = bugs;
  }

  /**
   * Returns # of vulnerabilities from a sonar scan
   *
   * @return Float
   */
  public Float getVulnerabilities() {
    return vulnerabilities;
  }

  /**
   * Assigns # of vulnerabilities for a sonar scan
   *
   * @param # of vulnerabilities to assign
   */
  public void setVulnerabilities(Float vulnerabilities) {
    this.vulnerabilities = vulnerabilities;
  }

  /**
   * Returns technical debt (minutes) from the sonar scan
   *
   * @return Float
   */
  public Float getTechDebt() {
    return techDebt;
  }

  /**
   * Assigns technical debt (minutes) for a sonar scan
   *
   * @param technical debt to assign
   */
  public void setTechDebt(Float techDebt) {
    this.techDebt = techDebt;
  }

  /**
   * Returns code coverage (%) from the sonar scan
   *
   * @return Float
   */
  public Float getCodeCoverage() {
    return codeCoverage;
  }

  /**
   * Assigns code coverage (%) for a sonar scan
   *
   * @param code coverage % to assign
   */
  public void setCodeCoverage(Float codeCoverage) {
    this.codeCoverage = codeCoverage;
  }

  /**
   * Returns complexity for a sonar scan
   *
   * @return Float
   */
  public Float getComplexity() {
    return complexity;
  }

  /**
   * Assigns complexity for a sonar scan
   *
   * @param max complexity to assign
   */
  public void setComplexity(Float complexity) {
    this.complexity = complexity;
  }

  /**
   * Returns code smells for a sonar scan
   *
   * @return Float
   */
  public Float getCodeSmells() {
    return codeSmells;
  }

  /**
   * Assigns code smells for a sonar scan
   *
   * @param average complexity to assign
   */
  public void setCodeSmells(Float codeSmells) {
    this.codeSmells = codeSmells;
  }

  /**
   * Returns lines of code for a sonar scan
   *
   * @return int
   */
  public int getLinesOfCode() {
    return linesOfCode;
  }

  /**
   * Assigns lines of code for a sonar scan
   *
   * @param lines of code to assign
   */
  public void setLinesOfCode(int linesOfCode) {
    this.linesOfCode = linesOfCode;
  }
}
