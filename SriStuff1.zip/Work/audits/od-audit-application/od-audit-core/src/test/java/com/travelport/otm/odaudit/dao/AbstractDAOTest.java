/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/

package com.travelport.otm.odaudit.dao;

import java.io.File;
import java.sql.Date;
import java.util.Calendar;

import org.junit.AfterClass;
import org.junit.BeforeClass;

import com.travelport.otm.odaudit.model.GitBucketGroupEntity;
import com.travelport.otm.odaudit.model.GitRepositoryEntity;
import com.travelport.otm.odaudit.model.ODScanEntity;
import com.travelport.otm.odaudit.model.OdProgramReportEntity;
import com.travelport.otm.odaudit.model.OrganizationEntity;
import com.travelport.otm.odaudit.model.OrganizationReportEntity;
import com.travelport.otm.odaudit.model.ProjectTeamEntity;
import com.travelport.otm.odaudit.model.ProjectTeamReportEntity;
import com.travelport.otm.odaudit.model.RepositoryReportEntity;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;
import com.travelport.otm.odaudit.model.SonarThresholdsEntity;
import com.travelport.otm.odaudit.type.RepositoryType;
import com.travelport.otm.odaudit.type.ScanType;

/**
 * Base test class that starts a in-memory database that can be used by the <code>DAOFactory</code>
 * for mock persistent storage.
 */
public abstract class AbstractDAOTest {

  // Defaults to create entities
  protected static final String TEST_ORG_NAME = "OD-Audit test org";
  protected static final long TEST_ORG_ID = 1000L;
  protected static final String TEST_PT_NAME = "OD-Audit test PT";
  protected static final long TEST_PT_ID = 1001L;
  protected static final String TEST_GB_GROUP_NAME = "OD-Audit test GB group";
  protected static final String TEST_GIT_REPO_BASE_URL = "https://gitbucket.tvlport.com/git/TEST/";
  protected static final String TEST_GIT_REPO_URL = "GitRepositoryDAOTest-testDuplicateCreate.git";
  protected static final String REPO_URL_UPD_SUFFIX = "GitRepositoryDAOTest-testUpdate-UPDATED.git";
  protected static final String REPO_URL_INVALID_SUFFIX = "GitRepositoryDAOTest-testInvalidUrl.git";
  protected static final String TEST_GIT_PROJECT_KEY = "od.audit.test.project.key";
  protected static final String TEST_BRANCH_NAME = "develop";
  protected static final Date TEST_TODAY =
      new java.sql.Date(Calendar.getInstance().getTimeInMillis());
  protected static final Date TEST_UPD_DATE = Date.valueOf("2017-11-01");

  protected static final String UPDATE_SUFFIX = " (UPDATED)";

  // Default values for sonar scans
  private static final float TEST_BUGS = 10;
  private static final float TEST_VULNERABILITIES = 20;
  private static final float TEST_TECH_DEBT = 180;
  private static final float TEST_CODE_COVERAGE = 60;
  private static final float TEST_COMPLEXITY = 15;
  private static final float TEST_CODE_SMELLS = 20;

  // Default values for sonar thresholds
  private static final float TEST_BUGS_LOW = 10;
  private static final float TEST_BUGS_HIGH = 30;
  private static final float TEST_VULNERABILITIES_LOW = 10;
  private static final float TEST_VULNERABILITIES_HIGH = 30;
  private static final float TEST_CODE_SMELLS_LOW = 10;
  private static final float TEST_CODE_SMELLS_HIGH = 30;
  private static final float TEST_TECH_DEBT_LOW = 10;
  private static final float TEST_TECH_DEBT_HIGH = 30;
  private static final float TEST_COMPLEXITY_LOW = 10;
  private static final float TEST_COMPLEXITY_HIGH = 30;
  private static final float TEST_CODE_COVERAGE_LOW = 10;
  private static final float TEST_CODE_COVERAGE_HIGH = 30;

  private static final File createDdlScript =
      new File(System.getProperty("user.dir"), "/src/main/ddl/create_ddl_odaudit.sql");

  private static MockDBManager mockDB;

  protected static DAOFactory daoFactory = new DAOFactory();

  @BeforeClass
  public static void setupDatabase() throws Exception {
    mockDB = new MockDBManager();
    mockDB.start();
    mockDB.runScript(createDdlScript);
    DAOFactory.setJpaPersistenceUnit("com.travelport.otm.odaudit.mock");
    DAOFactory.initializeJPAServices();
    daoFactory = new DAOFactory();
  }

  @AfterClass
  public static void shutdownDatabase() throws Exception {
    DAOFactory.shutdownJPAServices();
    Thread.sleep(100);
    mockDB.shutdown();
  }

  protected OrganizationEntity createOrganization() throws Exception {
    return createOrganization(TEST_ORG_NAME);
  }

  protected OrganizationEntity createOrganization(String orgName) throws Exception {
    boolean success = false;
    try {
      OrganizationDAO dao = daoFactory.newOrganizationDAO();
      OrganizationEntity org = new OrganizationEntity();
      org.setName(orgName);

      daoFactory.beginTransaction();
      dao.create(org);
      daoFactory.commitTransaction();
      success = true;
      return org;
    } finally {
      if (!success) {
        daoFactory.rollbackTransaction();
      }
    }
  }

  protected OrganizationEntity fetchOrganization(Long orgId) throws Exception {
    OrganizationEntity org = null;

    if (orgId == null) {
      org = createOrganization(TEST_ORG_NAME);
    } else {
      OrganizationDAO dao = daoFactory.newOrganizationDAO();
      org = dao.findById(orgId);
    }
    return org;
  }

  protected ProjectTeamEntity createProjectTeam() throws Exception {
    return createProjectTeam(TEST_PT_NAME, null);
  }

  protected ProjectTeamEntity createProjectTeam(String teamName, Long orgId) throws Exception {
    boolean success = false;
    try {
      OrganizationEntity org = fetchOrganization(orgId);
      ProjectTeamDAO dao = daoFactory.newProjectTeamDAO();
      ProjectTeamEntity team = new ProjectTeamEntity();
      team.setName(teamName);

      daoFactory.beginTransaction();
      team.setOrganization(org);
      dao.create(team);
      daoFactory.commitTransaction();

      success = true;
      return team;
    } finally {
      if (!success) {
        daoFactory.rollbackTransaction();
      }
    }
  }

  protected ProjectTeamEntity fetchProjectTeam(Long ptId) throws Exception {
    ProjectTeamEntity pt = null;

    if (ptId == null) {
      pt = createProjectTeam();
    } else {
      ProjectTeamDAO dao = daoFactory.newProjectTeamDAO();
      pt = dao.findById(ptId);
    }
    return pt;
  }

  protected GitBucketGroupEntity createGitBucketGroup() throws Exception {
    return createGitBucketGroup(TEST_GB_GROUP_NAME, null);
  }

  protected GitBucketGroupEntity createGitBucketGroup(String groupName, Long ptId)
      throws Exception {
    boolean success = false;
    try {
      GitBucketGroupDAO groupDao = daoFactory.newGitBucketGroupDAO();
      GitBucketGroupEntity group = new GitBucketGroupEntity();

      ProjectTeamEntity team = fetchProjectTeam(ptId);

      daoFactory.beginTransaction();
      group.setGroupName(groupName);
      group.setProjectTeam(team);
      groupDao.create(group);
      daoFactory.commitTransaction();
      success = true;
      return group;

    } finally {
      if (!success) {
        daoFactory.rollbackTransaction();
      }
    }
  }

  protected GitRepositoryEntity createGitRepository() throws Exception {
    return createGitRepository(TEST_GIT_REPO_URL, TEST_GIT_REPO_BASE_URL, TEST_GIT_PROJECT_KEY,
        null);
  }

  protected GitRepositoryEntity createGitRepositoryWithOrgAndPt() throws Exception {
    OrganizationEntity org = createOrganization(TEST_ORG_NAME);
    ProjectTeamEntity pt = createProjectTeam(TEST_PT_NAME, org.getId());
    return createGitRepository(TEST_GIT_REPO_URL, TEST_GIT_REPO_BASE_URL, TEST_GIT_PROJECT_KEY,
        pt.getId());
  }

  protected GitRepositoryEntity createGitRepository(String repoName, String repoUrl,
      String projectKey, Long ptId) throws Exception {
    boolean success = false;
    try {
      ProjectTeamEntity team = fetchProjectTeam(ptId);

      GitRepositoryEntity repo = new GitRepositoryEntity();
      GitRepositoryDAO dao = daoFactory.newGitRepositoryDAO();
      daoFactory.beginTransaction();
      repo.setRepositoryUrl(repoUrl);
      repo.setRepositoryName(repoName);
      repo.setProjectKey(projectKey);
      repo.setType(RepositoryType.TEST);
      repo.setProjectTeam(team);
      repo.setBranch(TEST_BRANCH_NAME);
      dao.create(repo);
      daoFactory.commitTransaction();
      success = true;
      return repo;
    } finally {
      if (!success) {
        daoFactory.rollbackTransaction();
      }
    }
  }

  protected ODScanEntity createOdScan() throws Exception {
    GitRepositoryEntity repo = createGitRepository();
    return createOdScan(TEST_TODAY, ScanType.SONAR, repo, null);
  }

  protected ODScanEntity createOdScan(Date scanDate, ScanType scanType, GitRepositoryEntity repo,
      SonarScanInfoEntity scanInfo) throws Exception {
    boolean success = false;
    try {
      ODScanEntity odScan = new ODScanEntity();
      ODScanDAO dao = daoFactory.newODScanDAO();
      daoFactory.beginTransaction();
      odScan.setScanDate(scanDate);
      odScan.setScanType(scanType);
      odScan.setGitRepository(repo);
      odScan.setSonarScanInfo(scanInfo);
      dao.create(odScan);
      daoFactory.commitTransaction();
      success = true;
      return odScan;
    } finally {
      if (!success) {
        daoFactory.rollbackTransaction();
      }
    }
  }

  protected SonarScanInfoEntity createSonarScanInfo() throws Exception {
    return createSonarScanInfo(TEST_BUGS, TEST_VULNERABILITIES, TEST_TECH_DEBT, TEST_CODE_COVERAGE,
        TEST_COMPLEXITY, TEST_CODE_SMELLS);
  }

  protected SonarScanInfoEntity createSonarScanInfo(Float bugs, Float vulnerabilities,
      Float techDebt, Float codeCoverage, float complexity, float codeSmells) throws Exception {
    boolean success = false;
    try {
      SonarScanInfoDAO dao = daoFactory.newSonarScanInfoDAO();
      SonarScanInfoEntity sonarScan = new SonarScanInfoEntity();

      daoFactory.beginTransaction();
      sonarScan.setBugs(bugs);
      sonarScan.setVulnerabilities(vulnerabilities);
      sonarScan.setTechDebt(techDebt);
      sonarScan.setCodeCoverage(codeCoverage);
      sonarScan.setComplexity(complexity);
      sonarScan.setCodeSmells(codeSmells);
      dao.create(sonarScan);
      daoFactory.commitTransaction();
      success = true;
      return sonarScan;

    } finally {
      if (!success) {
        daoFactory.rollbackTransaction();
      }
    }
  }

  protected OdProgramReportEntity createOdProgramReport() throws Exception {
    boolean success = false;
    try {
      OdProgramReportEntity prReport = new OdProgramReportEntity();
      SonarScanInfoEntity sonarScan = createSonarScanInfo();
      OdProgramReportDAO dao = daoFactory.newOdProgramReportDAO();

      daoFactory.beginTransaction();
      prReport.setOdReportDate(TEST_TODAY);
      prReport.setSonarScanInfo(sonarScan);
      dao.create(prReport);
      daoFactory.commitTransaction();
      success = true;
      return prReport;
    } finally {
      if (!success) {
        daoFactory.rollbackTransaction();
      }
    }
  }

  protected RepositoryReportEntity createRepositoryReport() throws Exception {
    boolean success = false;
    try {
      RepositoryReportEntity repoReport = new RepositoryReportEntity();
      SonarScanInfoEntity sonarScan = createSonarScanInfo();
      OdProgramReportEntity prReport = createOdProgramReport();
      ODScanEntity odScan = createOdScan();
      RepositoryReportDAO dao = daoFactory.newRepositoryReportDAO();

      daoFactory.beginTransaction();
      repoReport.setReportDate(TEST_TODAY);
      repoReport.setSonarScanInfo(sonarScan);
      repoReport.setOdScan(odScan);
      repoReport.setOdProgramReport(prReport);
      dao.create(repoReport);
      daoFactory.commitTransaction();
      success = true;
      return repoReport;
    } finally {
      if (!success) {
        daoFactory.rollbackTransaction();
      }
    }
  }

  protected ProjectTeamReportEntity createProjectTeamReport() throws Exception {
    boolean success = false;
    try {
      ProjectTeamReportEntity ptReport = new ProjectTeamReportEntity();
      SonarScanInfoEntity sonarScan = createSonarScanInfo();
      OdProgramReportEntity prReport = createOdProgramReport();
      ProjectTeamEntity team = createProjectTeam();
      ProjectTeamReportDAO dao = daoFactory.newProjectTeamReportDAO();

      daoFactory.beginTransaction();
      ptReport.setPtReportDate(TEST_TODAY);
      ptReport.setSonarScanInfo(sonarScan);
      ptReport.setOdProgramReport(prReport);
      ptReport.setProjectTeam(team);
      dao.create(ptReport);
      daoFactory.commitTransaction();
      success = true;
      return ptReport;
    } finally {
      if (!success) {
        daoFactory.rollbackTransaction();
      }
    }
  }

  protected OrganizationReportEntity createOrganizationReport() throws Exception {
    boolean success = false;
    try {
      OrganizationReportEntity orgReport = new OrganizationReportEntity();
      SonarScanInfoEntity sonarScan = createSonarScanInfo();
      OdProgramReportEntity prReport = createOdProgramReport();
      OrganizationEntity org = createOrganization();
      OrganizationReportDAO dao = daoFactory.newOrganizationReportDAO();

      daoFactory.beginTransaction();
      orgReport.setOrgReportDate(TEST_TODAY);
      orgReport.setSonarScanInfo(sonarScan);
      orgReport.setOdProgramReport(prReport);
      orgReport.setOrganization(org);
      dao.create(orgReport);
      daoFactory.commitTransaction();
      success = true;
      return orgReport;
    } finally {
      if (!success) {
        daoFactory.rollbackTransaction();
      }
    }
  }

  public static SonarThresholdsEntity createSonarThresholds() throws Exception {
    boolean success = false;
    try {
      SonarThresholdsEntity thresholds = new SonarThresholdsEntity();
      SonarThresholdsDAO thresholdsDao = daoFactory.newSonarThresholdsDAO();

      daoFactory.beginTransaction();
      thresholds.setBugsLow(TEST_BUGS_LOW);
      thresholds.setBugsHigh(TEST_BUGS_HIGH);
      thresholds.setVulnerabilitiesLow(TEST_VULNERABILITIES_LOW);
      thresholds.setVulnerabilitiesHigh(TEST_VULNERABILITIES_HIGH);
      thresholds.setCodeSmellsLow(TEST_CODE_SMELLS_LOW);
      thresholds.setCodeSmellsHigh(TEST_CODE_SMELLS_HIGH);
      thresholds.setTechDebtLow(TEST_TECH_DEBT_LOW);
      thresholds.setTechDebtHigh(TEST_TECH_DEBT_HIGH);
      thresholds.setComplexityLow(TEST_COMPLEXITY_LOW);
      thresholds.setComplexityHigh(TEST_COMPLEXITY_HIGH);
      thresholds.setCodeCoverageLow(TEST_CODE_COVERAGE_LOW);
      thresholds.setCodeCoverageHigh(TEST_CODE_COVERAGE_HIGH);
      thresholds.setActive(true);
      thresholds.setEffectiveDate(TEST_TODAY);
      thresholdsDao.create(thresholds);
      daoFactory.commitTransaction();
      success = true;
      return thresholds;
    } finally {
      if (!success) {
        daoFactory.rollbackTransaction();
      }
    }
  }

  protected void deleteOrgIfExists() throws DAOException {
    boolean success = false;
    try {
      OrganizationDAO dao = daoFactory.newOrganizationDAO();

      daoFactory.beginTransaction();
      OrganizationEntity org = dao.findByName(TEST_ORG_NAME);
      if (org != null) {
        dao.delete(org);
      }

      OrganizationEntity orgUpd = dao.findByName(TEST_ORG_NAME + UPDATE_SUFFIX);
      if (orgUpd != null) {
        dao.delete(orgUpd);
      }
      daoFactory.commitTransaction();
      success = true;
    } finally {
      if (!success) {
        daoFactory.rollbackTransaction();
      }
    }
  }
}
