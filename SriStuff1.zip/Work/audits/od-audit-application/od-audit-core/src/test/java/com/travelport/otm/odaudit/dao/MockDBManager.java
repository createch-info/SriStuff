/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.hsqldb.persist.HsqlProperties;
import org.hsqldb.server.Server;

/**
 * Creates an in-memory JDBC database that can be used for mock testing.
 */
public class MockDBManager {

  private static final String DEFAULT_DELIMITER = ";";
  private static final Pattern ID_COLUMN_PATTERN =
      Pattern.compile("\\s*id\\s+BIGINT\\s+NOT\\s+NULL\\s+AUTO_INCREMENT,");
  private static final Pattern NEW_DELIMITER_PATTERN =
      Pattern.compile("(?:--|\\/\\/|\\#)?!DELIMITER=(.+)");
  private static final Pattern COMMENT_PATTERN = Pattern.compile("^(?:--|\\/\\/|\\#).+");

  private Server dbServer;

  public void start() throws Exception {
    HsqlProperties dbProps = new HsqlProperties();

    dbProps.setProperty("server.database.0", "mem:mockDB");
    dbProps.setProperty("server.dbname.0", "mockDB");
    dbProps.setProperty("server.remote_open", true);

    dbServer = new org.hsqldb.Server();
    dbServer.setProperties(dbProps);
    dbServer.setSilent(true);
    dbServer.setRestartOnShutdown(false);
    dbServer.setLogWriter(null);
    dbServer.start();
  }

  public void shutdown() throws Exception {
    Connection connection = getConnection();
    Statement statement = connection.createStatement();

    statement.execute("DROP SCHEMA PUBLIC CASCADE");
    statement.close();
    connection.close();
    dbServer.shutdown();
  }

  public Connection getConnection() throws Exception {
    Class.forName("org.hsqldb.jdbcDriver");
    return DriverManager.getConnection("jdbc:hsqldb:mem:mockDB", "SA", "");
  }

  public void runScript(File sqlScript) throws Exception {
    Connection connection = null;

    try (BufferedReader scriptReader =
        new BufferedReader(new InputStreamReader(new FileInputStream(sqlScript)))) {
      StringBuffer command = null;
      String delimiter = DEFAULT_DELIMITER;
      String line = null;

      connection = getConnection();

      while ((line = scriptReader.readLine()) != null) {
        if (command == null) {
          command = new StringBuffer();
        }

        String trimmedLine = line.trim();

        Matcher delimiterMatcher = NEW_DELIMITER_PATTERN.matcher(trimmedLine);
        Matcher commentMatcher = COMMENT_PATTERN.matcher(trimmedLine);
        Matcher idColumnMatcher = ID_COLUMN_PATTERN.matcher(trimmedLine);

        if (idColumnMatcher.find()) {
          trimmedLine = "  id BIGINT IDENTITY NOT NULL AUTO_INCREMENT,";
        }

        // a) Delimiter change
        if (delimiterMatcher.find()) {
          delimiter = delimiterMatcher.group(1);
        }

        // b) Comment
        else if (commentMatcher.find()) {
        }

        // c) Statement
        else {
          command.append(trimmedLine);
          command.append(" ");

          // End of statement
          if (trimmedLine.endsWith(delimiter)) {
            String commandStr = convertMySQLtoHSQLDB(command.toString());

            if (commandStr != null) {
              Statement statement = connection.createStatement();

              statement.execute(commandStr);
              statement.close();
            }
            command = null;
          }
        }
      }
    } finally {
      if (connection != null)
        connection.close();
    }
  }

  /**
   * Converts the given SQL statement from MySQL syntax to HSQLDB. If no HSQLDB equivalent exists,
   * null will be returned.
   * 
   * @param mysqlStatement the MySQL statement to be converted
   * @return String
   */
  private String convertMySQLtoHSQLDB(String mysqlStatement) {
    String hsqldbStr = mysqlStatement.toString().trim();

    while (hsqldbStr.startsWith("#")) {
      hsqldbStr = hsqldbStr.substring(1).trim();
    }
    hsqldbStr = hsqldbStr.replaceAll("\\s+AUTO_INCREMENT", "");

    if (hsqldbStr.indexOf("INSERT INTO") >= 0) {
      hsqldbStr = null;

    } else if (hsqldbStr.indexOf("hibernate_sequence") >= 0) {
      hsqldbStr = "CREATE SEQUENCE hibernate_sequence AS BIGINT START WITH 1000";
    }
    return hsqldbStr;
  }

}
