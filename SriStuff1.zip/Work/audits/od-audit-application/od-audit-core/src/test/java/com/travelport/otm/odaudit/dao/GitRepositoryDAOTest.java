/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.travelport.otm.odaudit.model.GitRepositoryEntity;
import com.travelport.otm.odaudit.model.ProjectTeamEntity;
import com.travelport.otm.odaudit.type.RepositoryType;
import com.travelport.otm.odaudit.validation.ValidationException;

/**
 * Verifies the functions of the <code>GitRepositoryDAO</code> class.
 */
public class GitRepositoryDAOTest extends AbstractDAOTest {

  private GitRepositoryDAO dao;

  @Before
  public void setup() {
    dao = daoFactory.newGitRepositoryDAO();
  }

  @After
  public void tearDown() throws DAOException {

    // After each test, delete default org if it exists
    deleteOrgIfExists();
    deleteTestRepoIfExists();
    dao = null;
  }

  @Test
  public void testCreate() throws Exception {
    GitRepositoryEntity repo = createGitRepository();

    assertNotNull(repo);
    assertTrue(repo.getId() >= 0);
  }

  @Test
  public void testUpdate() throws Exception {
    boolean success = false;
    try {
      GitRepositoryEntity repository = createGitRepository();

      daoFactory.beginTransaction();
      repository.setRepositoryName(REPO_URL_UPD_SUFFIX);
      repository.setRepositoryUrl(TEST_GIT_REPO_BASE_URL + REPO_URL_UPD_SUFFIX);
      dao.update(repository);
      daoFactory.commitTransaction();

      daoFactory.beginTransaction();
      repository = dao.get(repository.getId());
      assertEquals(REPO_URL_UPD_SUFFIX, repository.getRepositoryName());
      daoFactory.commitTransaction();
      success = true;

    } finally {
      if (!success) {
        daoFactory.rollbackTransaction();
      }
    }
  }

  @Test(expected = DAOException.class)
  public void testDuplicateCreate() throws Exception {
    GitRepositoryEntity repo = createGitRepository();

    assertNotNull(repo);
    createGitRepository(repo.getRepositoryName(), repo.getRepositoryUrl(), repo.getProjectKey(),
        repo.getProjectTeam().getId());
  }

  @Test(expected = ValidationException.class)
  public void testInvalidName() throws Exception {
    createGitRepository(null, null, null, null);
  }

  @Test(expected = ValidationException.class)
  public void testInvalidProjectTeam() throws Exception {
    GitRepositoryEntity repository = new GitRepositoryEntity();

    repository.setProjectTeam(new ProjectTeamEntity());
    repository.setRepositoryName(null);
    repository.setRepositoryUrl(TEST_GIT_REPO_BASE_URL + REPO_URL_INVALID_SUFFIX);
    repository.setType(RepositoryType.PRODUCTION);
    dao.create(repository);
  }

  @Test(expected = ValidationException.class)
  public void testInvalidUrl() throws Exception {
    GitRepositoryEntity repository = new GitRepositoryEntity();

    repository.setProjectTeam(new ProjectTeamEntity());
    repository.setRepositoryName(REPO_URL_INVALID_SUFFIX);
    repository.setRepositoryUrl(null);
    repository.setType(RepositoryType.PRODUCTION);
    dao.create(repository);
  }

  @Test(expected = ValidationException.class)
  public void testInvalidType() throws Exception {
    GitRepositoryEntity repository = new GitRepositoryEntity();

    repository.setProjectTeam(new ProjectTeamEntity());
    repository.setRepositoryName(REPO_URL_INVALID_SUFFIX);
    repository.setRepositoryUrl(TEST_GIT_REPO_BASE_URL + repository.getRepositoryName());
    repository.setType(null);
    dao.create(repository);
  }

  @Test
  public void testFindByPtId() throws Exception {

    GitRepositoryEntity repo1 = createGitRepositoryWithOrgAndPt();

    String repoName2 = "repoName2";
    String repoUrl2 = "repoUrl2";
    String projectKey2 = "projectKey2";
    GitRepositoryEntity repo2 =
        createGitRepository(repoName2, repoUrl2, projectKey2, repo1.getProjectTeam().getId());

    List<GitRepositoryEntity> repoList = dao.findByPtId(repo1.getProjectTeam().getId());

    assertNotNull(repoList);
    assertTrue(!repoList.isEmpty() && repoList.size() == 2);

    GitRepositoryEntity firstRepo = repoList.get(0);
    assertNotNull(firstRepo);
    assertTrue(TEST_GIT_REPO_BASE_URL.equals(firstRepo.getRepositoryUrl()));
    assertTrue(TEST_GIT_PROJECT_KEY.equals(firstRepo.getProjectKey()));
  }

  protected void deleteTestRepoIfExists() throws DAOException {
    boolean success = false;
    try {
      GitRepositoryDAO dao = daoFactory.newGitRepositoryDAO();

      daoFactory.beginTransaction();
      List<GitRepositoryEntity> repoList = dao.findByRepositoryUrl(TEST_GIT_REPO_URL);
      if (repoList != null && !repoList.isEmpty()) {
        for (GitRepositoryEntity repo : repoList) {
          dao.delete(repo);
        }
      }
      daoFactory.commitTransaction();
      success = true;
    } finally {
      if (!success) {
        daoFactory.rollbackTransaction();
      }
    }
  }
}
