/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.travelport.otm.odaudit.model.GitBucketGroupEntity;
import com.travelport.otm.odaudit.validation.ValidationException;

/**
 * Verifies the functions of the <code>GitBucketGroupDAO</code> class.
 */
public class GitBucketGroupDAOTest extends AbstractDAOTest {

  @Before
  public void setup() {

  }

  @After
  public void tearDown() throws DAOException {

    // After each test, delete default org & cascade if it exists
    deleteOrgIfExists();
  }

  @Test
  public void testCreate() throws Exception {
    GitBucketGroupEntity group = createGitBucketGroup();

    assertNotNull(group);
    assertTrue(group.getId() >= 0);
  }

  @Test
  public void testUpdate() throws Exception {
    boolean success = false;
    try {
      GitBucketGroupEntity group = createGitBucketGroup();
      GitBucketGroupDAO dao = daoFactory.newGitBucketGroupDAO();
      String updatedName = group.getGroupName() + UPDATE_SUFFIX;

      daoFactory.beginTransaction();
      group.setGroupName(updatedName);
      dao.update(group);
      daoFactory.commitTransaction();

      daoFactory.beginTransaction();
      group = dao.get(group.getId());
      assertEquals(updatedName, group.getGroupName());
      daoFactory.commitTransaction();
      success = true;

    } finally {
      if (!success) {
        daoFactory.rollbackTransaction();
      }
    }
  }

  @Test(expected = DAOException.class)
  public void testDuplicateCreate() throws Exception {
    GitBucketGroupEntity group = createGitBucketGroup();

    assertNotNull(group);
    createGitBucketGroup(group.getGroupName(), group.getProjectTeam().getId());
  }

  @Test(expected = ValidationException.class)
  public void testInvalidGroupName() throws Exception {
    createGitBucketGroup(null, null);
  }
}
