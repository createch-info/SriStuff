/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.sql.Date;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.travelport.otm.odaudit.model.KPIRating;
import com.travelport.otm.odaudit.model.OdProgramReportEntity;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;
import com.travelport.otm.odaudit.model.SonarThresholdsEntity;
import com.travelport.otm.odaudit.type.SonarRating;

import mockit.Mock;
import mockit.MockUp;

/**
 * Verifies the functions of the <code>OdProgramReportDAO</code> class.
 */
public class OdProgramReportDAOTest extends AbstractDAOTest {

  private OdProgramReportDAO reportDao;

  @Before
  public void setup() {

    reportDao = daoFactory.newOdProgramReportDAO();
  }

  @After
  public void tearDown() throws Exception {

    reportDao = null;
  }

  @Test
  public void testCreate() throws Exception {
    OdProgramReportEntity report = createOdProgramReport();

    assertNotNull(report);
    assertTrue(report.getId() >= 0);
    assertTrue(report.getOdReportDate().compareTo(TEST_TODAY) == 0);
  }

  @Test(expected = UnsupportedOperationException.class)
  public void testDelete() throws Exception {
    OdProgramReportEntity report = createOdProgramReport();
    reportDao.delete(report);
  }

  @Test
  public void testUpdate() throws Exception {
    OdProgramReportEntity report = createOdProgramReport();

    report.setOdReportDate(TEST_UPD_DATE);
    reportDao.update(report);

    OdProgramReportEntity fetchedReport = reportDao.get(report.getId());
    assertNotNull(fetchedReport);
    assertTrue(report.getOdReportDate().compareTo(TEST_UPD_DATE) == 0);
  }

  @Test
  public void testGetAll() throws Exception {

    createOdProgramReport();
    createOdProgramReport();

    List<OdProgramReportEntity> reportList = reportDao.getAll();

    assertNotNull(reportList);
    assertTrue(reportList.size() > 1);
  }

  @Test
  public void testGetOdPrgRepoRatings() throws Exception {
    OdProgramReportEntity report = createOdProgramReport();
    SonarThresholdsEntity sonarThreshold = createSonarThresholds();

    OdProgramReportEntity reportRatings = reportDao.getOdPrgRepoRatings(report.getId());
    List<KPIRating> kpiRatings = reportRatings.getKpiRatings();
    assertNotNull(kpiRatings);
    for (KPIRating kpiRating : kpiRatings) {
      SonarRating rating = null;
      switch (kpiRating.getKpiType()) {
        case SONAR_BUGS:
          assertEquals(SonarRating.YELLOW, kpiRating.getRating());
          break;
        case SONAR_VULNERABILITIES:
          assertEquals(SonarRating.YELLOW, kpiRating.getRating());
          break;
        case SONAR_TECH_DEBT:
          assertEquals(SonarRating.RED, kpiRating.getRating());
          break;
        case SONAR_CODE_SMELLS:
          assertEquals(SonarRating.YELLOW, kpiRating.getRating());
          break;
        case SONAR_COMPLEXITY:
          assertEquals(SonarRating.YELLOW, kpiRating.getRating());
          break;
        case SONAR_CODE_COVERAGE:
          assertEquals(SonarRating.GREEN, kpiRating.getRating());
          break;
        default:
          break;
      }
    }
  }

  @Test(expected = DAOException.class)
  public void testGetOdPrgRepoRatingsNullSonarThresholds() throws Exception {
    OdProgramReportEntity report = createOdProgramReport();
    new MockUp<SonarThresholdsDAO>() {
      @Mock
      SonarThresholdsEntity fetchSonarThresholdsForEffDate(Date effDate) {
        return null;
      }
    };
    reportDao.getOdPrgRepoRatings(report.getId());
  }

  @Test(expected = DAOException.class)
  public void testGetOdPrgRepoRatingsNullSonarScanInfo() throws Exception {
    OdProgramReportEntity report = createOdProgramReport();
    SonarThresholdsEntity sonarThreshold = createSonarThresholds();
    new MockUp<SonarScanInfoDAO>() {
      @Mock
      SonarScanInfoEntity get(long id) {
        return null;
      }
    };
    reportDao.getOdPrgRepoRatings(report.getId());
  }
}
