/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.sql.Date;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.travelport.otm.odaudit.model.KPIRating;
import com.travelport.otm.odaudit.model.OrganizationReportEntity;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;
import com.travelport.otm.odaudit.model.SonarThresholdsEntity;
import com.travelport.otm.odaudit.type.SonarRating;

import mockit.Mock;
import mockit.MockUp;

/**
 * Verifies the functions of the <code>OrganizationReportDAO</code> class.
 */
public class OrganizationReportDAOTest extends AbstractDAOTest {

  private OrganizationReportDAO reportDao;

  @Before
  public void setup() {

    reportDao = daoFactory.newOrganizationReportDAO();
  }

  @After
  public void tearDown() throws Exception {

    deleteOrgIfExists();
    reportDao = null;
  }

  @Test
  public void testCreate() throws Exception {
    OrganizationReportEntity report = createOrganizationReport();

    assertNotNull(report);
    assertTrue(report.getId() >= 0);
    assertTrue(report.getOrgReportDate().compareTo(TEST_TODAY) == 0);
  }

  @Test(expected = UnsupportedOperationException.class)
  public void testDelete() throws Exception {
    OrganizationReportEntity report = createOrganizationReport();
    reportDao.delete(report);
  }

  @Test
  public void testUpdate() throws Exception {
    OrganizationReportEntity report = createOrganizationReport();

    report.setOrgReportDate(TEST_UPD_DATE);
    reportDao.update(report);

    OrganizationReportEntity fetchedReport = reportDao.get(report.getId());
    assertNotNull(fetchedReport);
    assertTrue(report.getOrgReportDate().compareTo(TEST_UPD_DATE) == 0);
  }

  @Test
  public void testFindByOrgName() throws Exception {

    createOrganizationReport();

    List<OrganizationReportEntity> reportList = reportDao.findByOrgName(TEST_ORG_NAME);

    assertNotNull(reportList);
    OrganizationReportEntity fetchReport = reportList.get(0);
    assertNotNull(fetchReport);
    assertTrue(TEST_ORG_NAME.equals(fetchReport.getOrganization().getName()));
  }

  @Test
  public void testGetOrgReportRatings() throws Exception {
    OrganizationReportEntity report = createOrganizationReport();
    SonarThresholdsEntity sonarThreshold = createSonarThresholds();

    OrganizationReportEntity reportRatings = reportDao.getOrgReportRatings(report.getId());
    List<KPIRating> kpiRatings = reportRatings.getKpiRatings();
    assertNotNull(kpiRatings);
    for (KPIRating kpiRating : kpiRatings) {
      SonarRating rating = null;
      switch (kpiRating.getKpiType()) {
        case SONAR_BUGS:
          assertEquals(SonarRating.YELLOW, kpiRating.getRating());
          break;
        case SONAR_VULNERABILITIES:
          assertEquals(SonarRating.YELLOW, kpiRating.getRating());
          break;
        case SONAR_TECH_DEBT:
          assertEquals(SonarRating.RED, kpiRating.getRating());
          break;
        case SONAR_CODE_SMELLS:
          assertEquals(SonarRating.YELLOW, kpiRating.getRating());
          break;
        case SONAR_COMPLEXITY:
          assertEquals(SonarRating.YELLOW, kpiRating.getRating());
          break;
        case SONAR_CODE_COVERAGE:
          assertEquals(SonarRating.GREEN, kpiRating.getRating());
          break;
        default:
          break;
      }
    }
  }

  @Test(expected = DAOException.class)
  public void testGetOrgReportRatingsNullRepositoryEntity() throws Exception {
    OrganizationReportEntity report = createOrganizationReport();
    reportDao.getOrgReportRatings(report.getId() + 1);
  }


  @Test(expected = DAOException.class)
  public void testGetRepoRatingsNullSonarThresholds() throws Exception {
    OrganizationReportEntity report = createOrganizationReport();
    new MockUp<SonarThresholdsDAO>() {
      @Mock
      SonarThresholdsEntity fetchSonarThresholdsForEffDate(Date effDate) {
        return null;
      }
    };
    reportDao.getOrgReportRatings(report.getId());
  }

  @Test(expected = DAOException.class)
  public void testGetOrgReportRatingsNullSonarScanInfo() throws Exception {
    OrganizationReportEntity report = createOrganizationReport();
    SonarThresholdsEntity sonarThreshold = createSonarThresholds();
    new MockUp<SonarScanInfoDAO>() {
      @Mock
      SonarScanInfoEntity get(long id) {
        return null;
      }
    };
    reportDao.getOrgReportRatings(report.getId());
  }
}
