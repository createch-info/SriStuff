/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.sql.Date;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.travelport.otm.odaudit.model.KPIRating;
import com.travelport.otm.odaudit.model.OrganizationReportEntity;
import com.travelport.otm.odaudit.model.ProjectTeamReportEntity;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;
import com.travelport.otm.odaudit.model.SonarThresholdsEntity;
import com.travelport.otm.odaudit.type.SonarRating;

import mockit.Mock;
import mockit.MockUp;

/**
 * Verifies the functions of the <code>ProjectTeamReportDAO</code> class.
 */
public class ProjectTeamReportDAOTest extends AbstractDAOTest {

  private ProjectTeamReportDAO reportDao;

  @Before
  public void setup() {

    reportDao = daoFactory.newProjectTeamReportDAO();
  }

  @After
  public void tearDown() throws Exception {

    deleteOrgIfExists();
    reportDao = null;
  }

  @Test
  public void testCreate() throws Exception {
    ProjectTeamReportEntity report = createProjectTeamReport();

    assertNotNull(report);
    assertTrue(report.getId() > 0);
    assertTrue(report.getPtReportDate().compareTo(TEST_TODAY) == 0);
  }

  @Test(expected = UnsupportedOperationException.class)
  public void testDelete() throws Exception {
    ProjectTeamReportEntity report = createProjectTeamReport();
    reportDao.delete(report);
  }

  @Test
  public void testUpdate() throws Exception {
    ProjectTeamReportEntity report = createProjectTeamReport();

    report.setPtReportDate(TEST_UPD_DATE);
    reportDao.update(report);

    ProjectTeamReportEntity fetchedReport = reportDao.get(report.getId());
    assertNotNull(fetchedReport);
    assertTrue(report.getPtReportDate().compareTo(TEST_UPD_DATE) == 0);
  }

  @Test
  public void testFindByPtName() throws Exception {

    ProjectTeamReportEntity report = createProjectTeamReport();

    List<ProjectTeamReportEntity> reportList = reportDao.findByPtName(TEST_PT_NAME);

    assertNotNull(reportList);
    ProjectTeamReportEntity fetchReport = reportList.get(0);
    assertNotNull(fetchReport);
    assertTrue(TEST_PT_NAME.equals(fetchReport.getProjectTeam().getName()));
  }

  @Test
  public void testGetProjectTeamRatings() throws Exception {
    ProjectTeamReportEntity report = createProjectTeamReport();
    SonarThresholdsEntity sonarThreshold = createSonarThresholds();
    ProjectTeamReportEntity reportRatings = reportDao.getProjectTeamRatings(report.getId());
    List<KPIRating> kpiRatings = reportRatings.getKpiRatings();
    assertNotNull(kpiRatings);
    for (KPIRating kpiRating : kpiRatings) {
      SonarRating rating = null;
      switch (kpiRating.getKpiType()) {
        case SONAR_BUGS:
          assertEquals(SonarRating.YELLOW, kpiRating.getRating());
          break;
        case SONAR_VULNERABILITIES:
          assertEquals(SonarRating.YELLOW, kpiRating.getRating());
          break;
        case SONAR_TECH_DEBT:
          assertEquals(SonarRating.RED, kpiRating.getRating());
          break;
        case SONAR_CODE_SMELLS:
          assertEquals(SonarRating.YELLOW, kpiRating.getRating());
          break;
        case SONAR_COMPLEXITY:
          assertEquals(SonarRating.YELLOW, kpiRating.getRating());
          break;
        case SONAR_CODE_COVERAGE:
          assertEquals(SonarRating.GREEN, kpiRating.getRating());
          break;
        default:
          break;
      }
    }
  }

  @Test(expected = DAOException.class)
  public void testGetProjectTeamRatingsNullProjectTeamEntity() throws Exception {
    ProjectTeamReportEntity report = createProjectTeamReport();
    reportDao.getProjectTeamRatings(report.getId() + 1);
  }


  @Test(expected = DAOException.class)
  public void testGetRepoRatingsNullSonarThresholds() throws Exception {
    OrganizationReportEntity report = createOrganizationReport();
    new MockUp<SonarThresholdsDAO>() {
      @Mock
      SonarThresholdsEntity fetchSonarThresholdsForEffDate(Date effDate) {
        return null;
      }
    };
    reportDao.getProjectTeamRatings(report.getId());
  }

  @Test(expected = DAOException.class)
  public void testGetRepoRatingsNullSonarScanInfo() throws Exception {
    OrganizationReportEntity report = createOrganizationReport();
    SonarThresholdsEntity sonarThreshold = createSonarThresholds();
    new MockUp<SonarScanInfoDAO>() {
      @Mock
      SonarScanInfoEntity get(long id) {
        return null;
      }
    };
    reportDao.getProjectTeamRatings(report.getId());
  }
}
