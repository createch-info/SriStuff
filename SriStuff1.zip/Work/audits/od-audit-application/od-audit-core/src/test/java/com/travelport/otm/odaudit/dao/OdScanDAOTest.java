/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.time.LocalDate;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.travelport.otm.odaudit.model.GitRepositoryEntity;
import com.travelport.otm.odaudit.model.ODScanEntity;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;
import com.travelport.otm.odaudit.type.ScanType;

/**
 * Verifies the functions of the <code>ODScanDAO</code> class.
 */
public class OdScanDAOTest extends AbstractDAOTest {

  private ODScanDAO odScanDao;

  @Before
  public void setup() {

    odScanDao = daoFactory.newODScanDAO();
  }

  @After
  public void tearDown() throws Exception {

    deleteOrgIfExists();
    odScanDao = null;
  }

  @Test
  public void testCreate() throws Exception {
    ODScanEntity OdScan = createOdScan();

    assertNotNull(OdScan);
    assertTrue(OdScan.getId() >= 0);
    assertNotNull(OdScan.getGitRepository());
    assertTrue(OdScan.getScanDate().compareTo(TEST_TODAY) == 0);
  }

  @Test(expected = UnsupportedOperationException.class)
  public void testDelete() throws Exception {
    ODScanEntity OdScan = createOdScan();
    odScanDao.delete(OdScan);
  }

  @Test
  public void testUpdate() throws Exception {
    ODScanEntity OdScan = createOdScan();

    OdScan.setScanDate(TEST_UPD_DATE);
    OdScan.setScanType(ScanType.FORTIFY);
    odScanDao.update(OdScan);

    ODScanEntity fetchedScan = odScanDao.get(OdScan.getId());
    assertNotNull(fetchedScan);
    assertTrue(ScanType.FORTIFY == fetchedScan.getScanType());
    assertTrue(fetchedScan.getScanDate().compareTo(TEST_UPD_DATE) == 0);
  }

  @Test
  public void testFindLatestScanInfoForGitRepo() throws Exception {

    GitRepositoryEntity repo = createGitRepositoryWithOrgAndPt();

    Float bugs1 = 15.0F;
    Float vulnerabilities1 = 20.0F;
    Float techDebt1 = 25.0F;
    Float coverage1 = 30.0F;
    Float complexity1 = 35.0F;
    Float codeSmells1 = 35.0F;
    SonarScanInfoEntity sonarScan1 = createSonarScanInfo(bugs1, vulnerabilities1, techDebt1,
        coverage1, complexity1, codeSmells1);
    java.sql.Date testDate1 = java.sql.Date.valueOf(LocalDate.now().minusDays(10));
    ODScanEntity odScan1 = createOdScan(testDate1, ScanType.SONAR, repo, sonarScan1);

    Float bugs2 = 40.0F;
    Float vulnerabilities2 = 45.0F;
    Float techDebt2 = 50.0F;
    Float coverage2 = 55.0F;
    Float complexity2 = 60.0F;
    Float codeSmells2 = 60.0F;
    SonarScanInfoEntity sonarScan2 = createSonarScanInfo(bugs2, vulnerabilities2, techDebt2,
        coverage2, complexity2, codeSmells2);
    ODScanEntity odScan2 = createOdScan(TEST_TODAY, ScanType.SONAR, repo, sonarScan2);

    SonarScanInfoEntity scan = odScanDao.findLatestScanInfoForGitRepo(repo.getId());

    assertNotNull(scan);
    assertTrue(scan.getBugs().equals(sonarScan2.getBugs()));
    assertTrue(scan.getVulnerabilities().equals(sonarScan2.getVulnerabilities()));
    assertTrue(scan.getTechDebt().equals(sonarScan2.getTechDebt()));
    assertTrue(scan.getCodeCoverage().equals(sonarScan2.getCodeCoverage()));
    assertTrue(scan.getComplexity().equals(sonarScan2.getComplexity()));
  }
}
