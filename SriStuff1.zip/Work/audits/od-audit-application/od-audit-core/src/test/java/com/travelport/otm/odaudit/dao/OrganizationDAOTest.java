/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.travelport.otm.odaudit.model.OrganizationEntity;
import com.travelport.otm.odaudit.validation.ValidationException;

/**
 * Verifies the functions of the <code>OrganizationDAO</code> class.
 */
public class OrganizationDAOTest extends AbstractDAOTest {

  @Before
  public void setup() {

  }

  @After
  public void tearDown() throws DAOException {

    // After each test, delete default org if it exists
    deleteOrgIfExists();
  }

  @Test
  public void testCreate() throws Exception {
    OrganizationEntity org = createOrganization();

    assertNotNull(org);
    assertTrue(org.getId() >= 0);
  }


  @Test
  public void testUpdate() throws Exception {
    boolean success = false;
    try {
      OrganizationEntity org = createOrganization();
      OrganizationDAO dao = daoFactory.newOrganizationDAO();
      String updatedName = org.getName() + UPDATE_SUFFIX;

      daoFactory.beginTransaction();
      org.setName(updatedName);
      dao.update(org);
      daoFactory.commitTransaction();

      daoFactory.beginTransaction();
      org = dao.get(org.getId());
      assertEquals(updatedName, org.getName());
      daoFactory.commitTransaction();
      success = true;

    } finally {
      if (!success) {
        daoFactory.rollbackTransaction();
      }
    }
  }

  @Test(expected = DAOException.class)
  public void testDuplicateCreate() throws Exception {
    OrganizationEntity org = createOrganization();

    assertNotNull(org);
    createOrganization(org.getName());
  }

  @Test(expected = ValidationException.class)
  public void testInvalidName() throws Exception {
    createOrganization(null);
  }
}
