/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.utils;


import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.travelport.otm.odaudit.dao.AbstractDAOTest;
import com.travelport.otm.odaudit.model.SonarScanInfoEntity;
import com.travelport.otm.odaudit.model.SonarThresholdsEntity;
import com.travelport.otm.odaudit.type.KPIType;
import com.travelport.otm.odaudit.type.SonarRating;
import com.travelport.otm.odaudit.util.ODAuditUtils;

/**
 * Verifies the functions of the <code>RepositoryReportDAO</code> class.
 */
public class ODAuditUtilsTest extends AbstractDAOTest {
  SonarThresholdsEntity sonarThresholds;
  SonarScanInfoEntity scanInfo;
  public static final float LOWVALUE = 10;
  public static final float HIGHVALUE = 50;
  public static final float DENOMINATOR = 2;

  @Before
  public void setup() throws Exception {
    sonarThresholds = createSonarThresholds();
    scanInfo = new SonarScanInfoEntity();
  }

  @Test
  public void ComputeRatingNullTest() throws Exception {
    SonarRating rating = ODAuditUtils.computeRating(true, HIGHVALUE, LOWVALUE, null);
    assertEquals(SonarRating.RED, rating);
  }

  @Test
  public void getKPIRatingBugsRedTest() throws Exception {
    scanInfo.setBugs((float) HIGHVALUE * DENOMINATOR);
    SonarRating rating = ODAuditUtils.getKPIRating(KPIType.SONAR_BUGS, sonarThresholds, scanInfo);
    assertEquals(SonarRating.RED, rating);
  }

  @Test
  public void getKPIRatingBugsYellowTest() throws Exception {
    scanInfo.setBugs((float) HIGHVALUE / DENOMINATOR);
    SonarRating rating = ODAuditUtils.getKPIRating(KPIType.SONAR_BUGS, sonarThresholds, scanInfo);
    assertEquals(SonarRating.YELLOW, rating);
  }

  @Test
  public void getKPIRatingBugsGreenTest() throws Exception {
    scanInfo.setBugs((float) LOWVALUE / DENOMINATOR);
    SonarRating rating = ODAuditUtils.getKPIRating(KPIType.SONAR_BUGS, sonarThresholds, scanInfo);
    assertEquals(SonarRating.GREEN, rating);
  }

  @Test
  public void getKPIRatingCodeCoverageRedTest() throws Exception {
    scanInfo.setCodeCoverage((float) LOWVALUE / DENOMINATOR);
    SonarRating rating =
        ODAuditUtils.getKPIRating(KPIType.SONAR_CODE_COVERAGE, sonarThresholds, scanInfo);
    assertEquals(SonarRating.RED, rating);
  }

  @Test
  public void getKPIRatingCodeCoverageYellowTest() throws Exception {
    scanInfo.setCodeCoverage((float) HIGHVALUE / DENOMINATOR);
    SonarRating rating =
        ODAuditUtils.getKPIRating(KPIType.SONAR_CODE_COVERAGE, sonarThresholds, scanInfo);
    assertEquals(SonarRating.YELLOW, rating);
  }


  @Test
  public void getKPIRatingCodeCoverageGreenTest() throws Exception {
    scanInfo.setCodeCoverage((float) HIGHVALUE * DENOMINATOR);
    SonarRating rating =
        ODAuditUtils.getKPIRating(KPIType.SONAR_CODE_COVERAGE, sonarThresholds, scanInfo);
    assertEquals(SonarRating.GREEN, rating);
  }


  @Test
  public void getKPIRatingLineOFCodeTest() throws Exception {
    scanInfo.setLinesOfCode((int) HIGHVALUE);
    SonarRating rating =
        ODAuditUtils.getKPIRating(KPIType.SONAR_LINES_OF_CODE, sonarThresholds, scanInfo);
    assertEquals(null, rating);
  }

}
