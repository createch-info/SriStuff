/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.sql.Date;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.travelport.otm.odaudit.model.SonarThresholdsEntity;

/**
 * Verifies the functions of the <code>ProjectTeamDAO</code> class.
 */
public class SonarThresholdsDAOTest extends AbstractDAOTest {

  // Default values for sonar scan thresholds
  private static final int TEST_BUGS_LOW = 10;
  private static final int TEST_BUGS_HIGH = 20;
  private static final int TEST_VULNERABILITIES_LOW = 20;
  private static final int TEST_VULNERABILITIES_HIGH = 30;
  private static final int TEST_TECH_DEBT_LOW = 180;
  private static final int TEST_TECH_DEBT_HIGH = 300;
  private static final int TEST_CODE_COVERAGE_LOW = 60;
  private static final int TEST_CODE_COVERAGE_HIGH = 80;
  private static final int TEST_COMPLEXITY_LOW = 15;
  private static final int TEST_COMPLEXITY_HIGH = 25;

  private SonarThresholdsDAO thrDao;

  @Before
  public void setup() {

    thrDao = daoFactory.newSonarThresholdsDAO();
  }

  @After
  public void tearDown() throws Exception {

    deleteAll();
    thrDao = null;
  }

  @Test
  public void testCreate() throws Exception {
    SonarThresholdsEntity threshold = createSonarThreshold(TEST_TODAY);

    assertNotNull(threshold);
    assertTrue(threshold.getId() >= 0);
    assertTrue(threshold.isActive());
  }

  @Test
  public void testDelete() throws Exception {
    SonarThresholdsEntity threshold = createSonarThreshold(TEST_TODAY);

    assertNotNull(threshold);
    assertTrue(threshold.isActive());

    daoFactory.beginTransaction();
    thrDao.delete(threshold);
    daoFactory.commitTransaction();

    SonarThresholdsEntity threshold2 = thrDao.fetchActiveSonarThresholds();
    assertNull(threshold2);
  }

  @Test
  public void testFetchActive() throws Exception {
    createSonarThreshold(TEST_TODAY);

    SonarThresholdsEntity threshold = thrDao.fetchActiveSonarThresholds();
    assertNotNull(threshold);
    assertTrue(threshold.getEffectiveDate().toLocalDate().compareTo(TEST_TODAY.toLocalDate()) == 0);
  }

  @Test
  public void testFetchAll() throws Exception {
    createSonarThreshold(TEST_TODAY);

    SonarThresholdsEntity threshold = createSonarThreshold(TEST_TODAY);
    updateSonarThreshold(threshold, TEST_UPD_DATE);

    List<SonarThresholdsEntity> thresholds = thrDao.fetchAllSonarThresholds();
    assertNotNull(thresholds);
    assertTrue(thresholds.size() > 1);

    SonarThresholdsEntity first = thresholds.get(0);
    assertNotNull(first);
    assertTrue(first.getEffectiveDate().toLocalDate().compareTo(TEST_TODAY.toLocalDate()) == 0);
  }

  @Test
  public void testFetchThrEffDate() throws Exception {

    Date testDate1 = Date.valueOf("2018-01-01");
    SonarThresholdsEntity threshold1 = createSonarThreshold(testDate1);

    Date testDate2 = Date.valueOf("2018-01-15");
    SonarThresholdsEntity threshold2 = createSonarThreshold(testDate2);

    Date testDate3 = Date.valueOf("2018-02-01");
    SonarThresholdsEntity threshold3 = createSonarThreshold(testDate3);

    SonarThresholdsEntity testEnt1 =
        thrDao.fetchSonarThresholdsForEffDate(Date.valueOf("2018-01-20"));
    assertNotNull(testEnt1);
    assertTrue(testEnt1.getEffectiveDate().toLocalDate().compareTo(testDate2.toLocalDate()) == 0);

    SonarThresholdsEntity testEnt2 =
        thrDao.fetchSonarThresholdsForEffDate(Date.valueOf("2018-02-01"));
    assertNotNull(testEnt2);
    assertTrue(testEnt2.getEffectiveDate().toLocalDate().compareTo(testDate3.toLocalDate()) == 0);
  }

  @Test
  public void testUpdate() throws Exception {
    SonarThresholdsEntity threshold = createSonarThreshold(TEST_TODAY);

    assertNotNull(threshold);
    assertNotNull(threshold.getEffectiveDate());
    updateSonarThreshold(threshold, TEST_UPD_DATE);

    SonarThresholdsEntity threshold2 = thrDao.fetchActiveSonarThresholds();
    assertNotNull(threshold2);
    assertNotNull(threshold2.getEffectiveDate());
    assertTrue(
        threshold2.getEffectiveDate().toLocalDate().compareTo(TEST_UPD_DATE.toLocalDate()) == 0);
  }

  private SonarThresholdsEntity createSonarThreshold(Date effDate) throws Exception {
    boolean success = false;

    try {
      SonarThresholdsEntity thresholds = new SonarThresholdsEntity();

      daoFactory.beginTransaction();
      thresholds.setActive(true);
      thresholds.setEffectiveDate(effDate);
      thresholds.setBugsLow(TEST_BUGS_LOW);
      thresholds.setBugsHigh(TEST_BUGS_HIGH);
      thresholds.setVulnerabilitiesLow(TEST_VULNERABILITIES_LOW);
      thresholds.setVulnerabilitiesHigh(TEST_VULNERABILITIES_HIGH);
      thresholds.setTechDebtLow(TEST_TECH_DEBT_LOW);
      thresholds.setTechDebtHigh(TEST_TECH_DEBT_HIGH);
      thresholds.setComplexityLow(TEST_COMPLEXITY_LOW);
      thresholds.setComplexityHigh(TEST_COMPLEXITY_HIGH);
      thresholds.setCodeCoverageLow(TEST_CODE_COVERAGE_LOW);
      thresholds.setCodeCoverageHigh(TEST_CODE_COVERAGE_HIGH);

      try {
        thrDao.create(thresholds);
      } catch (DAOException e) {
      }

      daoFactory.commitTransaction();
      success = true;
      return thresholds;
    } finally {
      if (!success) {
        daoFactory.rollbackTransaction();
      }
    }
  }

  private void updateSonarThreshold(SonarThresholdsEntity threshold, Date newEffDate)
      throws Exception {

    daoFactory.beginTransaction();
    threshold.setEffectiveDate(newEffDate);
    thrDao.update(threshold);
    daoFactory.commitTransaction();
  }

  private void deleteAll() throws Exception {

    daoFactory.beginTransaction();
    List<SonarThresholdsEntity> thresholds = thrDao.fetchAllSonarThresholds();
    if (thresholds != null && !thresholds.isEmpty()) {
      for (SonarThresholdsEntity threshold : thresholds) {
        thrDao.delete(threshold);
      }
    }
    daoFactory.commitTransaction();
  }
}
