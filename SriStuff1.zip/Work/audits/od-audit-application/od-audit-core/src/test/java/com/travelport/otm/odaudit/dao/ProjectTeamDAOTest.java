/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.travelport.otm.odaudit.model.ProjectTeamEntity;
import com.travelport.otm.odaudit.validation.ValidationException;

/**
 * Verifies the functions of the <code>ProjectTeamDAO</code> class.
 */
public class ProjectTeamDAOTest extends AbstractDAOTest {

  @Before
  public void setup() {

  }

  @After
  public void tearDown() throws DAOException {

    // After each test, delete default org if it exists
    deleteOrgIfExists();
  }

  @Test
  public void testCreate() throws Exception {
    ProjectTeamEntity team = createProjectTeam();

    assertNotNull(team);
    assertTrue(team.getId() >= 0);
  }

  @Test
  public void testUpdate() throws Exception {
    boolean success = false;
    try {
      ProjectTeamEntity team = createProjectTeam();
      ProjectTeamDAO dao = daoFactory.newProjectTeamDAO();
      String updatedName = team.getName() + UPDATE_SUFFIX;

      daoFactory.beginTransaction();
      team.setName(updatedName);
      dao.update(team);
      daoFactory.commitTransaction();

      daoFactory.beginTransaction();
      team = dao.get(team.getId());
      assertEquals(updatedName, team.getName());
      daoFactory.commitTransaction();
      success = true;

    } finally {
      if (!success) {
        daoFactory.rollbackTransaction();
      }
    }
  }

  @Test(expected = DAOException.class)
  public void testDuplicateCreate() throws Exception {
    ProjectTeamEntity team = createProjectTeam();

    assertNotNull(team);
    createProjectTeam(team.getName(), team.getOrganization().getId());
  }

  @Test(expected = ValidationException.class)
  public void testInvalidName() throws Exception {
    createProjectTeam(null, null);
  }
}
