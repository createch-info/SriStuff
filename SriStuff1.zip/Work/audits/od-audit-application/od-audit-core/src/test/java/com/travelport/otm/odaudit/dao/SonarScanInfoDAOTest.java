/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.dao;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.travelport.otm.odaudit.model.SonarScanInfoEntity;

/**
 * Verifies the functions of the <code>SonarScanInfoDAO</code> class.
 */
public class SonarScanInfoDAOTest extends AbstractDAOTest {

  private SonarScanInfoDAO sonarScanDao;

  @Before
  public void setup() {

    sonarScanDao = daoFactory.newSonarScanInfoDAO();
  }

  @After
  public void tearDown() throws Exception {

    sonarScanDao = null;
  }

  @Test
  public void testCreate() throws Exception {
    SonarScanInfoEntity sonarScan = createSonarScanInfo();

    assertNotNull(sonarScan);
    assertTrue(sonarScan.getId() >= 0);
  }

  @Test(expected = UnsupportedOperationException.class)
  public void testDelete() throws Exception {
    SonarScanInfoEntity sonarScan = createSonarScanInfo();
    sonarScanDao.delete(sonarScan);
  }

  @Test
  public void testUpdate() throws Exception {
    SonarScanInfoEntity sonarScan = createSonarScanInfo();

    Float complexity = new Float(40.0);
    Float codeCoverage = new Float(30.0);

    sonarScan.setComplexity(complexity);
    sonarScan.setCodeCoverage(codeCoverage);
    sonarScanDao.update(sonarScan);

    SonarScanInfoEntity fetchedScan = sonarScanDao.get(sonarScan.getId());
    assertNotNull(fetchedScan);
    assertTrue(fetchedScan.getComplexity() == complexity);
    assertTrue(fetchedScan.getCodeCoverage() == codeCoverage);
  }
}
