/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.form;

import com.travelport.otm.odaudit.model.OrganizationEntity;

/**
 * Model object form for the <code>Organization</code> class.
 */
public class OrganizationForm extends AbstractForm<OrganizationEntity> {

  /**
   * Default constructor.
   */
  public OrganizationForm() {
    super(new OrganizationEntity());
  }

}

