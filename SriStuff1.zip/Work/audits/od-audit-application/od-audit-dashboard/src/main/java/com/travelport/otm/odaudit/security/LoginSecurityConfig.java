/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.security;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

/**
 * Specifies the login security configuration for the OD Audit Dashboard application.
 */
@Configuration
@EnableWebSecurity
public class LoginSecurityConfig extends WebSecurityConfigurerAdapter {

  /**
   * Configures the authentication provider for the application.
   * 
   * @param authenticationMgr builder for the authentication manager
   * @throws Exception thrown if authentication cannot be configured
   */
  @Autowired
  public void configureGlobal(AuthenticationManagerBuilder authenticationMgr) throws Exception {
    authenticationMgr.authenticationProvider(new AuthenticationProvider() {

      @Override
      public boolean supports(Class<?> authentication) {
        return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
      }

      @Override
      public Authentication authenticate(Authentication authentication)
          throws AuthenticationException {
        UsernamePasswordAuthenticationToken authToken =
            (UsernamePasswordAuthenticationToken) authentication;
        UserAccountManager userManager = UserAccountManager.getInstance();
        String userId = authToken.getName();
        Object credentials = authToken.getCredentials();
        String password = (credentials instanceof String) ? (String) credentials : null;

        if (userManager.authenticateUser(userId, password)) {
          List<String> authorities = userManager.getAuthorities(userId);

          authToken = new UsernamePasswordAuthenticationToken(userId, password,
              authorities.stream().map(authority -> new SimpleGrantedAuthority(authority))
                  .collect(Collectors.toList()));

        } else {
          throw new BadCredentialsException("User credentials are not valid");
        }
        return authToken;
      }
    });
  }

  /**
   * @see org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter#configure(org.springframework.security.config.annotation.web.builders.HttpSecurity)
   */
  @Override
  protected void configure(HttpSecurity http) throws Exception {
    http.authorizeRequests().antMatchers("/public/*").permitAll().antMatchers("/admin/*")
        .hasAuthority("ADMINISTRATOR").and().formLogin().loginProcessingUrl("/login.html")
        .usernameParameter("j_username").passwordParameter("j_password")
        .defaultSuccessUrl("/public/index.html").failureUrl("/public/loginError.html").and()
        .logout().logoutUrl("/logout.html").logoutSuccessUrl("/public/index.html").and().csrf()
        .disable();
  }

}
