/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.servlet;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;

/**
 * Extends the default Spring Web MVC dispatcher servlet to ignore the controller's view if the HTTP
 * response has been written directly by the controller.
 */
@WebServlet(name = "od-audit", urlPatterns = {"*.html", "*.htm"})
public class DispatcherServlet extends org.springframework.web.servlet.DispatcherServlet {

  private static final long serialVersionUID = 1980118936311475837L;

  /**
   * @see org.springframework.web.servlet.DispatcherServlet#render(org.springframework.web.servlet.ModelAndView,
   *      javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
   */
  @Override
  protected void render(ModelAndView mv, HttpServletRequest request, HttpServletResponse response)
      throws Exception {
    if (!response.isCommitted()) {
      super.render(mv, request, response);
    }
  }

}
