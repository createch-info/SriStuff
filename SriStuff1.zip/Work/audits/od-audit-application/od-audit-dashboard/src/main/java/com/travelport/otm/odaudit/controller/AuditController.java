/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.travelport.otm.odaudit.dao.DAOFactoryManager;
import com.travelport.otm.odaudit.dao.GitBucketGroupDAO;
import com.travelport.otm.odaudit.dao.GitRepositoryDAO;
import com.travelport.otm.odaudit.dao.OdProgramReportDAO;
import com.travelport.otm.odaudit.dao.OrganizationDAO;
import com.travelport.otm.odaudit.dao.ProjectTeamDAO;
import com.travelport.otm.odaudit.form.ReportGroup;
import com.travelport.otm.odaudit.model.GitBucketGroupEntity;
import com.travelport.otm.odaudit.model.GitRepositoryEntity;
import com.travelport.otm.odaudit.model.OdProgramReportEntity;
import com.travelport.otm.odaudit.model.ODScanEntity;
import com.travelport.otm.odaudit.model.OrganizationEntity;
import com.travelport.otm.odaudit.model.OrganizationReportEntity;
import com.travelport.otm.odaudit.model.ProjectTeamEntity;
import com.travelport.otm.odaudit.model.ProjectTeamReportEntity;
import com.travelport.otm.odaudit.model.RepositoryReportEntity;
import com.travelport.otm.odaudit.type.KPIType;
import com.travelport.otm.odaudit.type.ScanType;

/**
 * Controller that handles interactions with the publicly viewable pages of the OD Audit Dashboard
 * site.
 */
@Controller
@RequestMapping("/public")
public class AuditController extends BaseController {

  protected static final String ORGANIZATION_TAB = "organizations";
  protected static final String REPORTS_TAB = "reports";
  protected static final String DEFAULT_SELECTED_TAB = REPORTS_TAB;

  private static final Logger log = LoggerFactory.getLogger(AuditController.class);

  @RequestMapping({"/index.html", "/index.htm"})
  public String homePage(Model model, HttpSession session, @CookieValue(value = "selectedTab",
      defaultValue = DEFAULT_SELECTED_TAB, required = false) String selectedTab) {
    try {
      if (selectedTab.equals(REPORTS_TAB)) {
        OdProgramReportDAO reportDAO = DAOFactoryManager.getFactory().newOdProgramReportDAO();
        OrganizationDAO orgDAO = DAOFactoryManager.getFactory().newOrganizationDAO();
        List<OdProgramReportEntity> programReports = reportDAO.getAll();
        OdProgramReportEntity parentReport =
            programReports.isEmpty() ? null : programReports.get(0);

        if (parentReport != null) {
          ReportGroup<OdProgramReportEntity, OdProgramReportEntity, OrganizationEntity, OrganizationReportEntity> reportGroup =
              new ReportGroup<>(parentReport, parentReport);

          for (OrganizationEntity org : orgDAO.getAll()) {
            for (OrganizationReportEntity childReport : org.getReports()) {
              if (childReport.getOdProgramReport().getId() == parentReport.getId()) {
                reportGroup.addChild(org, childReport);
                break;
              }
            }
          }
          model.addAttribute("reportGroup", reportGroup);
          model.addAttribute("kpiList", KPIType.getSupportedKpis());
        }
      }

    } catch (Throwable t) {
      log.error("Error during publication controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, null);
  }

  @RequestMapping({"/organization.html", "/organization.htm"})
  public String organizationPage(Model model, HttpSession session,
      @RequestParam(value = "id", required = true) long orgId, @CookieValue(value = "selectedTab",
          defaultValue = DEFAULT_SELECTED_TAB, required = false) String selectedTab) {
    String targetPage = null;
    try {
      OrganizationDAO dao = DAOFactoryManager.getFactory().newOrganizationDAO();
      OrganizationEntity organization = dao.get(orgId);

      if (organization != null) {
        if (selectedTab.equals(REPORTS_TAB)) {
          List<OrganizationReportEntity> orgReports = organization.getReports();
          OrganizationReportEntity parentReport = orgReports.isEmpty() ? null : orgReports.get(0);

          if (parentReport != null) {
            OdProgramReportEntity programReport = parentReport.getOdProgramReport();
            ReportGroup<OrganizationEntity, OrganizationReportEntity, ProjectTeamEntity, ProjectTeamReportEntity> reportGroup =
                new ReportGroup<>(organization, parentReport);

            for (ProjectTeamEntity team : organization.getProjectTeams()) {
              for (ProjectTeamReportEntity childReport : team.getReports()) {
                if (childReport.getOdProgramReport().getId() == programReport.getId()) {
                  reportGroup.addChild(team, childReport);
                  break;
                }
              }
            }
            model.addAttribute("reportGroup", reportGroup);
            model.addAttribute("kpiList", KPIType.getSupportedKpis());
          }
        }
        setCurrentOrg(organization, model);
        model.addAttribute("organization", organization);
        targetPage = "viewOrganization";

      } else {
        setErrorMessage("The requested organization does not exist.", model);
        targetPage = "home";
      }

    } catch (Throwable t) {
      log.error("Error during publication controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/projectTeam.html", "/projectTeam.htm"})
  public String projectTeamPage(Model model, HttpSession session,
      @RequestParam(value = "id", required = true) long teamId, @CookieValue(value = "selectedTab",
          defaultValue = DEFAULT_SELECTED_TAB, required = false) String selectedTab) {
    String targetPage = null;
    try {
      ProjectTeamDAO dao = DAOFactoryManager.getFactory().newProjectTeamDAO();
      ProjectTeamEntity team = dao.get(teamId);

      if (team != null) {
        if (selectedTab.equals(REPORTS_TAB)) {
          List<ProjectTeamReportEntity> teamReports = team.getReports();
          ProjectTeamReportEntity parentReport = teamReports.isEmpty() ? null : teamReports.get(0);

          if (parentReport != null) {
            OdProgramReportEntity programReport = parentReport.getOdProgramReport();
            ReportGroup<ProjectTeamEntity, ProjectTeamReportEntity, GitRepositoryEntity, RepositoryReportEntity> reportGroup =
                new ReportGroup<>(team, parentReport);

            for (GitRepositoryEntity repo : team.getGitRepositories()) {
              for (ODScanEntity repoReport : repo.getReports()) {
                boolean found = false;

                if (repoReport.getScanType() == ScanType.SONAR) {
                  for (RepositoryReportEntity childReport : repoReport.getRepositoryReports()) {
                    if (childReport.getOdProgramReport().getId() == programReport.getId()) {
                      reportGroup.addChild(repo, childReport);
                      found = true;
                    }
                  }
                }
                if (found)
                  break;
              }
            }
            model.addAttribute("reportGroup", reportGroup);
            model.addAttribute("kpiList", KPIType.getSupportedKpis());
          }
        }
        setCurrentOrg(team.getOrganization(), model);
        model.addAttribute("team", team);
        targetPage = "viewProjectTeam";

      } else {
        setErrorMessage("The requested project team does not exist.", model);
        targetPage = "home";
      }

    } catch (Throwable t) {
      log.error("Error during publication controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/gitBucketGroup.html", "/gitBucketGroup.htm"})
  public String gitBucketGroupPage(Model model, HttpSession session,
      @RequestParam(value = "id", required = true) long groupId, @CookieValue(value = "selectedTab",
          defaultValue = DEFAULT_SELECTED_TAB, required = false) String selectedTab) {
    String targetPage = null;
    try {
      GitBucketGroupDAO dao = DAOFactoryManager.getFactory().newGitBucketGroupDAO();
      GitBucketGroupEntity group = dao.get(groupId);

      if (group != null) {
        setCurrentOrg(group.getProjectTeam().getOrganization(), model);
        model.addAttribute("group", group);
        targetPage = "viewGitBucketGroup";

      } else {
        setErrorMessage("The requested GitBucket group does not exist.", model);
        targetPage = "home";
      }

    } catch (Throwable t) {
      log.error("Error during publication controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/gitRepository.html", "/gitRepository.htm"})
  public String gitRepositoryPage(Model model, HttpSession session,
      @RequestParam(value = "id", required = true) long repoId, @CookieValue(value = "selectedTab",
          defaultValue = DEFAULT_SELECTED_TAB, required = false) String selectedTab) {
    String targetPage = null;
    try {
      GitRepositoryDAO dao = DAOFactoryManager.getFactory().newGitRepositoryDAO();
      GitRepositoryEntity repo = dao.get(repoId);

      if (repo != null) {
        if (selectedTab.equals(REPORTS_TAB)) {
          List<ODScanEntity> repoScans = repo.getReports();

          for (ODScanEntity scan : repoScans) {
            if (scan.getScanType() == ScanType.SONAR) {
              RepositoryReportEntity repoReport =
                  scan.getRepositoryReports().isEmpty() ? null : scan.getRepositoryReports().get(0);

              if (repoReport != null) {
                model.addAttribute("report", repoReport);
                model.addAttribute("kpiList", KPIType.getSupportedKpis());
              }
            }
          }
        }
        setCurrentOrg(repo.getProjectTeam().getOrganization(), model);
        model.addAttribute("repo", repo);
        targetPage = "viewGitRepository";

      } else {
        setErrorMessage("The requested GitBucket repository does not exist.", model);
        targetPage = "home";
      }

    } catch (Throwable t) {
      log.error("Error during publication controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/kpiHistory.html", "/kpiHistory.htm"})
  public String kpiHistoryPage(Model model, HttpSession session,
      @RequestParam(value = "orgId", required = false) Long orgId,
      @RequestParam(value = "teamId", required = false) Long teamId,
      @RequestParam(value = "repoId", required = false) Long repoId,
      @RequestParam(value = "kpi", required = true) KPIType kpiType) {
    String targetPage = "kpiHistory";
    try {
      model.addAttribute("entityName", "Test Organization");

    } catch (Throwable t) {
      log.error("Error during publication controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

}
