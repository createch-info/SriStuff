/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.controller;

import java.util.List;
import java.util.Map;

import com.travelport.otm.odaudit.type.RepositoryType;
import com.travelport.otm.odaudit.util.AuditUtils;

/**
 * Contains information related to a Git repository, including the repository URL and the available
 * branches.
 */
public class RepositoryCandidate {

  private static Map<String, String> allRepositoryTypes =
      AuditUtils.buildSelectOptions(RepositoryType.class);

  private String repositoryUrl;
  private List<String> availableBranches;

  private boolean selected = true;
  private String selectedBranch;
  private RepositoryType selectedType = RepositoryType.PRODUCTION;

  /**
   * Default constructor.
   */
  public RepositoryCandidate() {}

  /**
   * Full constructor.
   * 
   * @param repositoryUrl the URL of the Git repository
   * @param availableBranches the available branches in the repository
   */
  public RepositoryCandidate(String repositoryUrl, List<String> availableBranches) {
    this.repositoryUrl = repositoryUrl;
    this.availableBranches = availableBranches;

    if (availableBranches.size() > 0) {
      this.selectedBranch = availableBranches.get(0);
    }
  }

  /**
   * Returns the URL of the Git repository.
   *
   * @return String
   */
  public String getRepositoryUrl() {
    return repositoryUrl;
  }

  /**
   * Assigns the URL of the Git repository.
   *
   * @param repositoryUrl the repository URL to assign
   */
  public void setRepositoryUrl(String repositoryUrl) {
    this.repositoryUrl = repositoryUrl;
  }

  /**
   * Returns the available branches in the repository.
   *
   * @return List<String>
   */
  public List<String> getAvailableBranches() {
    return availableBranches;
  }

  /**
   * Assigns the available branches in the repository.
   *
   * @param availableBranches the field value to assign
   */
  public void setAvailableBranches(List<String> availableBranches) {
    this.availableBranches = availableBranches;
  }

  /**
   * Returns the select options for the available repository types.
   *
   * @return Map<String,String>
   */
  public Map<String, String> getAllRepositoryTypes() {
    return allRepositoryTypes;
  }

  /**
   * Returns the flag indicating whether this candidate was selected for creation by the user.
   *
   * @return boolean
   */
  public boolean isSelected() {
    return selected;
  }

  /**
   * Assigns the flag indicating whether this candidate was selected for creation by the user.
   *
   * @param selected the flag value to assign
   */
  public void setSelected(boolean selected) {
    this.selected = selected;
  }

  /**
   * Returns the name of the branch that was selected by the user.
   *
   * @return String
   */
  public String getSelectedBranch() {
    return selectedBranch;
  }

  /**
   * Assigns the name of the branch that was selected by the user.
   *
   * @param selectedBranch the branch name to assign
   */
  public void setSelectedBranch(String selectedBranch) {
    this.selectedBranch = selectedBranch;
  }

  /**
   * Returns the repository type that was selected by the user.
   *
   * @return RepositoryType
   */
  public RepositoryType getSelectedType() {
    return selectedType;
  }

  /**
   * Assigns the repository type that was selected by the user.
   *
   * @param selectedType the repository type to assign
   */
  public void setSelectedType(RepositoryType selectedType) {
    this.selectedType = selectedType;
  }

}
