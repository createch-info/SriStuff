/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.security;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Manages user credentials in a centralized credentials file.
 */
public class UserAccountManager {

  public static final String CREDENTIALS_FILENAME = "/users.properties";
  public static final String SYSPROP_CATALINA_HOME = "catalina.base";
  public static final String SYSPROP_CREDENTIALS_FILE = "odaudit.credentialsFile";

  public static final String ADMINISTRATOR_ROLE = "ADMINISTRATOR";
  public static final String DEFAULT_ADMIN_USER = "admin";
  public static final String DEFAULT_ADMIN_PASSWORD = "password";

  private static final Logger log = LoggerFactory.getLogger(UserAccountManager.class);
  private static final Pattern useridPattern = Pattern.compile("^[a-zA-Z_][a-zA-Z0-9_-]*[$]?$");
  private static final Pattern passwordPattern = Pattern.compile("^\\S{4,16}$");
  private static final Pattern authorityPattern = Pattern.compile("^[A-Z_][A-Z0-9_-]*$");

  private static UserAccountManager defaultInstance;

  private Map<String, String> userCredentials = new HashMap<>();
  private Map<String, List<String>> userAuthorities = new HashMap<>();
  private File credentialsFile;
  private long lastUpdated = Long.MIN_VALUE;

  /**
   * Default constructor.
   * 
   * @throws IOException thrown if the credentials file cannot be loaded or created
   */
  private UserAccountManager() throws IOException {
    this.credentialsFile = getCredentialsFile();
    loadCredentials();
  }

  /**
   * Returns the default instance of this class.
   * 
   * @return UserCredentialsManager
   */
  public static UserAccountManager getInstance() {
    return defaultInstance;
  }

  /**
   * Returns true if the user's ID and password match the credentials of a known user account.
   * 
   * @param userId the ID of the user to authenticate
   * @param password the clear-text password for the user
   * @return boolean
   */
  public boolean authenticateUser(String userId, String password) {
    refreshCredentials();
    String encryptedPassword = userCredentials.get(userId);

    return (password != null) && (encryptedPassword != null)
        && EncryptionHelper.decrypt(encryptedPassword).equals(password);
  }

  /**
   * Returns the list of authorities assigned to the specified user account.
   * 
   * @param userId the ID of the user for which to return authorities
   * @return List<String>
   */
  public List<String> getAuthorities(String userId) {
    refreshCredentials();
    List<String> authorityList = userAuthorities.get(userId);

    return (authorityList == null) ? Collections.emptyList()
        : Collections.unmodifiableList(authorityList);
  }

  /**
   * Returns the list of all user ID's for this application.
   * 
   * @return List<String>
   */
  public List<String> getAllUsers() {
    List<String> userList = new ArrayList<>();

    refreshCredentials();
    userList.addAll(userCredentials.keySet());
    Collections.sort(userList);
    return userList;
  }

  /**
   * Creates a new user with the given ID and password.
   * 
   * @param userId the ID of the new user to create
   * @param password the password of the new user
   * @throws UserAccountException thrown if the user ID is a duplicate or the ID and/or password is
   *         invalid
   * @throws IOException thrown if the credentials file cannot be saved
   */
  public synchronized void createUser(String userId, String password)
      throws UserAccountException, IOException {
    refreshCredentials();

    if (isBlank(userId)) {
      throw new UserAccountException("The user ID cannot be empty.");
    }
    userId = userId.trim();

    if (!useridPattern.matcher(userId).matches()) {
      throw new UserAccountException("The user ID '" + userId + "' is not valid.");
    }
    if (userCredentials.containsKey(userId)) {
      throw new UserAccountException("A user with the ID '" + userId + "' already exists.");
    }

    password = password.trim();
    validatePassword(password);
    userCredentials.put(userId, EncryptionHelper.encrypt(password));
    userAuthorities.put(userId, new ArrayList<>());
    saveCredentials();
  }

  /**
   * Deletes the user with the given ID and password.
   * 
   * @param userId the ID of the user to delete
   * @throws UserAccountException thrown if the user ID does not exist
   * @throws IOException thrown if the credentials file cannot be saved
   */
  public synchronized void deleteUser(String userId) throws UserAccountException, IOException {
    refreshCredentials();

    if (isBlank(userId)) {
      throw new UserAccountException("The user ID cannot be empty.");
    }
    userId = userId.trim();

    if (!userCredentials.containsKey(userId)) {
      throw new UserAccountException("The user ID '" + userId + "' is not valid.");
    }
    userCredentials.remove(userId);
    userAuthorities.remove(userId);
    saveCredentials();
  }

  /**
   * Updates the password for the user with the given ID.
   * 
   * @param userId the ID of the user whose password is to be updated
   * @param password the new password for the user
   * @throws UserAccountException thrown if the user ID and/or password is invalid
   * @throws IOException thrown if the credentials file cannot be saved
   */
  public synchronized void setPassword(String userId, String password)
      throws UserAccountException, IOException {
    refreshCredentials();

    if (isBlank(userId)) {
      throw new UserAccountException("The user ID cannot be empty.");
    }
    userId = userId.trim();

    if (!userCredentials.containsKey(userId)) {
      throw new UserAccountException("The user ID '" + userId + "' is not valid.");
    }
    password = password.trim();
    validatePassword(password);

    userCredentials.put(userId, EncryptionHelper.encrypt(password));
    saveCredentials();
  }

  /**
   * Adds the specified authority for the user. If the authority has already been assigned for this
   * user, this method returns without action.
   * 
   * @param userId the ID of the user to which the authority will be added
   * @param authority the authority to be assigned
   * @throws UserAccountException thrown if the user ID and/or authority is invalid
   * @throws IOException thrown if the credentials file cannot be saved
   */
  public synchronized void addAuthority(String userId, String authority)
      throws UserAccountException, IOException {
    refreshCredentials();

    if (isBlank(userId)) {
      throw new UserAccountException("The user ID cannot be empty.");
    }
    if (isBlank(authority)) {
      throw new UserAccountException("The authority cannot be empty.");
    }
    userId = userId.trim();
    authority = authority.trim();

    if (!userCredentials.containsKey(userId)) {
      throw new UserAccountException("The user ID '" + userId + "' is not valid.");
    }
    if (!authorityPattern.matcher(authority).matches()) {
      throw new UserAccountException("The authority '" + userId
          + "' is not valid (uppercase alpha-numeric and underscores only).");
    }
    List<String> authorityList = userAuthorities.get(userId);

    if (authorityList == null) {
      authorityList = new ArrayList<>();
      userAuthorities.put(userId, authorityList);
    }

    if (!authorityList.contains(authority)) {
      authorityList.add(authority);
      saveCredentials();
    }
  }

  /**
   * Removes the specified authority from the user. If the authority is not currently assigned for
   * this user, this method returns without action.
   * 
   * @param userId the ID of the user to which the authority will be removed
   * @param authority the authority to be removed
   * @throws UserAccountException thrown if the user ID and/or authority is invalid
   * @throws IOException thrown if the credentials file cannot be saved
   */
  public synchronized void removeAuthority(String userId, String authority)
      throws UserAccountException, IOException {
    refreshCredentials();

    if (isBlank(userId)) {
      throw new UserAccountException("The user ID cannot be empty.");
    }
    if (isBlank(authority)) {
      throw new UserAccountException("The authority cannot be empty.");
    }
    userId = userId.trim();
    authority = authority.trim();

    if (!userCredentials.containsKey(userId)) {
      throw new UserAccountException("The user ID '" + userId + "' is not valid.");
    }
    List<String> authorityList = userAuthorities.get(userId);

    if ((authorityList != null) && authorityList.contains(authority)) {
      authorityList.remove(authority);
      saveCredentials();
    }
  }

  /**
   * Refreshes the user credentials from the local file system if the file has been updated by an
   * external process.
   */
  private void refreshCredentials() {
    try {
      loadCredentials();

    } catch (IOException e) {
      log.error("Error refreshing user credentials.", e);
    }
  }

  /**
   * Loads the credentials from the file if the in-memory content is stale.
   * 
   * @throws IOException thrown if the credentials file cannot be loaded
   */
  private synchronized void loadCredentials() throws IOException {
    if (credentialsFile.exists()) {
      if (credentialsFile.lastModified() > lastUpdated) {
        Properties credentialsProps = new Properties();

        try (InputStream is = new FileInputStream(credentialsFile)) {
          credentialsProps.load(is);
        }

        userCredentials.clear();
        userAuthorities.clear();

        for (String userId : credentialsProps.stringPropertyNames()) {
          String[] userData = credentialsProps.getProperty(userId, "").split("\\|");
          String encryptedPassword = (userData.length == 0) ? null : userData[0];

          if (!isBlank(encryptedPassword)) {
            List<String> authorityList = new ArrayList<>();

            for (int i = 1; i < userData.length; i++) {
              if (!isBlank(userData[i])) {
                authorityList.add(userData[i]);
              }
            }
            userCredentials.put(userId, encryptedPassword);
            userAuthorities.put(userId, authorityList);
          }
        }
      }

    } else { // No credentials file (create a default set of admin credentials)
      userCredentials.put(DEFAULT_ADMIN_USER, EncryptionHelper.encrypt(DEFAULT_ADMIN_PASSWORD));
      userAuthorities.put(DEFAULT_ADMIN_USER, Arrays.asList(ADMINISTRATOR_ROLE));
      saveCredentials();
    }
  }

  /**
   * Saves the credentials file to the local file system.
   * 
   * @throws IOException thrown if the credentials file cannot be saved
   */
  private void saveCredentials() throws IOException {
    Properties credentialsProps = new Properties();

    for (String userId : userCredentials.keySet()) {
      String encryptedPassword = userCredentials.get(userId);
      List<String> authorityList = userAuthorities.get(userId);
      StringBuilder userData = new StringBuilder(encryptedPassword);

      for (String authority : authorityList) {
        userData.append("|").append(authority);
      }
      credentialsProps.put(userId, userData.toString());
    }

    try (OutputStream out = new FileOutputStream(credentialsFile)) {
      credentialsProps.store(out, "User credentials and assigned authorities");
    }
    lastUpdated = credentialsFile.lastModified();
  }

  /**
   * Loads the credentials file or creates one automatically if it does not yet exist.
   * 
   * @return File
   * @throws IOException thrown if the credentials file cannot be loaded or created
   */
  private File getCredentialsFile() throws IOException {
    File credentialsFile = null;

    // First Choice: File location and name is explicitly specified
    if (System.getProperties().containsKey(SYSPROP_CREDENTIALS_FILE)) {
      credentialsFile = new File(System.getProperty(SYSPROP_CREDENTIALS_FILE));
    }

    // Second Choice: Look in Tomcat /conf directory for default filename
    if ((credentialsFile == null) && System.getProperties().containsKey(SYSPROP_CATALINA_HOME)) {
      credentialsFile =
          new File(System.getProperty(SYSPROP_CATALINA_HOME), "/conf" + CREDENTIALS_FILENAME);
    }

    // Last Choice: Look in current directory for default filename
    if (credentialsFile == null) {
      credentialsFile = new File(System.getProperty("user.dir"), CREDENTIALS_FILENAME);
    }
    return credentialsFile;
  }

  /**
   * Throws and exception if the given password is not valid.
   * 
   * @param password the password to be validated
   * @throws UserAccountException thrown if the password is not valid
   */
  private void validatePassword(String password) throws UserAccountException {
    if (isBlank(password)) {
      throw new UserAccountException("Password cannot be null or blank.");
    }
    if (!passwordPattern.matcher(password).matches()) {
      throw new UserAccountException("Passwords must be between four and sixteen"
          + " characters in length and contain no whitespace.");
    }
  }

  /**
   * Returns true if the given string is null or blank.
   * 
   * @param str the string to test
   * @return boolean
   */
  private boolean isBlank(String str) {
    return (str == null) || (str.trim().length() == 0);
  }

  /**
   * Initializes the default instance of this class.
   */
  static {
    try {
      defaultInstance = new UserAccountManager();

    } catch (Throwable t) {
      throw new ExceptionInInitializerError(t);
    }
  }

}
