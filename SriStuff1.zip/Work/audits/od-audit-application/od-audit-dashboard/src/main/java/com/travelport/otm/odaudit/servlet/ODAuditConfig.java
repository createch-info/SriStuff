/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Provides access to configuration properties from the 'od-audit.properties' file.
 */
public class ODAuditConfig {

  public static final String CONFIG_FILENAME = "/od-audit.properties";
  public static final String CONFIG_FILE_SYSPROP = "od-audit-config";

  private static final String DEFAULT_GITBUCKET_BASE_URL = "https://gitbucket.tvlport.com";
  private static final int REPOSITORY_FINDER_DEFAULT_POOL_SIZE = 5;

  private static final Logger log = LoggerFactory.getLogger(ODAuditConfig.class);

  private static ODAuditConfig instance = new ODAuditConfig();

  private String gitbucketBaseUrl = DEFAULT_GITBUCKET_BASE_URL;
  private int repositoryFinderPoolSize = REPOSITORY_FINDER_DEFAULT_POOL_SIZE;

  /**
   * Private default constructor.
   */
  private ODAuditConfig() {
    String odAuditConfig = System.getProperty(CONFIG_FILE_SYSPROP);
    String catalinaHome = System.getProperty("catalina.base");
    File configFile = null;

    if (odAuditConfig != null) {
      File file = new File(odAuditConfig);

      if (file.exists() && file.isFile()) {
        configFile = file;
      }
    }
    if ((configFile == null) && (catalinaHome != null)) {
      File file = new File(catalinaHome, "/conf" + CONFIG_FILENAME);

      if (file.exists() && file.isFile()) {
        configFile = file;
      }
    }
    if (configFile != null) {
      try (InputStream is = new FileInputStream(configFile)) {
        Properties configProps = new Properties();

        configProps.load(is);
        this.gitbucketBaseUrl = configProps.getProperty("gitbucketBaseUrl");
        this.repositoryFinderPoolSize =
            parseInt(configProps.getProperty("repositoryFinderPoolSize"),
                REPOSITORY_FINDER_DEFAULT_POOL_SIZE);

      } catch (IOException e) {
        // No error - warn and proceed with default values
        log.warn("Error loading OD Audit configuration file: " + configFile.getAbsolutePath(), e);
      }

    } else {
      log.warn("No OD Audit configuration file found (using defaults).");
    }
  }

  /**
   * Returns the singleton instance of the configuration settings.
   * 
   * @return ODAuditConfig
   */
  public static ODAuditConfig getInstance() {
    return instance;
  }

  /**
   * Returns the base URL for the GitBucket repository management site.
   *
   * @return String
   */
  public String getGitbucketBaseUrl() {
    return gitbucketBaseUrl;
  }

  /**
   * Returns the size of the repository finder thread pool.
   *
   * @return int
   */
  public int getRepositoryFinderPoolSize() {
    return repositoryFinderPoolSize;
  }

  /**
   * Parses the given integer string and returns the numeric value. If the string is unparsable or
   * null, the default value provided will be returned.
   * 
   * @param intStr the integer string to parse
   * @param defaultValue the default value to use in case of null/error
   * @return int
   */
  private int parseInt(String intStr, int defaultValue) {
    int result = defaultValue;
    try {
      if (intStr != null) {
        result = Integer.parseInt(intStr);
      }

    } catch (NumberFormatException e) {
      // No error - return default value
    }
    return result;
  }

}
