/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.form;

/**
 * Base class for all model object forms.
 *
 * @param <T> the model object type for this form
 */
public abstract class AbstractForm<T> {

  private boolean processForm = false;
  private T formObject;

  /**
   * Constructor that provides the model object instance.
   * 
   * @param formObject the model object instance for the form
   */
  public AbstractForm(T formObject) {
    this.formObject = formObject;
  }

  /**
   * Returns the flag value indicating whether the form has been initialized and submitted by the
   * user for processing.
   *
   * @return boolean
   */
  public boolean isProcessForm() {
    return processForm;
  }

  /**
   * Assigns the flag value indicating whether the form has been initialized and submitted by the
   * user for processing.
   *
   * @param processForm the field value to assign
   */
  public void setProcessForm(boolean processForm) {
    this.processForm = processForm;
  }

  /**
   * Returns the model object instance for this form.
   * 
   * @return T
   */
  public T getFormObject() {
    return formObject;
  }

  /**
   * Assigns the model object instance for this form.
   * 
   * @param formObject the form object instance to assign
   */
  public void setFormObject(T formObject) {
    this.formObject = formObject;
  }

}
