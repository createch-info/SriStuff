/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.util;

import java.text.MessageFormat;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import com.travelport.otm.odaudit.validation.MessageInterpolator;

/**
 * Static utility methods for the OD Audit Dashboard application.
 */
public class AuditUtils {

  private static ResourceBundle messageBundle =
      ResourceBundle.getBundle(MessageInterpolator.MESSAGE_BUNDLE_LOCATION, Locale.getDefault());

  /**
   * Builds a map of selection options for the given enumeration.
   * 
   * @param selectEnum the Java enum for which to build the select options
   * @return Map<String,String>
   */
  public static Map<String, String> buildSelectOptions(Class<? extends Enum<?>> selectEnum) {
    String messageKeyPrefix = selectEnum.getSimpleName() + ".";
    Map<String, String> options = new LinkedHashMap<>();

    for (Enum<?> literal : selectEnum.getEnumConstants()) {
      options.put(literal.toString(), getMessage(messageKeyPrefix + literal.toString()));
    }
    return options;
  }

  /**
   * Returns a human-readable message using the given key and parameters. If no such message is
   * defined, the message key is returned.
   * 
   * @param messageKey the key for the localizable message
   * @param params the list of message parameters
   * @return String
   */
  public static String getMessage(String messageKey, Object... params) {
    String message;

    try {
      message = MessageFormat.format(messageBundle.getString(messageKey), params);

    } catch (MissingResourceException e) {
      message = messageKey;
    }
    return message;
  }

}
