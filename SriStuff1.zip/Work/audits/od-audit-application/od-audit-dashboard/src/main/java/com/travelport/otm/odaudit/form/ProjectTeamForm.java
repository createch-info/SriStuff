/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.form;

import com.travelport.otm.odaudit.model.ProjectTeamEntity;

/**
 * Model object form for the <code>ProjectTeam</code> class.
 */
public class ProjectTeamForm extends AbstractForm<ProjectTeamEntity> {

  /**
   * Default constructor.
   */
  public ProjectTeamForm() {
    super(new ProjectTeamEntity());
  }

}
