/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;

import com.travelport.otm.odaudit.security.UserAccountManager;
import com.travelport.otm.odaudit.validation.MessageInterpolator;

/**
 * Utility methods designed for use within JSP page processing.
 */
public class PageUtils {

  private ResourceBundle messageBundle =
      ResourceBundle.getBundle(MessageInterpolator.MESSAGE_BUNDLE_LOCATION, Locale.getDefault());

  private static DateFormat dateFormat = new SimpleDateFormat("d-MMM-yyyy");

  /**
   * Returns true if the current user is an administrator for this application.
   * 
   * @param sessionScope the session scope of the JSP page
   * @return boolean
   */
  public boolean isAdministrator(Map<String, Object> sessionScope) {
    SecurityContext context = (SecurityContext) sessionScope.get("SPRING_SECURITY_CONTEXT");
    Authentication auth = (context == null) ? null : context.getAuthentication();
    boolean result = false;

    if (auth instanceof UsernamePasswordAuthenticationToken) {
      String userId = ((UsernamePasswordAuthenticationToken) auth).getName();

      result = UserAccountManager.getInstance().getAuthorities(userId)
          .contains(UserAccountManager.ADMINISTRATOR_ROLE);
    }
    return result;
  }

  /**
   * Returns a display label for the given enumeration.
   * 
   * @param enumValue the enumeration value for which to return a display label
   * @return String
   */
  public String getDisplayLabel(Enum<?> enumValue) {
    String label = null;

    if (enumValue != null) {
      String key = enumValue.getClass().getSimpleName() + "." + enumValue.toString();

      try {
        label = messageBundle.getString(key);

      } catch (MissingResourceException e) {
        label = key;
      }
    }
    return label;
  }

  /**
   * Returns a formatted string to represent the given date.
   * 
   * @param date the date to be formatted
   * @return String
   */
  public String formatDate(Date date) {
    return (date == null) ? null : dateFormat.format(date);
  }

  /**
   * Returns a human-readable message using the given key and parameters. If no such message is
   * defined, the message key is returned.
   * 
   * @param messageKey the key for the localizable message
   * @return String
   */
  public String getMessage(String messageKey) {
    String message;

    try {
      message = messageBundle.getString(messageKey);

    } catch (MissingResourceException e) {
      message = messageKey;
    }
    return message;
  }

  /**
   * Returns the value for the cookie with the specified name.
   * 
   * @param request the request from which to read the cookie value
   * @param cookieName the name of the cookie to return
   * @return String
   */
  public String getCookie(HttpServletRequest request, String cookieName) {
    String cookieValue = null;

    for (Cookie cookie : request.getCookies()) {
      if (cookieName.equals(cookie.getName())) {
        cookieValue = cookie.getValue();
        break;
      }
    }
    return cookieValue;
  }

}
