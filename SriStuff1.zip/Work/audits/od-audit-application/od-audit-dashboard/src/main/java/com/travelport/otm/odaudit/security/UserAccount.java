/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.security;

/**
 * Model object for the creation and modification of user accounts.
 */
public class UserAccount {

  private String userId;
  private String password;
  private String confirmPassword;

  /**
   * Returns the ID of the user account.
   *
   * @return String
   */
  public String getUserId() {
    return userId;
  }

  /**
   * Assigns the ID of the user account.
   *
   * @param userId the user ID to assign
   */
  public void setUserId(String userId) {
    this.userId = userId;
  }

  /**
   * Returns the password of the user account.
   *
   * @return String
   */
  public String getPassword() {
    return password;
  }

  /**
   * Assigns the password of the user account.
   *
   * @param password the password value to assign
   */
  public void setPassword(String password) {
    this.password = password;
  }

  /**
   * Returns the password confirmation field.
   *
   * @return String
   */
  public String getConfirmPassword() {
    return confirmPassword;
  }

  /**
   * Assigns the password confirmation field.
   *
   * @param confirmPassword the password confirmation value to assign
   */
  public void setConfirmPassword(String confirmPassword) {
    this.confirmPassword = confirmPassword;
  }

}
