/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.internal.storage.file.FileRepository;
import org.eclipse.jgit.lib.Ref;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.travelport.otm.odaudit.servlet.ODAuditConfig;

/**
 * Locates all repositories and development branches using a list of GitBucket groups.
 */
public class RepositoryFinder {

  private static final Logger log = LoggerFactory.getLogger(RepositoryFinder.class);

  private static Pattern branchPattern = Pattern.compile("refs/heads/([^/]+)$");
  private static ExecutorService executor;

  private String gitBucketBaseUrl;

  /**
   * Default constructor.
   */
  public RepositoryFinder() {
    ODAuditConfig config = ODAuditConfig.getInstance();

    this.gitBucketBaseUrl = config.getGitbucketBaseUrl();

    if (!this.gitBucketBaseUrl.endsWith("/")) {
      this.gitBucketBaseUrl += "/";
    }
  }

  /**
   * Constructor that specifies the size of the executor thread pool and the base URL for the
   * GitBucket repository manager.
   * 
   * @param gitBucketBaseUrl the base URL for all GitBucket calls
   */
  public RepositoryFinder(String gitBucketBaseUrl) {
    if (!gitBucketBaseUrl.endsWith("/")) {
      gitBucketBaseUrl += "/";
    }
    this.gitBucketBaseUrl = gitBucketBaseUrl;
  }

  /**
   * Shuts down the shared executor service for this finder class.
   */
  public static void shutdownExecutor() {
    executor.shutdown();
  }

  /**
   * Returns the list of all repositories and branches associated with the given collection of
   * GitBucket groups. Any repositories that are provided in the 'excludedRepositoryUrls' collection
   * will be excluded from the resulting list.
   * 
   * @param gitBucketGroups the list of GitBucket groups to scan
   * @param excludedRepositoryUrls the list of repository URL's to exclude from the search results
   * @return List<RepositoryCandidate>
   */
  public List<RepositoryCandidate> findRepositories(Collection<String> gitBucketGroups,
      Collection<String> excludedRepositoryUrls) {
    List<Future<RepositoryCandidate>> repoFutures = new ArrayList<>();
    List<Future<List<String>>> groupFutures = new ArrayList<>();
    List<String> includedRepositoryUrls = new ArrayList<>();
    List<RepositoryCandidate> repoList = new ArrayList<>();

    // Execute group scans in parallel
    for (String group : gitBucketGroups) {
      groupFutures.add(executor.submit(new Callable<List<String>>() {
        public List<String> call() throws Exception {
          List<String> result = new ArrayList<>();
          try {
            List<String> allRepos = findGitBucketRepositories(group);

            for (String repoUrl : allRepos) {
              if (!excludedRepositoryUrls.contains(repoUrl)) {
                result.add(repoUrl);
              }
            }

          } catch (Throwable t) {
            log.warn("Error scanning for repositories in GitBucket group: " + group);
          }
          return result;
        }
      }));
    }

    // Wait for the GitBucket scans to finish before proceeding to the branch
    // searches
    for (Future<List<String>> future : groupFutures) {
      try {
        includedRepositoryUrls.addAll(future.get());

      } catch (InterruptedException | ExecutionException e) {
        log.warn("Unknown exception during scan of GitBucket groups.");
      }
    }

    // Find the list of available branches for each included repository
    for (String repoUrl : includedRepositoryUrls) {
      repoFutures.add(executor.submit(new Callable<RepositoryCandidate>() {
        public RepositoryCandidate call() throws Exception {
          return new RepositoryCandidate(repoUrl, findGitBranches(repoUrl));
        }
      }));
    }

    // Wait for all of the branch scans to complete
    for (Future<RepositoryCandidate> future : repoFutures) {
      try {
        repoList.add(future.get());

      } catch (InterruptedException | ExecutionException e) {
        log.warn("Unknown exception during retrieval of Git repository branches.");
      }
    }

    return repoList;
  }

  /**
   * Returns the Git URL's for all public repositories in the specified GitBucket group.
   * 
   * @param gitBucketGroup the group for which to retrieve repository URL's
   * @return List<String>
   * @throws IOException thrown if an error occurs while calling the GitBucket site
   */
  private List<String> findGitBucketRepositories(String gitBucketGroup) throws IOException {
    URL gbUrl = new URL(gitBucketBaseUrl + gitBucketGroup);
    HttpsURLConnection conn = (HttpsURLConnection) gbUrl.openConnection();
    StringWriter out = new StringWriter();

    try (InputStream is = conn.getInputStream()) {
      Reader in = new InputStreamReader(is);
      char[] buffer = new char[4096];
      int charsRead;

      while ((charsRead = in.read(buffer, 0, buffer.length)) >= 0) {
        out.write(buffer, 0, charsRead);
      }
    }

    // Find all links that refer to a GitBucket repository in the HTML
    // content that was returned
    Pattern linkPattern =
        Pattern.compile("\\\"" + gitBucketBaseUrl + gitBucketGroup + "/([^\\?]+?)\\\"");
    Matcher m = linkPattern.matcher(out.toString());
    List<String> repositoryUrls = new ArrayList<>();

    while (m.find()) {
      String repositoryName = m.group(1);
      String gitUrl = gitBucketBaseUrl + "git/" + gitBucketGroup + "/" + repositoryName + ".git";

      repositoryUrls.add(gitUrl);
    }
    return repositoryUrls;
  }

  /**
   * Returns the list of all non-tracking branches for the specified Git repository.
   * 
   * @param gitRepositoryUrl the URL of the repository for which to retrieve branches
   * @return List<String>
   * @throws GitAPIException thrown if the GIT repository cannot be accessed
   */
  public List<String> findGitBranches(String gitRepositoryUrl) throws GitAPIException {
    List<String> branchList = new ArrayList<>();

    try (Git git = new Git(new FileRepository(System.getProperty("user.dir")))) {
      Collection<Ref> remoteRefs = git.lsRemote().setRemote(gitRepositoryUrl).setHeads(true).call();

      for (Ref ref : remoteRefs) {
        Matcher m = branchPattern.matcher(ref.getName());

        if (m.matches()) {
          branchList.add(m.group(1));
        }
      }

    } catch (GitAPIException | IOException e) {
      // Should never happen since Git repository is a dummy (ignore and return empty list)
    }
    return branchList;
  }

  /**
   * Initializes the thread pool executor service.
   */
  static {
    try {
      ODAuditConfig config = ODAuditConfig.getInstance();
      executor = Executors.newFixedThreadPool(config.getRepositoryFinderPoolSize());

    } catch (Throwable t) {
      throw new ExceptionInInitializerError(t);
    }
  }

  /**
   * Configure the SSL socket factory to accept unsigned certificates.
   */
  static {
    try {
      TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
          return new X509Certificate[0];
        }

        public void checkClientTrusted(java.security.cert.X509Certificate[] certs,
            String authType) {}

        public void checkServerTrusted(java.security.cert.X509Certificate[] certs,
            String authType) {}
      }};

      SSLContext sc = SSLContext.getInstance("SSL");
      sc.init(null, trustAllCerts, new java.security.SecureRandom());
      HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

    } catch (Throwable t) {
      throw new ExceptionInInitializerError(t);
    }
  }

}
