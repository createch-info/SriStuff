/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.form;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.travelport.otm.odaudit.model.PersistentEntity;

/**
 * Container for a grouping of OD Audit reports.
 *
 * @param <PT> the parent entity type
 * @param <PR> the parent report type
 * @param <CT> the child entity type
 * @param <CR> the child report type
 */
public class ReportGroup<PT extends PersistentEntity, PR, CT extends PersistentEntity, CR> {

  private PT parentEntity;
  private PR parentReport;
  private List<CT> childEntities = new ArrayList<>();
  private Map<Long, CR> childReports = new HashMap<>();

  /**
   * Constructor that specifies the parent entity and report instance.
   * 
   * @param parentEntity the parent entity for the report group
   * @param parentReport the parent report for the group
   */
  public ReportGroup(PT parentEntity, PR parentReport) {
    this.parentEntity = parentEntity;
    this.parentReport = parentReport;
  }

  /**
   * Adds the given child entity and report to this group.
   * 
   * @param childEntity the child entity to add
   * @param childReport the child report to add
   */
  public void addChild(CT childEntity, CR childReport) {
    childEntities.add(childEntity);
    childReports.put(childEntity.getId(), childReport);
  }

  /**
   * Returns the parent entity for this group.
   *
   * @return PT
   */
  public PT getParentEntity() {
    return parentEntity;
  }

  /**
   * Returns the parent report for this group.
   *
   * @return PR
   */
  public PR getParentReport() {
    return parentReport;
  }

  /**
   * Returns the list of child entities for this group.
   *
   * @return List<CT>
   */
  public List<CT> getChildEntities() {
    return childEntities;
  }

  /**
   * Returns the report associated with the given child entity.
   *
   * @return CR
   */
  public CR getChildReport(CT childEntity) {
    return (childEntity == null) ? null : childReports.get(childEntity.getId());
  }

}
