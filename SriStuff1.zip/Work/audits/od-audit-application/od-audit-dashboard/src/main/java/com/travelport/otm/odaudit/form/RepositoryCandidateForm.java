/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.form;

import java.util.ArrayList;
import java.util.List;

import com.travelport.otm.odaudit.controller.RepositoryCandidate;

/**
 * Model object form for the <code>RepositoryCandidate</code> class.
 */
public class RepositoryCandidateForm {

  private boolean processForm = false;
  private List<RepositoryCandidate> formObject = new ArrayList<>();

  /**
   * Default constructor.
   */
  public RepositoryCandidateForm() {}

  /**
   * Returns the flag value indicating whether the form has been initialized and submitted by the
   * user for processing.
   *
   * @return boolean
   */
  public boolean isProcessForm() {
    return processForm;
  }

  /**
   * Assigns the flag value indicating whether the form has been initialized and submitted by the
   * user for processing.
   *
   * @param processForm the field value to assign
   */
  public void setProcessForm(boolean processForm) {
    this.processForm = processForm;
  }

  /**
   * Returns the model object instance for this form.
   * 
   * @return List<RepositoryCandidate>
   */
  public List<RepositoryCandidate> getFormObject() {
    return formObject;
  }

  /**
   * Assigns the model object instance for this form.
   * 
   * @param formObject the form object instance to assign
   */
  public void setFormObject(List<RepositoryCandidate> formObject) {
    this.formObject = formObject;
  }

}

