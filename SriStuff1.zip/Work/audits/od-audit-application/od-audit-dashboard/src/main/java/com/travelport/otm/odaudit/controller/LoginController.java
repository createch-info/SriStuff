/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.travelport.otm.odaudit.form.UserAccountForm;
import com.travelport.otm.odaudit.security.UserAccount;
import com.travelport.otm.odaudit.security.UserAccountException;
import com.travelport.otm.odaudit.security.UserAccountManager;

/**
 * Controller that handles logins and user account management for the OD Audit Dashboard site.
 */
@Controller
@RequestMapping("/admin")
public class LoginController extends BaseController {

  private static final Logger log = LoggerFactory.getLogger(LoginController.class);

  @RequestMapping({"/createUser.html", "createUser.htm"})
  public String createUser(Model model, HttpSession session,
      @ModelAttribute("userForm") UserAccountForm userForm) {
    String targetPage = "createUser";
    try {
      userForm.setProcessForm(true);

    } catch (Throwable t) {
      log.error("Error during admin controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/doCreateUser.html", "doCreateUser.htm"})
  public String doCreateUser(Model model, HttpSession session, RedirectAttributes redirectAttrs,
      @ModelAttribute("userForm") UserAccountForm userForm) {
    String targetPage = "createUser";
    try {
      if (userForm.isProcessForm()) {
        UserAccount userAccount = userForm.getFormObject();
        String password = userAccount.getPassword();
        String confirmPassword = userAccount.getConfirmPassword();

        if ((password != null) && (confirmPassword != null) && !password.equals(confirmPassword)) {
          throw new UserAccountException("The password and password confirmation do not match.");
        }

        UserAccountManager.getInstance().createUser(userAccount.getUserId(),
            userAccount.getPassword());
        UserAccountManager.getInstance().addAuthority(userAccount.getUserId(),
            UserAccountManager.ADMINISTRATOR_ROLE);
        setStatusMessage("User '" + userAccount.getUserId() + "' created successfully.",
            redirectAttrs);
        targetPage = "redirect:/public/index.html";
      }

    } catch (UserAccountException e) {
      setErrorMessage(e.getMessage(), model);

    } catch (Throwable t) {
      log.error("Error during publication controller processing.", t);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/selectDeleteUser.html", "selectDeleteUser.htm"})
  public String selectDeleteUser(Model model, HttpSession session) {
    String targetPage = "selectDeleteUser";
    try {
      model.addAttribute("allUsers", UserAccountManager.getInstance().getAllUsers());

    } catch (Throwable t) {
      log.error("Error during admin controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/deleteUser.html", "deleteUser.htm"})
  public String deleteUser(Model model, HttpSession session,
      @ModelAttribute("userForm") UserAccountForm userForm,
      @RequestParam(value = "user", required = false) String user) {
    String targetPage = "deleteUser";
    try {
      if (user != null) {
        userForm.getFormObject().setUserId(user);
        userForm.setProcessForm(true);

      } else {
        targetPage = "redirect:/admin/selectDeleteUser.html";
      }

    } catch (Throwable t) {
      log.error("Error during admin controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/doDeleteUser.html", "doDeleteUser.htm"})
  public String doDeleteUser(Model model, HttpSession session, RedirectAttributes redirectAttrs,
      @ModelAttribute("userForm") UserAccountForm userForm) {
    String targetPage = "deleteUser";
    try {
      if (userForm.isProcessForm()) {
        UserAccount userAccount = userForm.getFormObject();

        UserAccountManager.getInstance().deleteUser(userAccount.getUserId());
        setStatusMessage("User '" + userAccount.getUserId() + "' deleted successfully.",
            redirectAttrs);
        targetPage = "redirect:/public/index.html";
      }

    } catch (UserAccountException e) {
      setErrorMessage(e.getMessage(), model);

    } catch (Throwable t) {
      log.error("Error during publication controller processing.", t);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/changePassword.html", "changePassword.htm"})
  public String changePassword(Model model, HttpSession session,
      @ModelAttribute("userForm") UserAccountForm userForm) {
    String targetPage = "changePassword";
    try {
      SecurityContext context = (SecurityContext) session.getAttribute("SPRING_SECURITY_CONTEXT");
      Authentication auth = (context == null) ? null : context.getAuthentication();

      userForm.getFormObject().setUserId(auth.getName());
      userForm.setProcessForm(true);

    } catch (Throwable t) {
      log.error("Error during admin controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/doChangePassword.html", "doChangePassword.htm"})
  public String doChangePassword(Model model, HttpSession session, RedirectAttributes redirectAttrs,
      @ModelAttribute("userForm") UserAccountForm userForm) {
    String targetPage = "changePassword";
    try {
      if (userForm.isProcessForm()) {
        UserAccount userAccount = userForm.getFormObject();
        String password = userAccount.getPassword();
        String confirmPassword = userAccount.getConfirmPassword();

        if ((password != null) && (confirmPassword != null) && !password.equals(confirmPassword)) {
          throw new UserAccountException("The password and password confirmation do not match.");
        }
        UserAccountManager.getInstance().setPassword(userAccount.getUserId(),
            userAccount.getPassword());
        setStatusMessage("Password successfully updated.", redirectAttrs);
        targetPage = "redirect:/public/index.html";
      }

    } catch (UserAccountException e) {
      setErrorMessage(e.getMessage(), model);

    } catch (Throwable t) {
      log.error("Error during publication controller processing.", t);
    }
    return applyCommonValues(model, targetPage);
  }

}
