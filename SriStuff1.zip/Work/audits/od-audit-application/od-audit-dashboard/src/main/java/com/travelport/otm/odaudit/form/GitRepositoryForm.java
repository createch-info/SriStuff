/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.form;

import com.travelport.otm.odaudit.model.GitRepositoryEntity;

/**
 * Model object form for the <code>GitRepository</code> class.
 */
public class GitRepositoryForm extends AbstractForm<GitRepositoryEntity> {

  /**
   * Default constructor.
   */
  public GitRepositoryForm() {
    super(new GitRepositoryEntity());
  }

}

