/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.travelport.otm.odaudit.dao.DAOException;
import com.travelport.otm.odaudit.dao.DAOFactoryManager;
import com.travelport.otm.odaudit.dao.GitBucketGroupDAO;
import com.travelport.otm.odaudit.dao.GitRepositoryDAO;
import com.travelport.otm.odaudit.dao.OrganizationDAO;
import com.travelport.otm.odaudit.dao.ProjectTeamDAO;
import com.travelport.otm.odaudit.form.GitBucketGroupForm;
import com.travelport.otm.odaudit.form.GitRepositoryForm;
import com.travelport.otm.odaudit.form.OrganizationForm;
import com.travelport.otm.odaudit.form.ProjectTeamForm;
import com.travelport.otm.odaudit.form.RepositoryCandidateForm;
import com.travelport.otm.odaudit.model.GitBucketGroupEntity;
import com.travelport.otm.odaudit.model.GitRepositoryEntity;
import com.travelport.otm.odaudit.model.OrganizationEntity;
import com.travelport.otm.odaudit.model.ProjectTeamEntity;
import com.travelport.otm.odaudit.type.RepositoryType;
import com.travelport.otm.odaudit.util.AuditUtils;
import com.travelport.otm.odaudit.validation.ValidationException;

/**
 * Controller that handles interactions with the publicly viewable pages of the OD Audit Dashboard
 * site.
 */
@Controller
@RequestMapping("/admin")
public class AdminController extends BaseController {

  private static final Logger log = LoggerFactory.getLogger(AdminController.class);

  @RequestMapping({"/createOrganization.html", "/createOrganization.htm"})
  public String createOrganizationPage(Model model, HttpSession session,
      RedirectAttributes redirectAttrs,
      @ModelAttribute("organizationForm") OrganizationForm organizationForm) {
    String targetPage = "createOrganization";
    try {
      if (organizationForm.isProcessForm()) {
        OrganizationDAO dao = DAOFactoryManager.getFactory().newOrganizationDAO();
        OrganizationEntity organization = organizationForm.getFormObject();

        dao.create(organization);
        redirectAttrs.addAttribute("id", organization.getId());
        targetPage = "redirect:/public/organization.html";

      } else {
        organizationForm.setProcessForm(true);
      }

    } catch (ValidationException e) {
      addValidationErrors(e, model);

    } catch (DAOException e) {
      log.error("Error updating persistent entity.", e);
      setErrorMessage(e.getMessage(), model);

    } catch (Throwable t) {
      log.error("Error during controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/updateOrganization.html", "/updateOrganization.htm"})
  public String updateOrganizationPage(Model model, HttpSession session,
      RedirectAttributes redirectAttrs, @RequestParam(value = "id", required = false) Long orgId,
      @ModelAttribute("organizationForm") OrganizationForm organizationForm) {
    String targetPage = "updateOrganization";
    try {
      OrganizationDAO dao = DAOFactoryManager.getFactory().newOrganizationDAO();
      OrganizationEntity organization = dao.get(orgId);

      if (organization != null) {
        if (organizationForm.isProcessForm()) {
          organization.setName(organizationForm.getFormObject().getName());
          dao.update(organization);
          redirectAttrs.addAttribute("id", organization.getId());
          targetPage = "redirect:/public/organization.html";

        } else {
          organizationForm.setFormObject(organization);
          organizationForm.setProcessForm(true);
        }
        model.addAttribute("organization", organization);
        setCurrentOrg(organization, model);

      } else {
        setErrorMessage("The requested organization does not exist.", model);
        targetPage = "home";
      }

    } catch (ValidationException e) {
      addValidationErrors(e, model);

    } catch (DAOException e) {
      log.error("Error updating persistent entity.", e);
      setErrorMessage(e.getMessage(), model);

    } catch (Throwable t) {
      log.error("Error during controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/deleteOrganization.html", "/deleteOrganization.htm"})
  public String deleteOrganizationPage(Model model, HttpSession session,
      RedirectAttributes redirectAttrs, @RequestParam(value = "id", required = false) Long orgId,
      @ModelAttribute("organizationForm") OrganizationForm organizationForm) {
    String targetPage = "deleteOrganization";
    try {
      OrganizationDAO dao = DAOFactoryManager.getFactory().newOrganizationDAO();
      OrganizationEntity organization = dao.get(orgId);

      if (organization != null) {
        if (organizationForm.isProcessForm()) {
          dao.delete(organization);
          setStatusMessage("Organization '" + organization.getName() + "' deleted successfully.",
              model);
          targetPage = "redirect:/public/index.html";

        } else {
          organizationForm.setFormObject(organization);
          organizationForm.setProcessForm(true);
        }

      } else {
        setErrorMessage("The requested organization does not exist.", model);
        targetPage = "home";
      }

    } catch (DAOException e) {
      log.error("Error updating persistent entity.", e);
      setErrorMessage(e.getMessage(), model);

    } catch (Throwable t) {
      log.error("Error during controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/createProjectTeam.html", "/createProjectTeam.htm"})
  public String createProjectTeamPage(Model model, HttpSession session,
      RedirectAttributes redirectAttrs, @RequestParam(value = "orgId", required = true) Long orgId,
      @ModelAttribute("teamForm") ProjectTeamForm teamForm) {
    String targetPage = "createProjectTeam";
    try {
      if (teamForm.isProcessForm()) {
        OrganizationDAO orgDAO = DAOFactoryManager.getFactory().newOrganizationDAO();
        ProjectTeamDAO teamDAO = DAOFactoryManager.getFactory().newProjectTeamDAO();
        OrganizationEntity organization = orgDAO.get(orgId);
        ProjectTeamEntity team = teamForm.getFormObject();

        team.setOrganization(organization);
        teamDAO.create(team);
        redirectAttrs.addAttribute("id", team.getId());
        targetPage = "redirect:/public/projectTeam.html";

      } else {
        OrganizationDAO orgDAO = DAOFactoryManager.getFactory().newOrganizationDAO();
        OrganizationEntity organization = orgDAO.get(orgId);

        teamForm.getFormObject().setOrganization(organization);
        teamForm.setProcessForm(true);
      }

    } catch (ValidationException e) {
      addValidationErrors(e, model);

    } catch (DAOException e) {
      log.error("Error updating persistent entity.", e);
      setErrorMessage(e.getMessage(), model);

    } catch (Throwable t) {
      log.error("Error during controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/updateProjectTeam.html", "/updateProjectTeam.htm"})
  public String updateProjectTeamPage(Model model, HttpSession session,
      RedirectAttributes redirectAttrs, @RequestParam(value = "id", required = false) Long teamId,
      @ModelAttribute("teamForm") ProjectTeamForm teamForm) {
    String targetPage = "updateProjectTeam";
    try {
      ProjectTeamDAO dao = DAOFactoryManager.getFactory().newProjectTeamDAO();
      ProjectTeamEntity team = dao.get(teamId);

      if (team != null) {
        if (teamForm.isProcessForm()) {
          team.setName(teamForm.getFormObject().getName());
          dao.update(team);
          redirectAttrs.addAttribute("id", team.getId());
          targetPage = "redirect:/public/projectTeam.html";

        } else {
          teamForm.setFormObject(team);
          teamForm.setProcessForm(true);
        }
        setCurrentOrg(team.getOrganization(), model);

      } else {
        setErrorMessage("The requested project team does not exist.", model);
        targetPage = "home";
      }

    } catch (ValidationException e) {
      addValidationErrors(e, model);

    } catch (DAOException e) {
      log.error("Error updating persistent entity.", e);
      setErrorMessage(e.getMessage(), model);

    } catch (Throwable t) {
      log.error("Error during controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/deleteProjectTeam.html", "/deleteProjectTeam.htm"})
  public String deleteProjectTeamPage(Model model, HttpSession session,
      RedirectAttributes redirectAttrs, @RequestParam(value = "id", required = false) Long teamId,
      @ModelAttribute("teamForm") ProjectTeamForm teamForm) {
    String targetPage = "deleteProjectTeam";
    try {
      ProjectTeamDAO dao = DAOFactoryManager.getFactory().newProjectTeamDAO();
      ProjectTeamEntity team = dao.get(teamId);

      if (team != null) {
        if (teamForm.isProcessForm()) {
          dao.delete(team);
          setStatusMessage("Project team '" + team.getName() + "' deleted successfully.", model);
          redirectAttrs.addAttribute("id", team.getOrganization().getId());
          targetPage = "redirect:/public/organization.html";

        } else {
          teamForm.setFormObject(team);
          teamForm.setProcessForm(true);
        }

      } else {
        setErrorMessage("The requested project team does not exist.", model);
        targetPage = "home";
      }

    } catch (DAOException e) {
      log.error("Error updating persistent entity.", e);
      setErrorMessage(e.getMessage(), model);

    } catch (Throwable t) {
      log.error("Error during controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/createGitBucketGroup.html", "/createGitBucketGroup.htm"})
  public String createGitBucketGroupPage(Model model, HttpSession session,
      RedirectAttributes redirectAttrs,
      @RequestParam(value = "teamId", required = true) Long teamId,
      @ModelAttribute("groupForm") GitBucketGroupForm groupForm) {
    String targetPage = "createGitBucketGroup";
    try {
      if (groupForm.isProcessForm()) {
        ProjectTeamDAO teamDAO = DAOFactoryManager.getFactory().newProjectTeamDAO();
        GitBucketGroupDAO groupDAO = DAOFactoryManager.getFactory().newGitBucketGroupDAO();
        ProjectTeamEntity team = teamDAO.get(teamId);
        GitBucketGroupEntity group = groupForm.getFormObject();

        group.setProjectTeam(team);
        groupDAO.create(group);
        redirectAttrs.addAttribute("id", group.getId());
        targetPage = "redirect:/public/gitBucketGroup.html";

      } else {
        ProjectTeamDAO teamDAO = DAOFactoryManager.getFactory().newProjectTeamDAO();
        ProjectTeamEntity team = teamDAO.get(teamId);

        groupForm.getFormObject().setProjectTeam(team);
        groupForm.setProcessForm(true);
      }

    } catch (ValidationException e) {
      addValidationErrors(e, model);

    } catch (DAOException e) {
      log.error("Error updating persistent entity.", e);
      setErrorMessage(e.getMessage(), model);

    } catch (Throwable t) {
      log.error("Error during controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/updateGitBucketGroup.html", "/updateGitBucketGroup.htm"})
  public String updateGitBucketGroupPage(Model model, HttpSession session,
      RedirectAttributes redirectAttrs, @RequestParam(value = "id", required = false) Long groupId,
      @ModelAttribute("groupForm") GitBucketGroupForm groupForm) {
    String targetPage = "updateGitBucketGroup";
    try {
      GitBucketGroupDAO dao = DAOFactoryManager.getFactory().newGitBucketGroupDAO();
      GitBucketGroupEntity group = dao.get(groupId);

      if (group != null) {
        if (groupForm.isProcessForm()) {
          group.setGroupName(groupForm.getFormObject().getGroupName());
          dao.update(group);
          redirectAttrs.addAttribute("id", group.getId());
          targetPage = "redirect:/public/gitBucketGroup.html";

        } else {
          groupForm.setFormObject(group);
          groupForm.setProcessForm(true);
        }
        setCurrentOrg(group.getProjectTeam().getOrganization(), model);

      } else {
        setErrorMessage("The requested GitBucket group does not exist.", model);
        targetPage = "home";
      }

    } catch (ValidationException e) {
      addValidationErrors(e, model);

    } catch (DAOException e) {
      log.error("Error updating persistent entity.", e);
      setErrorMessage(e.getMessage(), model);

    } catch (Throwable t) {
      log.error("Error during controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/deleteGitBucketGroup.html", "/deleteGitBucketGroup.htm"})
  public String deleteGitBucketGroupPage(Model model, HttpSession session,
      RedirectAttributes redirectAttrs, @RequestParam(value = "id", required = false) Long groupId,
      @ModelAttribute("groupForm") GitBucketGroupForm groupForm) {
    String targetPage = "deleteGitBucketGroup";
    try {
      GitBucketGroupDAO dao = DAOFactoryManager.getFactory().newGitBucketGroupDAO();
      GitBucketGroupEntity group = dao.get(groupId);

      if (group != null) {
        if (groupForm.isProcessForm()) {
          dao.delete(group);
          setStatusMessage("GitBucket group '" + group.getGroupName() + "' deleted successfully.",
              model);
          redirectAttrs.addAttribute("id", group.getProjectTeam().getId());
          targetPage = "redirect:/public/projectTeam.html";

        } else {
          groupForm.setFormObject(group);
          groupForm.setProcessForm(true);
        }

      } else {
        setErrorMessage("The requested GitBucket group does not exist.", model);
        targetPage = "home";
      }

    } catch (DAOException e) {
      log.error("Error updating persistent entity.", e);
      setErrorMessage(e.getMessage(), model);

    } catch (Throwable t) {
      log.error("Error during controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/createGitRepository.html", "/createGitRepository.htm"})
  public String createGitRepositoryPage(Model model, HttpSession session,
      RedirectAttributes redirectAttrs,
      @RequestParam(value = "teamId", required = true) Long teamId,
      @ModelAttribute("repoForm") GitRepositoryForm repoForm) {
    String targetPage = "createGitRepository";
    try {
      model.addAttribute("allRepositoryTypes", AuditUtils.buildSelectOptions(RepositoryType.class));
      model.addAttribute("availableBranches",
          new RepositoryFinder().findGitBranches(repoForm.getFormObject().getRepositoryUrl()));

      if (repoForm.isProcessForm()) {
        ProjectTeamDAO teamDAO = DAOFactoryManager.getFactory().newProjectTeamDAO();
        GitRepositoryDAO repoDAO = DAOFactoryManager.getFactory().newGitRepositoryDAO();
        String repositoryUrl = repoForm.getFormObject().getRepositoryUrl();
        ProjectTeamEntity team = teamDAO.get(teamId);
        GitRepositoryEntity repo = repoForm.getFormObject();

        repo.setRepositoryName(getRepositoryName(repositoryUrl));
        repo.setProjectTeam(team);
        repoDAO.create(repo);
        redirectAttrs.addAttribute("id", repo.getId());
        targetPage = "redirect:/public/gitRepository.html";

      } else {
        ProjectTeamDAO teamDAO = DAOFactoryManager.getFactory().newProjectTeamDAO();
        ProjectTeamEntity team = teamDAO.get(teamId);

        repoForm.getFormObject().setProjectTeam(team);
        repoForm.setProcessForm(true);
      }

    } catch (ValidationException e) {
      addValidationErrors(e, model);

    } catch (DAOException e) {
      log.error("Error updating persistent entity.", e);
      setErrorMessage(e.getMessage(), model);

    } catch (Throwable t) {
      log.error("Error during controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/updateGitRepository.html", "/updateGitRepository.htm"})
  public String updateGitRepositoryPage(Model model, HttpSession session,
      RedirectAttributes redirectAttrs, @RequestParam(value = "id", required = false) Long repoId,
      @ModelAttribute("repoForm") GitRepositoryForm repoForm) {
    String targetPage = "updateGitRepository";
    try {
      GitRepositoryDAO dao = DAOFactoryManager.getFactory().newGitRepositoryDAO();
      GitRepositoryEntity repo = dao.get(repoId);

      if (repo != null) {
        model.addAttribute("allRepositoryTypes",
            AuditUtils.buildSelectOptions(RepositoryType.class));
        model.addAttribute("availableBranches",
            new RepositoryFinder().findGitBranches(repo.getRepositoryUrl()));

        if (repoForm.isProcessForm()) {
          String repositoryUrl = repoForm.getFormObject().getRepositoryUrl();

          repo.setRepositoryName(getRepositoryName(repositoryUrl));
          repo.setRepositoryUrl(repositoryUrl);
          repo.setType(repoForm.getFormObject().getType());
          repo.setBranch(repoForm.getFormObject().getBranch());
          repo.setProjectKey(repoForm.getFormObject().getProjectKey());
          repo.setProjectName(repoForm.getFormObject().getProjectName());
          dao.update(repo);
          redirectAttrs.addAttribute("id", repo.getId());
          targetPage = "redirect:/public/gitRepository.html";

        } else {
          repoForm.setFormObject(repo);
          repoForm.setProcessForm(true);
        }
        setCurrentOrg(repo.getProjectTeam().getOrganization(), model);

      } else {
        setErrorMessage("The requested Git repository does not exist.", model);
        targetPage = "home";
      }

    } catch (ValidationException e) {
      addValidationErrors(e, model);

    } catch (DAOException e) {
      log.error("Error updating persistent entity.", e);
      setErrorMessage(e.getMessage(), model);

    } catch (Throwable t) {
      log.error("Error during controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/deleteGitRepository.html", "/deleteGitRepository.htm"})
  public String deleteGitRepositoryPage(Model model, HttpSession session,
      RedirectAttributes redirectAttrs, @RequestParam(value = "id", required = false) Long repoId,
      @ModelAttribute("repoForm") GitRepositoryForm repoForm) {
    String targetPage = "deleteGitRepository";
    try {
      GitRepositoryDAO dao = DAOFactoryManager.getFactory().newGitRepositoryDAO();
      GitRepositoryEntity repo = dao.get(repoId);

      if (repo != null) {
        if (repoForm.isProcessForm()) {
          dao.delete(repo);
          setStatusMessage(
              "GitBucket repo '" + repo.getRepositoryName() + "' deleted successfully.", model);
          redirectAttrs.addAttribute("id", repo.getProjectTeam().getId());
          targetPage = "redirect:/public/projectTeam.html";

        } else {
          repoForm.setFormObject(repo);
          repoForm.setProcessForm(true);
        }

      } else {
        setErrorMessage("The requested Git repository does not exist.", model);
        targetPage = "home";
      }

    } catch (DAOException e) {
      log.error("Error updating persistent entity.", e);
      setErrorMessage(e.getMessage(), model);

    } catch (Throwable t) {
      log.error("Error during controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  @RequestMapping({"/discoverGitRepositories.html", "/discoverGitRepositories.htm"})
  public String discoverGitRepositoriesPage(Model model, HttpSession session,
      RedirectAttributes redirectAttrs,
      @RequestParam(value = "teamId", required = false) Long teamId,
      @ModelAttribute("candidateForm") RepositoryCandidateForm candidateForm) {
    String targetPage = "discoverGitRepositories";
    try {
      ProjectTeamDAO teamDao = DAOFactoryManager.getFactory().newProjectTeamDAO();
      ProjectTeamEntity team = teamDao.get(teamId);

      if (team != null) {
        if (candidateForm.isProcessForm()) {
          GitRepositoryDAO repoDao = DAOFactoryManager.getFactory().newGitRepositoryDAO();
          int selectionCount = 0;
          int createFailures = 0;

          for (RepositoryCandidate candidate : candidateForm.getFormObject()) {
            if (candidate.isSelected()) {
              try {
                GitRepositoryEntity repo = new GitRepositoryEntity();

                selectionCount++;
                repo.setProjectTeam(team);
                repo.setRepositoryUrl(candidate.getRepositoryUrl());
                repo.setRepositoryName(getRepositoryName(candidate.getRepositoryUrl()));
                repo.setBranch(candidate.getSelectedBranch());
                repo.setType(candidate.getSelectedType());
                repo.setProjectKey("TempProjectKey");
                repoDao.create(repo);

              } catch (DAOException e) {
                log.error("Error creating Git repository: " + candidate.getRepositoryUrl(), e);
                createFailures++;
              }
            }
          }

          if (selectionCount > 0) {
            if (createFailures == 0) {
              setStatusMessage("The selected Git repositories were created successfully.",
                  redirectAttrs);

            } else {
              setStatusMessage(
                  "Created " + (selectionCount - createFailures) + " Git repositories ["
                      + createFailures + " failure(s)].  See server log for details.",
                  redirectAttrs);
            }
            redirectAttrs.addAttribute("id", team.getId());
            targetPage = "redirect:/public/projectTeam.html";

          } else {
            setErrorMessage("At least one Git repository must be selected.", model);
          }

        } else {
          List<String> existingRepositoryUrls = new ArrayList<>();
          List<String> gitbucketGroups = new ArrayList<>();
          List<RepositoryCandidate> repoCandidates;

          for (GitBucketGroupEntity gbGroup : team.getGitBucketGroups()) {
            gitbucketGroups.add(gbGroup.getGroupName());
          }
          for (GitRepositoryEntity existingRepo : team.getGitRepositories()) {
            existingRepositoryUrls.add(existingRepo.getRepositoryUrl());
          }
          repoCandidates =
              new RepositoryFinder().findRepositories(gitbucketGroups, existingRepositoryUrls);

          candidateForm.setFormObject(repoCandidates);
          candidateForm.setProcessForm(true);
        }
        model.addAttribute("team", team);

      } else {
        setErrorMessage("The requested project team does not exist.", model);
        targetPage = "home";
      }

    } catch (DAOException e) {
      log.error("Error creating Git repositories.", e);
      setErrorMessage(e.getMessage(), model);

    } catch (Throwable t) {
      log.error("Error during controller processing.", t);
      setErrorMessage(DEFAULT_ERROR_MESSAGE, model);
    }
    return applyCommonValues(model, targetPage);
  }

  /**
   * Returns the name component of the repository from the URL provided.
   * 
   * @param repositoryUrl the URL of the git repository from which to extract the name
   * @return String
   */
  private String getRepositoryName(String repositoryUrl) {
    int slashIdx = repositoryUrl.lastIndexOf('/');
    String repoName = (slashIdx < 0) ? repositoryUrl : repositoryUrl.substring(slashIdx + 1);

    return repoName.replace(".git", "");
  }

}
