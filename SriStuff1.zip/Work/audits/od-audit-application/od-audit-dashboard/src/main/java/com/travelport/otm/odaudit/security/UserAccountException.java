/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.security;

/**
 * Exception thrown when an error occurs during user authentication.
 */
public class UserAccountException extends Exception {

  private static final long serialVersionUID = 1433946538665096960L;

  /**
   * Default constructor.
   */
  public UserAccountException() {}

  /**
   * Constructs an exception with the specified message.
   * 
   * @param message the exception message
   */
  public UserAccountException(String message) {
    super(message);
  }

  /**
   * Constructs an exception with the specified underlying cause.
   * 
   * @param cause the underlying exception that caused this one
   */
  public UserAccountException(Throwable cause) {
    super(cause);
  }

  /**
   * Constructs an exception with the specified message and underlying cause.
   * 
   * @param message the exception message
   * @param cause the underlying exception that caused this one
   */
  public UserAccountException(String message, Throwable cause) {
    super(message, cause);
  }

}
