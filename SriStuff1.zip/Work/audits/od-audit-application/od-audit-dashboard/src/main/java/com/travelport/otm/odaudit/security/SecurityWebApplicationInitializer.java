/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.security;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 * Initializes the security system for the application.
 */
public class SecurityWebApplicationInitializer extends AbstractSecurityWebApplicationInitializer {

  /**
   * Default constructor.
   */
  public SecurityWebApplicationInitializer() {
    super(LoginSecurityConfig.class);
  }

}
