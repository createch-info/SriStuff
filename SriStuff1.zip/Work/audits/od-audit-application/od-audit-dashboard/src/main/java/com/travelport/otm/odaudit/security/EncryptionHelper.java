/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.security;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.Random;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

/**
 * Helper class used to encrypt and decrypt passwords.
 */
public class EncryptionHelper {

  private static final int SK_LENGTH = 8;
  private static final String SK_ALGORITHM = "PBEWithMD5AndDES";
  private static final char[] SK_CHARSET =
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
  private static final byte[] SALT = {25, -82, -101, 35, 76, 122, 41, 3};
  private static final int ITERATION_COUNT = 12;

  /**
   * Encrypts the given plain-text string.
   * 
   * @param plainText the plain text string to be encrypted
   * @return String
   */
  public static String encrypt(String plainText) {
    try {
      String secretKey = generateSecretKey();
      KeySpec keySpec = new PBEKeySpec(secretKey.toCharArray(), SALT, ITERATION_COUNT);
      SecretKey key = SecretKeyFactory.getInstance(SK_ALGORITHM).generateSecret(keySpec);
      AlgorithmParameterSpec paramSpec = new PBEParameterSpec(SALT, ITERATION_COUNT);
      Cipher encryptCipher = Cipher.getInstance(key.getAlgorithm());

      encryptCipher.init(Cipher.ENCRYPT_MODE, key, paramSpec);
      byte[] in = plainText.getBytes("UTF-8");
      byte[] out = encryptCipher.doFinal(in);

      return secretKey + new String(Base64.getEncoder().encode(out));

    } catch (InvalidKeySpecException | NoSuchAlgorithmException | InvalidKeyException
        | InvalidAlgorithmParameterException | NoSuchPaddingException | UnsupportedEncodingException
        | IllegalBlockSizeException | BadPaddingException e) {
      throw new EncryptionException("Error during string processing", e);
    }
  }

  /**
   * Decrypts the given encrypted-text string.
   * 
   * @param plainText the encrypted text string to be decrypted
   * @return String
   */
  public static String decrypt(String encryptedText) {
    try {
      if ((encryptedText == null) || (encryptedText.length() <= SK_LENGTH)) {
        throw new EncryptionException("The encrypted text string is not valid: " + encryptedText);
      }
      String secretKey = encryptedText.substring(0, SK_LENGTH);
      String eText = encryptedText.substring(SK_LENGTH);
      KeySpec keySpec = new PBEKeySpec(secretKey.toCharArray(), SALT, ITERATION_COUNT);
      SecretKey key = SecretKeyFactory.getInstance(SK_ALGORITHM).generateSecret(keySpec);
      AlgorithmParameterSpec paramSpec = new PBEParameterSpec(SALT, ITERATION_COUNT);
      Cipher decryptCipher = Cipher.getInstance(key.getAlgorithm());

      decryptCipher.init(Cipher.DECRYPT_MODE, key, paramSpec);
      byte[] enc = Base64.getDecoder().decode(eText);
      byte[] utf8Bytes = decryptCipher.doFinal(enc);
      return new String(utf8Bytes, "UTF-8");

    } catch (InvalidKeySpecException | NoSuchAlgorithmException | NoSuchPaddingException
        | InvalidKeyException | InvalidAlgorithmParameterException | IllegalBlockSizeException
        | BadPaddingException | UnsupportedEncodingException e) {
      throw new EncryptionException("Error during string processing", e);
    }
  }

  /**
   * Generates an eight character alpha-numeric secret key.
   * 
   * @return String
   */
  private static String generateSecretKey() {
    Random r = new Random(System.currentTimeMillis());
    StringBuilder secretKey = new StringBuilder();

    for (int i = 0; i < SK_LENGTH; i++) {
      secretKey.append(SK_CHARSET[r.nextInt(SK_CHARSET.length)]);
    }
    return secretKey.toString();
  }

  public static void main(String[] args) {
    System.out.println("DECRYPTED: '" + decrypt("vtLmG3tsNSfenTb4ki4=") + "'");
  }
}
