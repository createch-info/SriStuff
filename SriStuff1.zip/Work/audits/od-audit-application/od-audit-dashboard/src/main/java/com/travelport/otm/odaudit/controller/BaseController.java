/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;

import com.travelport.otm.odaudit.dao.DAOException;
import com.travelport.otm.odaudit.dao.DAOFactory;
import com.travelport.otm.odaudit.dao.DAOFactoryManager;
import com.travelport.otm.odaudit.dao.OrganizationDAO;
import com.travelport.otm.odaudit.model.OrganizationEntity;
import com.travelport.otm.odaudit.util.PageUtils;
import com.travelport.otm.odaudit.validation.ValidationException;
import com.travelport.otm.odaudit.validation.ValidationResults;

/**
 * Abstract base class of all Spring Web MVC controllers for the OD Audit Dashboard site.
 */
public class BaseController {

  static final String DEFAULT_ERROR_MESSAGE =
      "An error occured while displaying the page (please contact the system administrator).";

  private static final Logger log = LoggerFactory.getLogger(BaseController.class);

  @Autowired
  private HttpServletRequest requestContext;

  /**
   * Applies all values to the given model that are common to the entire application. If
   * 'targetPage' value will always be returned by this method if a non-null value is provided. If
   * null, a default value of "homePage" will be returned.
   * 
   * @param model the UI model to which the common values should be applied
   * @param targetPage the target navigation page for the controller
   * @return String
   */
  protected String applyCommonValues(Model model, String targetPage) {
    DAOFactory daoFactory = new DAOFactory();
    try {
      OrganizationDAO orgDAO = daoFactory.newOrganizationDAO();

      if (requestContext != null) {
        String statusMessage = requestContext.getParameter("statusMessage");
        String errorMessage = requestContext.getParameter("errorMessage");

        if (statusMessage != null) {
          setStatusMessage(statusMessage, model);
        }
        if (errorMessage != null) {
          setErrorMessage(errorMessage, model);
        }
      }
      model.addAttribute("pageUtils", new PageUtils());
      model.addAttribute("currentPage", targetPage);
      model.addAttribute("allOrganizations", orgDAO.getAll());

    } catch (DAOException e) {
      log.error("Error retrieving organizations.", e);

    } finally {
      daoFactory.close();
    }
    return (targetPage == null) ? "home" : targetPage;
  }

  /**
   * Assigns the current organization for the request being processed.
   * 
   * @param currentOrg the current organization
   * @param model the model to which the organization assignment should be applied
   */
  protected void setCurrentOrg(OrganizationEntity currentOrg, Model model) {
    model.addAttribute("currentOrgId", (currentOrg == null) ? -1 : currentOrg.getId());
  }

  /**
   * Assigns the status message for the console page that will be displayed.
   * 
   * @param statusMessage the status message text
   * @param model the model to which the error message should be applied
   */
  protected void setStatusMessage(String statusMessage, Model model) {
    model.addAttribute("statusMessage", statusMessage);
  }

  /**
   * Assigns the error message for the console page that will be displayed. A call to this method
   * also marks the current transaction for rollback.
   * 
   * @param errorMessage the error message text
   * @param model the model to which the error message should be applied
   */
  protected void setErrorMessage(String errorMessage, Model model) {
    model.addAttribute("errorMessage", errorMessage);
    DAOFactoryManager.markForRollback();
  }

  /**
   * Adds the given set of validation results to the model provided. If any validation results
   * already exist in the model, the new results are merged into the original set.
   * 
   * <p>
   * The results are stored as a model attribute under the key "validationErrors".
   * 
   * <p>
   * A call to this method also marks the current transaction for rollback.
   * 
   * @param validationEx the exception that contains the set of validation results to add
   * @param model the model that will contain the validation results
   */
  protected void addValidationErrors(ValidationException validationEx, Model model) {
    ValidationResults validationResults = validationEx.getValidationResults();

    if (validationResults != null) {
      addValidationErrors(validationResults, model);

    } else { // use the exception message as the UI error message
      setErrorMessage(validationEx.getMessage(), model);
    }
    DAOFactoryManager.markForRollback();
  }

  /**
   * Adds the given set of validation results to the model provided. If any validation results
   * already exist in the model, the new results are merged into the original set.
   * 
   * <p>
   * The results are stored as a model attribute under the key "validationErrors".
   * 
   * <p>
   * A call to this method also marks the current transaction for rollback.
   * 
   * @param validationResults the set of validation results to add
   * @param model the model that will contain the validation results
   */
  protected void addValidationErrors(ValidationResults validationResults, Model model) {
    if (validationResults != null) {
      ValidationResults existingResults = (ValidationResults) model.asMap().get("validationErrors");

      if (existingResults != null) {
        existingResults.addAll(validationResults);

      } else {
        model.addAttribute("validationErrors", validationResults);
      }
    }
  }

}
