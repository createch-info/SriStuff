/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.form;

import com.travelport.otm.odaudit.security.UserAccount;

/**
 * Model object form for the <code>UserAccount</code> class.
 */
public class UserAccountForm extends AbstractForm<UserAccount> {

  /**
   * Default constructor.
   */
  public UserAccountForm() {
    super(new UserAccount());
  }

}
