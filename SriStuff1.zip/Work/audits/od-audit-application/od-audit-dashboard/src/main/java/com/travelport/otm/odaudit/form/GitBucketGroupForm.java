/*******************************************************************************
 * Copyright (c) 2018 Travelport. All rights reserved.
 *******************************************************************************/
package com.travelport.otm.odaudit.form;

import com.travelport.otm.odaudit.model.GitBucketGroupEntity;

/**
 * Model object form for the <code>GitBucketGroup</code> class.
 */
public class GitBucketGroupForm extends AbstractForm<GitBucketGroupEntity> {

  /**
   * Default constructor.
   */
  public GitBucketGroupForm() {
    super(new GitBucketGroupEntity());
  }

}
