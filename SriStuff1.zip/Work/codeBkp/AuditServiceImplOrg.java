/*******************************************************************************
 * Copyright (c) 2017 IBM Corporation and others. All rights reserved. This program and the
 * accompanying materials are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors: IBM Corporation - initial API and implementation
 *******************************************************************************/
package com.travelport.otm.odaudit.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.travelport.otm.odaudit.model.OdProgramReport;

@Path("/od_audit")
@Consumes({MediaType.APPLICATION_JSON})
@Produces({MediaType.APPLICATION_JSON})
public class AuditServiceImplOrg implements AuditService {

  private static final Logger log = LoggerFactory.getLogger(AuditServiceImplOrg.class);

  private static AuditServiceImplOrg helper;

  static {
    helper = new AuditServiceImplOrg();
  }

  @Override
  @GET
  @Path("/metrics")
  public void getSonarMetricsAndRollup() {

    // Create OD_PROGRAM_REPORT record with dummy sonar_scan_info_id
    OdProgramReport report = helper.createODPgmReport();

    // Fetch from sonarQube and persist repo-level metrics for all repos
    helper.updateRepoMetrics(report);

    // Invoke method to get the latest version of git repo & branch
    // RevCommit commit = helper.getLatestCommit();
  }

}
