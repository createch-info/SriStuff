package com.travelport.odbootcamp.albumdomain;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.namespace.QName;

import com.travelport.odt.restfw.plugin.common.annotations.OTMAction;
import com.travelport.odt.restfw.plugin.common.annotations.OTMResource;
import com.travelport.odt.restfw.common.FrameworkConstants;
import com.travelport.odt.restfw.plugin.common.exceptions.ServiceException;
import com.travelport.odt.restfw.plugin.common.sync.ProcessingJob;
import com.travelport.odt.restfw.consumer.ActionParam;
import com.travelport.odt.restfw.consumer.InvocationManager;
import com.travelport.odt.restfw.consumer.InvocationManagerFactory;
import com.travelport.odt.restfw.consumer.exceptions.InvocationException;
import com.travelport.schema.common.Identifier;

import sandbox.demonstration.mp3.AlbumID;
import sandbox.demonstration.mp3.AlbumIdentifier;
import sandbox.demonstration.mp3.AbstractAlbumResource;
import sandbox.demonstration.mp3.ArtistIdentifier;
import sandbox.demonstration.mp3.Song;

@Path("OD_BOOTCAMP/Albums")
@OTMResource(systemId="OD_BOOTCAMP", namespace="http://sandbox/Demonstration/MP3/v0", localName="AlbumResource")
@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON} )
@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON} )
public class MyAlbumDomain extends AbstractAlbumResource {

	@Override
	protected void doCreate_v0( final String songName,  final String artistName,  final AlbumID albumID, final String version) throws ServiceException {
	}

	@Override
	protected void doDelete_v0( final String identifier) throws ServiceException {
	}
	
	@Override
	protected AlbumIdentifier doGet_v0( final String identifier) throws ServiceException {
		AlbumIdentifier albumId = new AlbumIdentifier();
		Identifier id = new Identifier();
		id.setValue(identifier);
		albumId.setIdentifier(id);

		return albumId;
	}

	@Override
	protected AlbumIdentifier doQuery_Mp3_v0( final String songName,  final String artistName) throws ServiceException {
		AlbumIdentifier albumId = new AlbumIdentifier();
		Identifier id = new Identifier();
		id.setValue("123");
		albumId.setIdentifier(id);

		return albumId;
	}

	/**
	 * This method is overridden to provide a work around for an OD REST Framework
	 * bug which will be fixed in an upcoming release.  This override allows the
	 * LocalResourceManager call for the Get action to use the path parameter
	 * name of "Identifier" rather than the framework generated name of "param1".
	 * This workaround will not be needed in future releases of the framework.
	 */
	@Override
	@GET 
	@OTMAction("Get")
	@Path("/{Identifier}")
	public Response get(@javax.ws.rs.PathParam("Identifier") final String identifier) {
		try {
			ProcessingJob job = new ProcessingJob() {
					public Object processRequest() throws ServiceException {
						return doGet_v0(identifier);
					}
				};
				
			return buildResponse( job.processRequest() );

		} catch (Throwable t) {
			return buildResponse( t );
		}
	}

}
