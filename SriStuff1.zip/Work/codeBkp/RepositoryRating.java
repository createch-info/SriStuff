/*
 * Copyright (c) 2017, Travelport. All Rights Reserved. Use is subject to license agreement.
 */
package com.travelport.otm.odaudit.model;

import java.util.List;

/**
 * POJO for repo-level ratings
 */
public class RepositoryRating {

	private long repositoryReportId;

	private String repositoryUrl;

	private List<KPITypeRating> ratings;

	/**
	 * Returns repository report Id
	 *
	 * @return long
	 */
	public long getRepositoryReportId() {
		return repositoryReportId;
	}

	/**
	 * Assigns repository report Id
	 *
	 * @param repositoryReportId
	 *            the ID value to assign
	 */
	public void setRepositoryReportId(long repositoryReportId) {
		this.repositoryReportId = repositoryReportId;
	}

	/**
	 * Returns repository URL
	 *
	 * @return String
	 */
	public String getRepositoryUrl() {
		return repositoryUrl;
	}

	/**
	 * Assigns repository URL
	 *
	 * @param repository
	 *            URL to assign
	 */
	public void setRepositoryUrl(String repositoryUrl) {
		this.repositoryUrl = repositoryUrl;
	}

	/**
	 * Returns list of KPITypeRating
	 *
	 * @return List<KPITypeRating>
	 */
	public List<KPITypeRating> getRatings() {
		return ratings;
	}

	/**
	 * Assigns list of KPITypeRating
	 *
	 * @param List<KPITypeRating>
	 */
	public void setRatings(List<KPITypeRating> ratings) {
		this.ratings = ratings;
	}
}
