package com.travelport.odbootcamp.albumdomain.jersey;

import com.travelport.training.od_bootcamp.tp.mp3.sponnapalli.Album;

public class AlbumUpdate extends Album {

  private String newName;

  public AlbumUpdate(Album album) {
    super.setSong(album.getSong());
    super.setTitle(album.getTitle());
    super.setArtist(album.getArtist());
  }

  public String getNewName() {
    return newName;
  }

  public void setNewName(String newName) {
    this.newName = newName;
  }
}
