/*******************************************************************************
 * Copyright (c) 2017 IBM Corporation and others. All rights reserved. This program and the
 * accompanying materials are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors: IBM Corporation - initial API and implementation
 *******************************************************************************/
package com.travelport.odbootcamp.albumdomain;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.travelport.otm.odaudit.service.AuditService;
import com.travelport.otm.odaudit.service.AuditServiceImpl;
import com.travelport.otm.odaudit.service.domain.SonarMeasure;
import com.travelport.otm.odaudit.service.domain.SonarMetrics;

public class AuditServiceImplTest {

  private static final String TEST_PROJECT_KEY =
      "com.travelport.odbootcamp:albumdomain-sponnapalli102";

  // @Mocked
  // private InvocationManager invocationManager;
  // @Mocked
  // private InvocationBuilder invocationBuilder;

  private AuditService service;

  @BeforeClass
  public void setup() {
    // new MockUp<InvocationManagerFactory>() {
    // @Mock
    // InvocationManager getManager() {
    // return invocationManager;
    // }
    //
    // };

    service = new AuditServiceImpl();
  }

  @AfterClass
  public void teardown() {
    service = null;
  }

  @Test
  public void testFetchScanMetrics() throws Exception {
    SonarMetrics metrics = service.fetchScanMetrics(TEST_PROJECT_KEY);

    assertNotNull(metrics);
    assertNotNull(metrics.getMeasures());
    assertFalse(metrics.getMeasures().isEmpty());

    SonarMeasure measure = metrics.getMeasures().get(0);
    assertNotNull(measure);
  }
}
